# KAI Vibe

Turns a WordPress site into a native **MCP (Model Context Protocol)** server, so an AI client can read and manage the site over an authenticated, scoped, fully audited connection.

There is no relay service and no companion Node process. WordPress hosts the MCP endpoint itself:

```
https://your-site.com/wp-json/kai-vibe/v1/mcp
```

Transport is Streamable HTTP. Authentication is a bearer token minted in wp-admin.

---

## Why it is built this way

Three decisions shape everything else.

**A token resolves to a real WordPress user.** Rather than inventing a parallel permission system, a verified token is handed to `determine_current_user`. From that point every core capability check applies exactly as it would for a logged-in human — `current_user_can`, `map_meta_cap`, post type permissions, WooCommerce, everything. Scopes narrow what a token may reach; they can never widen it past the user it acts as.

**Destructive work stops for a human.** Installing a plugin, switching a theme, writing a PHP file, running SQL or WP-CLI, changing a role, deleting permanently — each raises an approval request that appears in wp-admin. Approving one lets the agent complete *that exact operation once*, matched on tool name plus an argument fingerprint. Anything else needs a fresh approval.

**Everything overwritten is kept.** WordPress revisions cover `post_content` and little else — not post meta, options, terms, or theme files, which is exactly where an agent does its most consequential work. A change journal records the previous state of every write, and `undo_change` restores it. There is a one-click Undo in wp-admin too.

---

## Install

1. Copy the `kai-vibe` directory into `wp-content/plugins/`.
2. Activate it in **Plugins**.
3. Open **KAI Vibe → Tokens**, create a token, and copy it. It is shown once — only an HMAC is stored.
4. Point your client at the endpoint.

### Claude Code

```bash
claude mcp add --transport http kai-vibe \
  https://your-site.com/wp-json/kai-vibe/v1/mcp \
  --header "Authorization: Bearer kaiv_..."
```

### Any client that reads `mcp.json`

```json
{
  "mcpServers": {
    "kai-vibe": {
      "type": "http",
      "url": "https://your-site.com/wp-json/kai-vibe/v1/mcp",
      "headers": { "Authorization": "Bearer kaiv_..." }
    }
  }
}
```

### Check by hand

```bash
curl -s https://your-site.com/wp-json/kai-vibe/v1/mcp \
  -H "Authorization: Bearer kaiv_..." \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```

`GET /wp-json/kai-vibe/v1/info` needs no token and confirms the plugin is installed and reachable.

**HTTPS is required.** Tokens are refused over plain HTTP outside `local` and `development` environments, for the same reason Application Passwords are.

---

## Tools

Around seventy tools across seventeen packs. Each declares a required scope and, where relevant, a WordPress capability. Tools whose scope a token lacks are hidden from `tools/list` rather than failing on call — a shorter honest list beats a long one full of permission errors.

| Pack | Tools |
|---|---|
| **Site** | `site_info`, `site_health`, `list_post_types`, `list_taxonomies`, `connection_status`, `check_approval`, `list_approvals` |
| **Content** | `find_content`, `get_post`, `create_post`, `update_post`, `delete_post`, `get_post_meta`, `set_post_meta`, `list_revisions`, `restore_revision`, `duplicate_post` |
| **Taxonomies** | `list_terms`, `create_term`, `update_term`, `delete_term`, `assign_terms` |
| **Media** | `search_media`, `upload_media`, `update_media`, `delete_media`, `set_featured_image` |
| **Users** | `list_users`, `get_user`, `list_roles`, `create_user`, `update_user`, `delete_user` |
| **Comments** | `list_comments`, `moderate_comment`, `reply_to_comment`, `delete_comment` |
| **Options** | `get_option`, `list_options`, `set_option`, `delete_option` |
| **Menus** | `list_menus`, `get_menu`, `add_menu_item`, `delete_menu_item` |
| **Plugins & themes** | `list_plugins`, `list_themes`, `activate_plugin`, `deactivate_plugin`, `install_plugin`, `update_extension`, `delete_plugin`, `switch_theme` |
| **Filesystem** | `list_files`, `read_file`, `write_file`, `edit_file`, `search_files`, `delete_file`, `create_directory` |
| **WP-CLI** | `run_wp_cli`, `wp_cli_status` |
| **Database** | `db_tables`, `db_describe`, `db_query` |
| **Page builders** | `builder_detect`, `builder_get`, `builder_set`, `builder_flush` |
| **WooCommerce** | `wc_products`, `wc_get_product`, `wc_update_product`, `wc_orders`, `wc_get_order`, `wc_update_order_status`, `wc_sales_report` |
| **Search** | `search_content`, `grep_content`, `replace_in_content`, `fetch_rendered_page` |
| **Maintenance** | `flush_cache`, `flush_rewrites`, `list_cron`, `run_cron_event`, `manage_transients`, `read_debug_log` |
| **Journal** | `list_changes`, `get_change`, `undo_change` |

Also exposed: MCP **resources** (`wp://site/overview`, `wp://post/{id}`, `wp://file/{path}`, `wp://option/{name}`, and more) and **prompts** (`site_health_review`, `write_post`, `fix_page`, `bulk_cleanup`).

### Page builder awareness

The most common way an agent breaks a WordPress site is editing `post_content` on a page whose layout lives in post meta. This plugin refuses to let that happen: `update_post` errors out with a pointer to `builder_set` when a builder owns the post, and `builder_set` encodes the value the way that builder expects, sets the flags it needs, and regenerates its CSS cache.

Recognised: Elementor, Divi, Beaver Builder, Bricks, Breakdance, Oxygen, WPBakery. Register more with the `kaiv_builders` filter.

---

## Security model

| Layer | What it does |
|---|---|
| Transport | HTTPS required outside local/dev |
| Token | `kaiv_<id>_<secret>`; only an HMAC keyed to the site salt is stored; per-token scopes, expiry, revocation, usage stats |
| Identity | Token resolves to a WordPress user; all core capability checks apply |
| Scopes | 23 scopes with `prefix:*` and `*` wildcards; enforced before the tool runs |
| Capability | Tools additionally declare a required WordPress capability |
| Approval gate | Destructive operations wait for a human, matched on tool + argument fingerprint, single use, time limited |
| Path jail | Filesystem tools resolve through `realpath()` and must land inside `wp-content` or a configured extra root; `wp-config.php` is never reachable |
| PHP lint | PHP writes are parsed before they hit disk; a syntax error is refused, not saved |
| SQL guard | `DROP`/`TRUNCATE`/`GRANT` refused outright; stacked statements refused; writes off by default and never permitted against the user tables; reads row-capped and credential columns redacted |
| Secrets | Options and meta matching credential patterns are never returned; `user_pass` and session tokens never leave the site |
| Rate limit | Per-token call ceiling, configurable |
| IP allowlist | Optional, supports CIDR for IPv4 and IPv6 |
| Audit log | Every call, argument set, outcome and duration, with credential-shaped values redacted |
| Journal | Previous state of every write, with rollback |

Deleting the plugin destroys all tokens.

---

## Settings

**KAI Vibe → Settings.** Sensible defaults are already applied; the ones worth a decision:

- **WP-CLI** — off by default. The most powerful tool here.
- **Database writes** — off by default. Raw writes skip the hooks WordPress uses to keep caches and derived data correct.
- **Approval gate** — on by default. Turn it off only where a mistake is cheap.
- **PHP file writes** — on by default. Turn off on production unless you mean it.

---

## Extending

Register your own tools:

```php
add_action( 'kaiv_register_tools', function ( $registry ) {
	$registry->add(
		KaiVibe\Mcp\Tool::make( 'my_tool' )
			->describe( 'What it does, and when the model should reach for it.' )
			->scope( 'content:read' )
			->cap( 'edit_posts' )
			->read_only()
			->input(
				KaiVibe\Mcp\Schema::object(
					array( 'thing' => KaiVibe\Mcp\Schema::string( 'The thing.' ) ),
					array( 'thing' )
				)
			)
			->run( function ( array $args ) {
				return array( 'echoed' => $args['thing'] );
			} )
	);
} );
```

Return an array (JSON), a string (text), a `WP_Error` (tool error), or a `ToolResult` for full control.

Useful filters and actions:

| Hook | Purpose |
|---|---|
| `kaiv_tool_packs` | Add or remove whole tool packs |
| `kaiv_register_tools` | Register individual tools |
| `kaiv_scopes` | Extend the scope vocabulary |
| `kaiv_instructions` | Change the guidance sent to the model on connect |
| `kaiv_builders` | Register another page builder |
| `kaiv_fs_roots` | Widen or narrow the filesystem jail |
| `kaiv_secret_options`, `kaiv_locked_options` | Adjust what is unreadable / unwritable |
| `kaiv_guarded_tables` | Tables raw SQL may not write |
| `kaiv_approval_requested` | Send yourself a notification when an agent asks for approval |
| `kaiv_pre_approval` | Auto-approve specific calls |
| `kaiv_flush_cache` | Hook your own cache layer into `flush_cache` |
| `kaiv_trust_proxy_headers` | Trust `X-Forwarded-For` behind a proxy (needed for a meaningful IP allowlist) |

---

## Layout

```
kai-vibe/
├── kai-vibe.php          bootstrap
├── uninstall.php             destroys tokens, tables, options
├── assets/                   admin CSS and JS
└── includes/
    ├── class-autoloader.php  KaiVibe\Sub\ClassName → includes/sub/class-class-name.php
    ├── class-plugin.php      wiring
    ├── class-installer.php   tables, defaults, cron
    ├── class-settings.php
    ├── functions.php
    ├── mcp/                  protocol: server, transport, tools, schema, validation,
    │                         resources, prompts
    ├── auth/                 scopes, token manager, authenticator
    ├── security/             audit log, journal, path guard, protected data,
    │                         approval gate, rate limiter
    ├── support/              formatter, site profile, page builders
    ├── tools/                seventeen tool packs
    └── admin/                screens and views
```

---

## Requirements

WordPress 6.4+, PHP 7.4+. Pretty permalinks recommended (the REST route works either way).

## Licence

GPL-2.0-or-later.
