/**
 * KAI Vibe admin behaviour: copy buttons and scope presets.
 */
( function () {
	'use strict';

	var PRESETS = {
		read: [
			'site:read',
			'content:read',
			'media:read',
			'comments:read',
			'extensions:read'
		],
		content: [
			'site:read',
			'content:read',
			'content:write',
			'taxonomy:write',
			'media:read',
			'media:write',
			'comments:read',
			'comments:write',
			'builder:write'
		],
		developer: [
			'site:read',
			'content:read',
			'content:write',
			'taxonomy:write',
			'media:read',
			'media:write',
			'options:read',
			'options:write',
			'extensions:read',
			'extensions:write',
			'fs:read',
			'fs:write',
			'db:read',
			'builder:write',
			'maintenance'
		],
		none: []
	};

	document.addEventListener( 'click', function ( event ) {
		var copy = event.target.closest( '.kaiv-copy' );

		if ( copy ) {
			handleCopy( copy );
			return;
		}

		var preset = event.target.closest( '.kaiv-preset' );

		if ( preset ) {
			applyPreset( preset.dataset.preset );
			return;
		}

		var tab = event.target.closest( '.kaiv-tab-button' );

		if ( tab ) {
			selectTab( tab );
		}
	} );

	/**
	 * Show the panel belonging to a clicked tab button.
	 *
	 * @param {HTMLElement} button Tab button.
	 */
	function selectTab( button ) {
		var wrapper = button.closest( '.kaiv-tabs' );

		if ( ! wrapper ) {
			return;
		}

		var wanted = button.dataset.tab;

		wrapper.querySelectorAll( '.kaiv-tab-button' ).forEach( function ( el ) {
			el.classList.toggle( 'is-active', el === button );
		} );

		wrapper.querySelectorAll( '.kaiv-tab-panel' ).forEach( function ( el ) {
			el.classList.toggle( 'is-active', el.dataset.tab === wanted );
		} );
	}

	/**
	 * Copy the value of the input this button points at.
	 *
	 * @param {HTMLElement} button Copy button.
	 */
	function handleCopy( button ) {
		var input = document.getElementById( button.dataset.target );

		if ( ! input ) {
			return;
		}

		var done = function () {
			var original = button.textContent;

			button.textContent = 'Copied';
			button.classList.add( 'kaiv-copied' );

			window.setTimeout( function () {
				button.textContent = original;
				button.classList.remove( 'kaiv-copied' );
			}, 1600 );
		};

		if ( navigator.clipboard && window.isSecureContext ) {
			// writeText() rejects when the document is not focused or the user
			// has blocked clipboard access. Without a rejection handler the
			// button silently does nothing, and this is the only time the token
			// is ever shown.
			navigator.clipboard.writeText( input.value ).then( done, function () {
				window.prompt( 'Copy this value:', input.value );
			} );
			return;
		}

		// Fallback for plain-HTTP local installs, where the async API is absent.
		input.select();
		input.setSelectionRange( 0, input.value.length );

		try {
			document.execCommand( 'copy' );
			done();
		} catch ( error ) {
			window.prompt( 'Copy this value:', input.value );
		}
	}

	/**
	 * Tick the scopes belonging to a preset, untick everything else.
	 *
	 * @param {string} name Preset key.
	 */
	function applyPreset( name ) {
		var wanted = PRESETS[ name ] || [];
		var boxes = document.querySelectorAll( '.kaiv-scopes input[type="checkbox"]' );

		Array.prototype.forEach.call( boxes, function ( box ) {
			box.checked = wanted.indexOf( box.value ) !== -1;
		} );
	}
}() );
