<?php
/**
 * Plugin Name:       KAI Vibe
 * Plugin URI:        https://example.com/kai-vibe
 * Description:       Turns this WordPress site into a native MCP (Model Context Protocol) server, so AI agents can read, build and manage the site over an authenticated, scoped, fully audited connection.
 * Version:           0.2.0
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            KAI
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       kai-vibe
 *
 * @package KaiVibe
 */

defined( 'ABSPATH' ) || exit;

define( 'KAIV_VERSION', '0.2.0' );
define( 'KAIV_FILE', __FILE__ );
define( 'KAIV_DIR', plugin_dir_path( __FILE__ ) );
define( 'KAIV_URL', plugin_dir_url( __FILE__ ) );
define( 'KAIV_SLUG', 'kai-vibe' );

/**
 * REST namespace the MCP endpoint lives under.
 * Full endpoint: /wp-json/kai-vibe/v1/mcp
 */
define( 'KAIV_REST_NS', 'kai-vibe/v1' );

require_once KAIV_DIR . 'includes/class-autoloader.php';
KaiVibe\Autoloader::register();

require_once KAIV_DIR . 'includes/functions.php';

register_activation_hook( __FILE__, array( 'KaiVibe\Installer', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'KaiVibe\Installer', 'deactivate' ) );

/**
 * Main plugin instance.
 *
 * @return KaiVibe\Plugin
 */
function kaiv() {
	return KaiVibe\Plugin::instance();
}

kaiv()->boot();
