=== KAI Vibe ===
Contributors: kai
Tags: ai, mcp, claude, automation, assistant
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 0.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Let an AI assistant work on your site. Ask in plain English — it writes posts, fixes pages and tidies up, with your approval and full undo.

== Description ==

KAI Vibe connects your WordPress site to an AI assistant such as Claude, so you can ask for things in plain English instead of clicking through the dashboard yourself.

You might say:

* "Draft a blog post about our new opening hours, and match the style of my last three posts."
* "The About page looks broken. Work out why and fix it."
* "Find every page that still mentions our old phone number and update it."
* "Add alt text to any image that is missing it."
* "Which of my plugins are out of date?"

The assistant does the work on your site, and you stay in charge of it.

= You stay in control =

**It asks before anything risky.** Deleting things, installing plugins, changing your theme, editing files — these stop and wait for you to approve them in your dashboard. Approving one lets the assistant do that one thing, once.

**You can undo it.** Every change is saved along with a copy of what was there before. If something goes wrong, press Undo. This covers ground that WordPress revisions do not, including plugin settings, categories and theme files.

**It cannot do more than you allow.** Each key you create is limited to the jobs you tick, and to the permissions of the WordPress user you point it at. Give it an editor account and it can never install a plugin, no matter what it is asked.

**You can see everything it did.** The Activity screen records every action, with a timestamp. Nothing happens invisibly.

= Nothing is sent to us =

There is no middleman service. Your site talks directly to the AI assistant you choose, and the connection is served by WordPress itself. KAI Vibe has no servers, collects no analytics and phones nothing home. Your content only ever goes to the assistant you connect, and only when you ask it something.

Passwords are never readable. Settings that look like API keys or secrets are hidden from the assistant, and a small set of critical options — your site address, your admin email, your registration settings — can never be changed this way at all.

= What it can help with =

* **Writing** — draft posts and pages, write excerpts, set categories and tags
* **Fixing** — diagnose a broken page, search and replace across your content
* **Images** — upload, organise, and add missing alt text
* **Housekeeping** — clear caches, check scheduled tasks, review the error log
* **Reviewing** — site health checks, out-of-date plugins, what changed this week
* **Shops** — products, orders and sales reports, if you use WooCommerce
* **Page builders** — Elementor, Divi, Beaver Builder, Bricks, Breakdance, Oxygen and WPBakery layouts are read and written properly, rather than being broken by a naive edit

Advanced options for developers — direct database queries and WP-CLI commands — are switched off by default. Most people never need to turn them on.

= Connecting takes two button presses =

Copy one line — your site's address for AI — and paste it into the assistant. It asks WordPress who you are, you log in if you are not already, and you press Connect. That is the whole thing. There is no key to find, no configuration file to edit and nothing to copy back.

The connection acts as the WordPress account that approved it, so it can do exactly what that person can do and nothing more. You can see every connected assistant, and disconnect any of them, on the Tokens screen.

= Which assistants work with it? =

Any app that supports MCP (Model Context Protocol), including Claude, ChatGPT, Claude Code, Cursor, VS Code, Windsurf and automation tools such as n8n. Apps sign themselves in using OAuth, which every one of them speaks, so there is nothing product-specific to set up. A few tools can only read a fixed key from a settings file; for those, you can still make a key by hand and tick exactly which jobs it may do.

== Installation ==

1. Install and activate the plugin.
2. Go to **KAI Vibe** in your dashboard.
3. Follow the three steps on screen: create a key, copy your site address, and paste both into your AI assistant.

Your site needs to be on HTTPS. Almost all hosts offer a free SSL certificate — if yours is not switched on, ask your host before you start. KAI Vibe will not accept a connection over an unencrypted link, because your key would be readable in transit.

== Frequently Asked Questions ==

= Do I need to be technical to use this? =

No. Creating a key is one screen with a couple of choices on it, and the plugin shows you exactly what to paste where for each assistant. After that you just talk to your assistant normally.

= Is my site safe? =

You decide how much access to give. Start with the "Content editor" preset, which lets the assistant write and edit content but nothing else, and leave approvals switched on. You can revoke a key instantly at any time, or switch off all connections with a single tick box.

= What happens if the AI gets something wrong? =

Open **KAI Vibe → Changes** and press Undo on the change you want reversed. The previous version is stored for every edit, including things WordPress does not normally keep history for.

= Will it publish things without asking? =

New posts are created as drafts unless you specifically ask for them to be published. Deleting, installing and other risky actions always stop for your approval while approvals are switched on.

= Can I give it to a client or a team member? =

Yes. Create a separate key for each person or assistant, with its own permissions and expiry date. The Activity log shows which key did what, so you can always tell them apart.

= Does this work with WooCommerce? =

Yes. Products, orders, coupons and sales reports are all supported, and those tools only appear when WooCommerce is active. Everything goes through WooCommerce's own functions, so stock levels and totals stay correct.

= Does it work with my page builder? =

Elementor, Divi, Beaver Builder, Bricks, Breakdance, Oxygen and WPBakery are all recognised. This matters more than it sounds: those builders do not store layouts in the normal place, so an assistant that does not know about them will quietly wreck your design. KAI Vibe reads and writes each one properly and clears its cache afterwards.

= Do you see my content? =

No. There is no service in the middle. Your site connects straight to the assistant you chose.

= What is MCP? =

Model Context Protocol — an open standard for letting AI assistants use outside tools. You do not need to understand it to use this plugin.

= Can I remove it cleanly? =

Yes. Deleting the plugin destroys every key and removes all of its data and database tables.

== Screenshots ==

1. The Connect screen: three steps, plus examples of what to ask.
2. Creating a key, with plain-language permissions and one-click presets.
3. The approval queue, where risky actions wait for you.
4. The change log, with one-click Undo on anything the assistant did.
5. The activity log, showing every action taken.

== Changelog ==

= 0.1.2 =
* Rewrote the Connect screen as three plain-English steps, with setup instructions for each AI app, examples of what to ask for, and the technical detail folded away for those who want it.
* Added a plain-language explanation of what keeps your site safe.
* Escaping and input handling tightened throughout the admin screens.
* Added the full licence text.

= 0.1.1 =
* Impossible operations are now refused before the approval queue sees them, so you are never asked to approve something that could not have worked.
* Reading a page builder layout no longer needs write permission.
* Corrected two details reported on the status screen.
* Tested against WordPress 7.1.

= 0.1.0 =
* First release. MCP server built into WordPress, scoped keys, approval gate for risky actions, full undo history, activity log, and tools covering content, media, users, files, page builders and WooCommerce.

== Upgrade Notice ==

= 0.1.2 =
Much clearer setup: three simple steps, instructions for each AI app, and examples of what to ask for.
