<?php
/**
 * The permission vocabulary tokens are issued against.
 *
 * Scopes are the *first* gate. WordPress capabilities of the acting user are
 * the second — a token can never grant more than its user already has.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Auth;

defined( 'ABSPATH' ) || exit;

class Scopes {

	const WILDCARD = '*';

	/**
	 * scope => array( label, description, risk )
	 * Risk drives the colour coding in wp-admin and whether the approval gate applies.
	 *
	 * @return array<string,array>
	 */
	public static function all() {
		$scopes = array(
			'site:read'        => array( 'Site info', 'Read site settings, health, environment and registered types.', 'low' ),
			'content:read'     => array( 'Read content', 'Read posts, pages, any post type, revisions and meta.', 'low' ),
			'content:write'    => array( 'Write content', 'Create, update, trash and restore posts of any type.', 'medium' ),
			'taxonomy:write'   => array( 'Write taxonomies', 'Create and edit categories, tags and custom terms.', 'medium' ),
			'media:read'       => array( 'Read media', 'Browse and search the media library.', 'low' ),
			'media:write'      => array( 'Write media', 'Upload, sideload and delete attachments.', 'medium' ),
			'comments:read'    => array( 'Read comments', 'Read comments and moderation queue.', 'low' ),
			'comments:write'   => array( 'Moderate comments', 'Approve, spam, trash and reply to comments.', 'medium' ),
			'users:read'       => array( 'Read users', 'List users and their roles. Never exposes password hashes.', 'medium' ),
			'users:write'      => array( 'Write users', 'Create users, change roles and profile fields.', 'high' ),
			'options:read'     => array( 'Read options', 'Read the options table, excluding the secret denylist.', 'medium' ),
			'options:write'    => array( 'Write options', 'Update site options. Protected options stay locked.', 'high' ),
			'extensions:read'  => array( 'Read plugins/themes', 'List installed plugins and themes and their status.', 'low' ),
			'extensions:write' => array( 'Manage plugins/themes', 'Install, activate, deactivate, update and delete.', 'high' ),
			'fs:read'          => array( 'Read files', 'Read and search files inside the allowed roots.', 'medium' ),
			'fs:write'         => array( 'Write files', 'Create, edit and delete files inside the allowed roots.', 'high' ),
			'cli:run'          => array( 'Run WP-CLI', 'Execute WP-CLI commands on the server.', 'high' ),
			'db:read'          => array( 'Read database', 'Run SELECT queries against the database.', 'high' ),
			'db:write'         => array( 'Write database', 'Run INSERT/UPDATE/DELETE/DDL statements.', 'critical' ),
			'builder:write'    => array( 'Page builders', 'Read and write Elementor, Divi, Bricks and friends.', 'medium' ),
			'woo:read'         => array( 'Read WooCommerce', 'Products, orders, customers, coupons and reports.', 'medium' ),
			'woo:write'        => array( 'Write WooCommerce', 'Create and edit products, orders and coupons.', 'high' ),
			'maintenance'      => array( 'Maintenance', 'Flush caches, rewrite rules, cron and transients.', 'medium' ),
		);

		/**
		 * Filter the scope vocabulary. Add scopes for your own tool packs here.
		 *
		 * @param array $scopes Scope definitions.
		 */
		return apply_filters( 'kaiv_scopes', $scopes );
	}

	/**
	 * @return string[]
	 */
	public static function keys() {
		return array_keys( self::all() );
	}

	/**
	 * @param string $scope Scope key.
	 * @return string One of low|medium|high|critical.
	 */
	public static function risk( $scope ) {
		$all = self::all();
		return isset( $all[ $scope ][2] ) ? $all[ $scope ][2] : 'high';
	}

	/**
	 * @param string $scope Scope key.
	 * @return string
	 */
	public static function label( $scope ) {
		$all = self::all();
		return isset( $all[ $scope ][0] ) ? $all[ $scope ][0] : $scope;
	}

	/**
	 * Does a granted set satisfy a required scope?
	 *
	 * Supports the "*" wildcard and prefix wildcards such as "content:*".
	 *
	 * @param string[] $granted  Scopes on the token.
	 * @param string   $required Scope the tool needs.
	 * @return bool
	 */
	public static function satisfies( array $granted, $required ) {
		if ( '' === $required || null === $required ) {
			return true;
		}
		if ( in_array( self::WILDCARD, $granted, true ) ) {
			return true;
		}
		if ( in_array( $required, $granted, true ) ) {
			return true;
		}

		$prefix = strtok( $required, ':' );
		return in_array( $prefix . ':*', $granted, true );
	}

	/**
	 * Drop anything that is not a known scope.
	 *
	 * @param mixed $scopes Raw input.
	 * @return string[]
	 */
	public static function sanitize( $scopes ) {
		$scopes = is_array( $scopes ) ? $scopes : array_map( 'trim', explode( ',', (string) $scopes ) );
		$known  = self::keys();
		$clean  = array();

		foreach ( $scopes as $scope ) {
			$scope = strtolower( trim( (string) $scope ) );
			if ( self::WILDCARD === $scope || in_array( $scope, $known, true ) ) {
				$clean[] = $scope;
			} elseif ( preg_match( '/^[a-z]+:\*$/', $scope ) ) {
				$clean[] = $scope;
			}
		}

		return array_values( array_unique( $clean ) );
	}
}
