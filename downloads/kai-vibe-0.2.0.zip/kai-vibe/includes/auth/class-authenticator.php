<?php
/**
 * Bearer authentication for the MCP endpoint.
 *
 * Rather than inventing a parallel permission system, a verified token is
 * resolved to a real WordPress user and handed to determine_current_user.
 * From that point on, every core capability check — current_user_can(),
 * map_meta_cap, post type permissions, WooCommerce, everything — applies
 * exactly as it would for a logged-in human. Scopes narrow that further;
 * they can never widen it.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Auth;

defined( 'ABSPATH' ) || exit;

class Authenticator {

	/** @var Authenticator|null */
	private static $instance = null;

	/** @var array|null Verified token record for this request. */
	private $token = null;

	/** @var \WP_Error|null Deferred auth failure, surfaced during REST dispatch. */
	private $error = null;

	/** @var bool Guards against determine_current_user recursion. */
	private $resolving = false;

	/** @var bool */
	private $attempted = false;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function hooks() {
		add_filter( 'determine_current_user', array( $this, 'determine_current_user' ), 20 );
		add_filter( 'rest_authentication_errors', array( $this, 'rest_authentication_errors' ), 20 );

		// A KAI Vibe token is a credential for the MCP endpoint and nothing
		// else. Everything this plugin promises — scopes, the approval gate,
		// the rate limiter, the journal — lives inside that endpoint, so a
		// token that could authenticate core REST routes or wp-admin would
		// walk straight past all of it.
		add_filter( 'rest_pre_dispatch', array( $this, 'confine_to_mcp' ), 10, 3 );

		// Application Passwords are refused over plain HTTP; our tokens follow
		// the same rule unless the site explicitly opts out for local dev.
		add_filter( 'kaiv_require_https', array( $this, 'default_https_requirement' ), 5 );
	}

	/**
	 * The token record backing this request, if any.
	 *
	 * @return array|null
	 */
	public function token() {
		return $this->token;
	}

	/**
	 * True while the token is mid-resolution.
	 *
	 * Anything called from inside determine_current_user must not ask for the
	 * current user, or it re-enters this filter before the answer exists.
	 *
	 * @return bool
	 */
	public function is_resolving() {
		return $this->resolving;
	}

	/**
	 * @return string
	 */
	public function token_id() {
		return $this->token ? (string) $this->token['id'] : '';
	}

	/**
	 * Scopes granted to this request.
	 *
	 * @return string[]
	 */
	public function scopes() {
		return $this->token ? (array) $this->token['scopes'] : array();
	}

	/**
	 * @param string $scope Scope to test.
	 * @return bool
	 */
	public function has_scope( $scope ) {
		return Scopes::satisfies( $this->scopes(), $scope );
	}

	/**
	 * Resolve the bearer token to a user id.
	 *
	 * @param int|false $user_id Value from earlier filters.
	 * @return int|false
	 */
	public function determine_current_user( $user_id ) {
		if ( $this->resolving || $this->attempted ) {
			return $user_id;
		}

		// Never let a token stand in for a login on an ordinary page request.
		if ( ! defined( 'REST_REQUEST' ) || ! REST_REQUEST ) {
			return $user_id;
		}

		$presented = $this->read_token_from_request();

		// Only ever act on our own tokens. Any other bearer token on this site
		// belongs to another plugin (JWT auth and friends) and must be left
		// alone, or every REST request it authenticates would be turned into a
		// 401 by rest_authentication_errors() below.
		if ( ! $presented || 0 !== strpos( $presented, TokenManager::PREFIX ) ) {
			return $user_id;
		}

		$this->resolving = true;
		$this->attempted = true;

		$result = $this->authenticate( $presented );

		$this->resolving = false;

		if ( is_wp_error( $result ) ) {
			$this->error = $result;
			return $user_id;
		}

		$this->token = $result;

		return (int) $result['user_id'];
	}

	/**
	 * Run every gate the token has to pass.
	 *
	 * @param string $presented Raw token.
	 * @return array|\WP_Error
	 */
	private function authenticate( $presented ) {
		if ( ! kaiv_setting( 'enabled', true ) ) {
			return new \WP_Error( 'kaiv_disabled', __( 'The MCP endpoint is switched off for this site.', 'kai-vibe' ), array( 'status' => 503 ) );
		}

		if ( apply_filters( 'kaiv_require_https', true ) && ! is_ssl() && ! $this->is_local_environment() ) {
			return new \WP_Error( 'kaiv_https_required', __( 'Tokens may only be sent over HTTPS.', 'kai-vibe' ), array( 'status' => 403 ) );
		}

		$ip = self::client_ip();
		if ( ! $this->ip_allowed( $ip ) ) {
			kaiv_audit( 'auth.ip_blocked', array( 'ip' => $ip ) );
			return new \WP_Error( 'kaiv_ip_blocked', __( 'This IP address is not allowed to connect.', 'kai-vibe' ), array( 'status' => 403 ) );
		}

		$record = TokenManager::verify( $presented );
		if ( is_wp_error( $record ) ) {
			kaiv_audit( 'auth.failed', array( 'reason' => $record->get_error_code(), 'ip' => $ip ) );
			return $record;
		}

		TokenManager::touch( $record['id'], $ip );

		return $record;
	}

	/**
	 * Refuse to let a token drive any route but our own.
	 *
	 * @param mixed            $result  Pre-dispatch result.
	 * @param \WP_REST_Server  $server  Server.
	 * @param \WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function confine_to_mcp( $result, $server, $request ) {
		if ( ! $this->token || ! $request instanceof \WP_REST_Request ) {
			return $result;
		}

		$route  = ltrim( (string) $request->get_route(), '/' );
		$prefix = trim( KAIV_REST_NS, '/' ) . '/mcp';

		if ( 0 === strpos( $route, $prefix ) ) {
			return $result;
		}

		return new \WP_Error(
			'kaiv_wrong_endpoint',
			__( 'This token only works against the KAI Vibe endpoint.', 'kai-vibe' ),
			array( 'status' => 403 )
		);
	}

	/**
	 * Surface a deferred auth error, and block unauthenticated MCP calls.
	 *
	 * @param \WP_Error|null|bool $result Existing result.
	 * @return \WP_Error|null|bool
	 */
	public function rest_authentication_errors( $result ) {
		if ( ! empty( $result ) ) {
			return $result;
		}

		if ( $this->error ) {
			return $this->error;
		}

		return $result;
	}

	/**
	 * Pull the token out of the request, tolerating hosts that mangle headers.
	 *
	 * @return string
	 */
	private function read_token_from_request() {
		$candidates = array();

		foreach ( array( 'HTTP_AUTHORIZATION', 'REDIRECT_HTTP_AUTHORIZATION', 'HTTP_X_AUTHORIZATION' ) as $key ) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				$candidates[] = wp_unslash( $_SERVER[ $key ] );
			}
		}

		// Some FastCGI setups only expose it through getallheaders().
		if ( empty( $candidates ) && function_exists( 'getallheaders' ) ) {
			foreach ( (array) getallheaders() as $name => $value ) {
				if ( 0 === strcasecmp( $name, 'authorization' ) ) {
					$candidates[] = $value;
				}
			}
		}

		foreach ( $candidates as $header ) {
			if ( preg_match( '/^\s*Bearer\s+(\S+)\s*$/i', (string) $header, $m ) ) {
				return $m[1];
			}
		}

		// Explicit fallback header for hosts that strip Authorization outright.
		if ( ! empty( $_SERVER['HTTP_X_KAIV_TOKEN'] ) ) {
			return trim( wp_unslash( $_SERVER['HTTP_X_KAIV_TOKEN'] ) );
		}

		return '';
	}

	/**
	 * @param string $ip Client IP.
	 * @return bool
	 */
	private function ip_allowed( $ip ) {
		$allowlist = (array) kaiv_setting( 'ip_allowlist', array() );
		$allowlist = array_filter( array_map( 'trim', $allowlist ) );

		if ( empty( $allowlist ) ) {
			return true;
		}

		foreach ( $allowlist as $rule ) {
			if ( self::ip_matches( $ip, $rule ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Match an IP against a plain address or a CIDR block (v4 and v6).
	 *
	 * @param string $ip   Address to test.
	 * @param string $rule Address or CIDR.
	 * @return bool
	 */
	public static function ip_matches( $ip, $rule ) {
		if ( false === strpos( $rule, '/' ) ) {
			return $ip === $rule;
		}

		list( $subnet, $bits ) = explode( '/', $rule, 2 );

		$ip_bin     = @inet_pton( $ip );
		$subnet_bin = @inet_pton( $subnet );
		$bits       = (int) $bits;

		if ( false === $ip_bin || false === $subnet_bin || strlen( $ip_bin ) !== strlen( $subnet_bin ) ) {
			return false;
		}

		$whole = intdiv( $bits, 8 );
		$rest  = $bits % 8;

		if ( $whole > 0 && 0 !== substr_compare( $ip_bin, $subnet_bin, 0, $whole ) ) {
			return false;
		}

		if ( 0 === $rest ) {
			return true;
		}

		$mask = ~( ( 1 << ( 8 - $rest ) ) - 1 ) & 0xFF;

		return ( ord( $ip_bin[ $whole ] ) & $mask ) === ( ord( $subnet_bin[ $whole ] ) & $mask );
	}

	/**
	 * Best-effort client IP. Proxy headers are only trusted when the site opts in,
	 * because otherwise the IP allowlist would be trivially spoofable.
	 *
	 * @return string
	 */
	public static function client_ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '';

		if ( apply_filters( 'kaiv_trust_proxy_headers', false ) ) {
			foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR' ) as $key ) {
				if ( ! empty( $_SERVER[ $key ] ) ) {
					$value = wp_unslash( $_SERVER[ $key ] );
					$parts = explode( ',', $value );
					$ip    = trim( $parts[0] );
					break;
				}
			}
		}

		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
	}

	/**
	 * @param bool $require Current requirement.
	 * @return bool
	 */
	public function default_https_requirement( $require ) {
		return $this->is_local_environment() ? false : $require;
	}

	/**
	 * @return bool
	 */
	private function is_local_environment() {
		return in_array( wp_get_environment_type(), array( 'local', 'development' ), true );
	}
}
