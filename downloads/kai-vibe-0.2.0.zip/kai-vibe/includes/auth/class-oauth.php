<?php
/**
 * A small OAuth 2.1 authorization server, so connecting an AI assistant is
 * "paste the site address, press Connect, press Approve" and nothing else.
 *
 * The person connecting never sees a token, a scope list or a config file.
 * The assistant discovers everything it needs on its own:
 *
 *   1. It calls the MCP endpoint with no credentials.
 *   2. It gets a 401 carrying WWW-Authenticate: Bearer resource_metadata="…".
 *   3. It reads that document, which names this site as its own auth server.
 *   4. It registers itself (RFC 7591) — no client id to copy anywhere.
 *   5. It opens the browser at /authorize; WordPress asks the person to log in
 *      if they are not already, then shows one Approve button.
 *   6. It swaps the returned code for tokens (RFC 7636 PKCE, no client secret).
 *
 * Deliberately narrow: public clients only, PKCE always required, one grant
 * type for the handshake and one for renewal. There is no client secret to
 * leak, and every issued connection is an ordinary row on the Tokens screen
 * that the owner can disconnect with one click.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Auth;

defined( 'ABSPATH' ) || exit;

class OAuth {

	/** Registered client applications. */
	const CLIENTS_OPTION = 'kaiv_oauth_clients';

	/** Prefix for the transient holding a pending authorization code. */
	const CODE_PREFIX = 'kaiv_oauth_code_';

	/** How long an authorization code may be exchanged for. */
	const CODE_TTL = 120;

	/** How long an issued access token lives before it must be refreshed. */
	const TOKEN_TTL = HOUR_IN_SECONDS;

	/** @var OAuth|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function hooks() {
		// The well-known documents live at the domain root, above WordPress's
		// own routing, so they are served before the query is parsed.
		add_action( 'parse_request', array( $this, 'maybe_serve_well_known' ), 0 );

		// The consent screen deliberately does NOT live on the REST API.
		// WordPress resets a cookie-authenticated REST request to logged-out
		// unless it carries a wp_rest nonce, which a browser arriving from an
		// AI client never has — the screen would bounce to login forever. On a
		// normal front-end request the logged-in user is simply there.
		add_action( 'parse_request', array( $this, 'maybe_handle_authorize' ), 1 );

		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Where the browser is sent to approve a connection.
	 *
	 * A query argument rather than a pretty path, so it works the same on a
	 * site with no permalink rewrites at all.
	 *
	 * @return string
	 */
	public static function authorize_url() {
		return add_query_arg( 'kaiv_oauth', 'authorize', home_url( '/' ) );
	}

	/**
	 * Front-end entry point for the consent screen.
	 */
	public function maybe_handle_authorize() {
		if ( ! isset( $_GET['kaiv_oauth'] ) || 'authorize' !== $_GET['kaiv_oauth'] ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}

		$this->authorize();
		exit;
	}

	/**
	 * @return bool
	 */
	public static function enabled() {
		return (bool) kaiv_setting( 'oauth_enabled', true ) && (bool) kaiv_setting( 'enabled', true );
	}

	/**
	 * Capability a WordPress user needs before they may approve a connection.
	 *
	 * Whatever they approve is capped by their own role regardless, but a
	 * subscriber on a membership site has no business minting connections.
	 *
	 * @return string
	 */
	public static function connect_capability() {
		return (string) apply_filters( 'kaiv_connect_capability', 'edit_posts' );
	}

	/* ---------------------------------------------------------------------
	 * Discovery
	 * ------------------------------------------------------------------ */

	/**
	 * True when WordPress is installed at the domain root and can therefore
	 * answer requests for /.well-known/… itself.
	 *
	 * @return bool
	 */
	public static function owns_domain_root() {
		$path = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );

		return '' === $path || '/' === $path;
	}

	/**
	 * Where this resource's metadata document can actually be fetched.
	 *
	 * @return string
	 */
	public static function resource_metadata_url() {
		if ( self::owns_domain_root() ) {
			$path = (string) wp_parse_url( rest_url( KAIV_REST_NS . '/mcp' ), PHP_URL_PATH );

			return home_url( '/.well-known/oauth-protected-resource' . $path );
		}

		// Subdirectory install: advertise the copy we can serve ourselves. The
		// WWW-Authenticate header points clients straight at it.
		return rest_url( KAIV_REST_NS . '/.well-known/oauth-protected-resource' );
	}

	/**
	 * @return string
	 */
	public static function issuer() {
		return self::owns_domain_root() ? untrailingslashit( home_url( '/' ) ) : untrailingslashit( rest_url( KAIV_REST_NS ) );
	}

	/**
	 * RFC 9728: what this protected resource is and who authorises access.
	 *
	 * @return array
	 */
	public static function resource_metadata() {
		return array(
			'resource'                              => rest_url( KAIV_REST_NS . '/mcp' ),
			'authorization_servers'                 => array( self::issuer() ),
			'bearer_methods_supported'              => array( 'header' ),
			'scopes_supported'                      => array_keys( Scopes::all() ),
			'resource_name'                         => get_bloginfo( 'name' ),
		);
	}

	/**
	 * RFC 8414: how to drive this authorization server.
	 *
	 * @return array
	 */
	public static function server_metadata() {
		return array(
			'issuer'                                       => self::issuer(),
			'authorization_endpoint'                       => self::authorize_url(),
			'token_endpoint'                               => rest_url( KAIV_REST_NS . '/oauth/token' ),
			'registration_endpoint'                        => rest_url( KAIV_REST_NS . '/oauth/register' ),
			'revocation_endpoint'                          => rest_url( KAIV_REST_NS . '/oauth/revoke' ),
			'scopes_supported'                             => array_keys( Scopes::all() ),
			'response_types_supported'                     => array( 'code' ),
			'grant_types_supported'                        => array( 'authorization_code', 'refresh_token' ),
			'code_challenge_methods_supported'             => array( 'S256' ),
			'token_endpoint_auth_methods_supported'        => array( 'none' ),
			'revocation_endpoint_auth_methods_supported'   => array( 'none' ),
			'service_documentation'                        => 'https://modelcontextprotocol.io',
		);
	}

	/**
	 * Answer the root-level well-known requests before WordPress decides the
	 * URL is a 404.
	 */
	public function maybe_serve_well_known() {
		if ( ! self::owns_domain_root() ) {
			return;
		}

		$path = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$path = '/' . ltrim( $path, '/' );

		if ( 0 !== strpos( $path, '/.well-known/' ) ) {
			return;
		}

		// Clients differ on whether they append the resource path, and some
		// still probe the OpenID document, so answer every shape we can.
		$resource_doc = 0 === strpos( $path, '/.well-known/oauth-protected-resource' );
		$server_doc   = 0 === strpos( $path, '/.well-known/oauth-authorization-server' )
			|| 0 === strpos( $path, '/.well-known/openid-configuration' );

		if ( ! $resource_doc && ! $server_doc ) {
			return;
		}

		if ( ! self::enabled() ) {
			self::emit( array( 'error' => 'oauth_disabled' ), 404 );
		}

		self::emit( $resource_doc ? self::resource_metadata() : self::server_metadata(), 200 );
	}

	/**
	 * Send a JSON document and stop. Discovery has to be readable by a client
	 * that has no credentials yet, from any origin.
	 *
	 * @param array $body   Document.
	 * @param int   $status HTTP status.
	 */
	private static function emit( array $body, $status ) {
		if ( ! headers_sent() ) {
			status_header( $status );
			header( 'Content-Type: application/json; charset=' . get_option( 'blog_charset' ) );
			header( 'Cache-Control: public, max-age=300' );
			header( 'Access-Control-Allow-Origin: *' );
			header( 'Access-Control-Allow-Headers: Authorization, Content-Type, MCP-Protocol-Version' );
			header( 'Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS' );
		}

		echo wp_json_encode( $body, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT ); // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Routes
	 * ------------------------------------------------------------------ */

	public function register_routes() {
		$open = '__return_true';

		register_rest_route(
			KAIV_REST_NS,
			'/.well-known/oauth-protected-resource',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'handle_resource_metadata' ),
				'permission_callback' => $open,
			)
		);

		register_rest_route(
			KAIV_REST_NS,
			'/.well-known/oauth-authorization-server',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'handle_server_metadata' ),
				'permission_callback' => $open,
			)
		);

		register_rest_route(
			KAIV_REST_NS,
			'/oauth/register',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_register' ),
				'permission_callback' => $open,
			)
		);

		register_rest_route(
			KAIV_REST_NS,
			'/oauth/token',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_token' ),
				'permission_callback' => $open,
			)
		);

		register_rest_route(
			KAIV_REST_NS,
			'/oauth/revoke',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_revoke' ),
				'permission_callback' => $open,
			)
		);
	}

	/**
	 * @return \WP_REST_Response
	 */
	public function handle_resource_metadata() {
		return new \WP_REST_Response( self::resource_metadata(), self::enabled() ? 200 : 404 );
	}

	/**
	 * @return \WP_REST_Response
	 */
	public function handle_server_metadata() {
		return new \WP_REST_Response( self::server_metadata(), self::enabled() ? 200 : 404 );
	}

	/* ---------------------------------------------------------------------
	 * Dynamic client registration (RFC 7591)
	 * ------------------------------------------------------------------ */

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public function handle_register( $request ) {
		if ( ! self::enabled() ) {
			return self::oauth_error( 'access_denied', __( 'One-click connection is switched off for this site.', 'kai-vibe' ), 403 );
		}

		$body = json_decode( (string) $request->get_body(), true );
		$body = is_array( $body ) ? $body : $request->get_params();

		// Unauthenticated endpoint: throttle it, or it is a free write primitive.
		$throttle = 'kaiv_reg_' . md5( (string) Authenticator::client_ip() );
		$attempts = (int) get_transient( $throttle );

		if ( $attempts >= (int) apply_filters( 'kaiv_max_registrations_per_hour', 20 ) ) {
			return self::oauth_error( 'temporarily_unavailable', __( 'Too many registrations from this address. Try again later.', 'kai-vibe' ), 429 );
		}

		set_transient( $throttle, $attempts + 1, HOUR_IN_SECONDS );

		$redirect_uris = isset( $body['redirect_uris'] ) ? (array) $body['redirect_uris'] : array();
		$redirect_uris = array_slice( $redirect_uris, 0, 5 );
		$redirect_uris = array_values( array_unique( array_filter( array_map( array( $this, 'clean_redirect_uri' ), $redirect_uris ) ) ) );

		if ( empty( $redirect_uris ) ) {
			return self::oauth_error( 'invalid_redirect_uri', __( 'At least one usable redirect_uri is required.', 'kai-vibe' ), 400 );
		}

		$client_id = 'kaivc_' . bin2hex( random_bytes( 12 ) );

		$client = array(
			'client_id'     => $client_id,
			'client_name'   => isset( $body['client_name'] )
				? self::clip( sanitize_text_field( (string) $body['client_name'] ), 120 )
				: __( 'AI assistant', 'kai-vibe' ),
			'client_uri'    => isset( $body['client_uri'] ) ? self::clip( esc_url_raw( (string) $body['client_uri'] ), 500 ) : '',
			'logo_uri'      => isset( $body['logo_uri'] ) ? self::clip( esc_url_raw( (string) $body['logo_uri'] ), 500 ) : '',
			'redirect_uris' => $redirect_uris,
			'created'       => time(),
			'last_used'     => 0,
		);

		if ( '' === $client['client_name'] ) {
			$client['client_name'] = __( 'AI assistant', 'kai-vibe' );
		}

		// Prune before every insert, not only past an arbitrary count, and let
		// prune_clients() enforce the ceiling by eviction rather than hoping.
		$clients               = self::prune_clients( self::clients() );
		$clients[ $client_id ] = $client;

		update_option( self::CLIENTS_OPTION, $clients, false );

		kaiv_audit( 'oauth.client_registered', array( 'client_id' => $client_id, 'client_name' => $client['client_name'] ) );

		$response = new \WP_REST_Response(
			array(
				'client_id'                  => $client_id,
				'client_name'                => $client['client_name'],
				'redirect_uris'              => $redirect_uris,
				'grant_types'                => array( 'authorization_code', 'refresh_token' ),
				'response_types'             => array( 'code' ),
				'token_endpoint_auth_method' => 'none',
				'client_id_issued_at'        => $client['created'],
			),
			201
		);

		$response->header( 'Cache-Control', 'no-store' );

		return $response;
	}

	/**
	 * Accept only redirect targets that cannot be used to bounce a code to a
	 * stranger: https, or the loopback and custom-scheme URLs desktop clients
	 * legitimately use.
	 *
	 * @param mixed $uri Candidate.
	 * @return string Empty string when unusable.
	 */
	public function clean_redirect_uri( $uri ) {
		$uri = trim( (string) $uri );

		if ( '' === $uri || strlen( $uri ) > 2000 ) {
			return '';
		}

		$parts = wp_parse_url( $uri );

		if ( empty( $parts['scheme'] ) ) {
			return '';
		}

		$scheme = strtolower( $parts['scheme'] );
		$host   = isset( $parts['host'] ) ? strtolower( $parts['host'] ) : '';

		if ( 'https' === $scheme ) {
			return $uri;
		}

		if ( 'http' === $scheme && in_array( $host, array( '127.0.0.1', '[::1]', 'localhost' ), true ) ) {
			return $uri;
		}

		// A private-use scheme such as cursor:// or vscode://, which has no
		// host and cannot be opened by a remote attacker.
		if ( ! in_array( $scheme, array( 'http', 'https', 'javascript', 'data', 'file', 'vbscript' ), true ) && false !== strpos( $uri, ':' ) ) {
			return $uri;
		}

		return '';
	}

	/* ---------------------------------------------------------------------
	 * Authorization
	 * ------------------------------------------------------------------ */

	/**
	 * The one screen a person actually sees. A plain GET renders it; the
	 * Approve or Deny button posts back to the same URL.
	 */
	public function authorize() {
		if ( ! self::enabled() ) {
			self::render_failure( __( 'One-click connection is switched off for this site.', 'kai-vibe' ) );
		}

		$get  = wp_unslash( $_GET );  // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput
		$post = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput

		// An array where a string belongs is always a probe, never a client.
		$read = static function ( $source, $key, $limit = 1024 ) {
			if ( ! isset( $source[ $key ] ) || ! is_scalar( $source[ $key ] ) ) {
				return '';
			}

			return (string) substr( (string) $source[ $key ], 0, $limit );
		};

		$client_id     = sanitize_text_field( $read( $get, 'client_id', 64 ) );
		$redirect_uri  = $read( $get, 'redirect_uri', 2000 );
		$state         = $read( $get, 'state', 512 );
		$challenge     = $read( $get, 'code_challenge', 256 );
		$method        = strtoupper( $read( $get, 'code_challenge_method', 16 ) );
		$resource      = $read( $get, 'resource', 2000 );
		$response_type = $read( $get, 'response_type', 32 );

		$client = self::client( $client_id );

		// Nothing below may redirect to $redirect_uri until it has been matched
		// against the registration, and nothing may redirect at all until a
		// logged-in human is on the other end — otherwise this endpoint is an
		// open redirect that anyone can arm with one unauthenticated POST.
		if ( ! $client || ! in_array( $redirect_uri, $client['redirect_uris'], true ) ) {
			self::render_failure( __( 'That app asked to be sent somewhere this site does not recognise, so the connection was stopped. Ask it to connect again from the beginning.', 'kai-vibe' ) );
		}

		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( self::current_url() ) );
			exit;
		}

		if ( ! current_user_can( self::connect_capability() ) ) {
			self::render_failure(
				__( 'Your WordPress account is not allowed to connect an assistant to this site. Ask an administrator to do it.', 'kai-vibe' )
			);
		}

		// A human is present and the destination is one the app registered, so
		// protocol errors can now safely be reported back to the app.
		if ( 'code' !== $response_type ) {
			self::redirect_error( $redirect_uri, 'unsupported_response_type', $state );
		}

		// PKCE is not optional here. Without it a stolen code is enough.
		if ( '' === $challenge || 'S256' !== $method ) {
			self::redirect_error( $redirect_uri, 'invalid_request', $state );
		}

		$user = wp_get_current_user();

		// get_method() honours _method and X-HTTP-Method-Override, so it is not
		// proof of anything. Only a real POST carrying a real nonce decides.
		$is_post = isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === strtoupper( (string) $_SERVER['REQUEST_METHOD'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

		if ( $is_post ) {
			if ( ! wp_verify_nonce( $read( $post, 'kaiv_nonce', 128 ), 'kaiv_authorize' ) ) {
				self::render_failure( __( 'That approval form expired. Start the connection again.', 'kai-vibe' ) );
			}

			if ( '' === $read( $post, 'approve', 8 ) ) {
				kaiv_audit( 'oauth.denied', array( 'client_id' => $client_id, 'client_name' => $client['client_name'] ) );
				self::redirect_error( $redirect_uri, 'access_denied', $state );
			}

			$code = 'kaivac_' . bin2hex( random_bytes( 24 ) );

			set_transient(
				self::CODE_PREFIX . $code,
				array(
					'client_id'    => $client_id,
					'user_id'      => (int) $user->ID,
					'redirect_uri' => $redirect_uri,
					'challenge'    => $challenge,
					'resource'     => $resource,
					'issued'       => time(),
				),
				self::CODE_TTL
			);

			kaiv_audit(
				'oauth.approved',
				array(
					'client_id'   => $client_id,
					'client_name' => $client['client_name'],
					'acts_as'     => $user->user_login,
				)
			);

			self::redirect_to_client( $redirect_uri, array( 'code' => $code ), $state );
		}

		self::render_consent( $client, $user, $redirect_uri );
	}

	/**
	 * The consent screen. One sentence about what is being connected, one
	 * sentence about what it will be able to do, and two buttons.
	 *
	 * @param array    $client Registered client.
	 * @param \WP_User $user   Approving user.
	 */
	private static function render_consent( array $client, $user, $redirect_uri ) {
		$roles = array_map(
			static function ( $role ) {
				$names = wp_roles()->get_names();
				return isset( $names[ $role ] ) ? translate_user_role( $names[ $role ] ) : $role;
			},
			(array) $user->roles
		);

		$view = KAIV_DIR . 'includes/admin/views/consent.php';

		$kaiv_client   = $client;
		$kaiv_user     = $user;
		$kaiv_roles    = $roles;
		$kaiv_redirect = $redirect_uri;

		nocache_headers();
		status_header( 200 );
		header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );

		require $view;
		exit;
	}

	/**
	 * A dead end the person can read, for the cases where bouncing them back
	 * to the app would be unsafe or pointless.
	 *
	 * @param string $message Plain-language explanation.
	 */
	private static function render_failure( $message ) {
		$kaiv_message = $message;

		nocache_headers();
		status_header( 400 );
		header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );

		require KAIV_DIR . 'includes/admin/views/consent-failed.php';
		exit;
	}

	/**
	 * @param string $redirect_uri Validated redirect target.
	 * @param string $error        OAuth error code.
	 * @param string $state        Client state.
	 */
	private static function redirect_error( $redirect_uri, $error, $state ) {
		self::redirect_to_client( $redirect_uri, array( 'error' => $error ), $state );
	}

	/**
	 * Hand the browser back to the app.
	 *
	 * add_query_arg() does not percent-encode what you give it, so an "&" or a
	 * "#" inside state would otherwise let the app's callback URL be rewritten.
	 *
	 * @param string $redirect_uri Validated redirect target.
	 * @param array  $args         Query arguments to append.
	 * @param string $state        Client state, echoed back verbatim.
	 */
	private static function redirect_to_client( $redirect_uri, array $args, $state ) {
		if ( '' !== $state ) {
			$args['state'] = $state;
		}

		$target = add_query_arg( array_map( 'rawurlencode', $args ), $redirect_uri );

		wp_redirect( $target ); // phpcs:ignore WordPress.Security.SafeRedirect -- Already validated against the client's registered redirect_uris.
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Token
	 * ------------------------------------------------------------------ */

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public function handle_token( $request ) {
		if ( ! self::enabled() ) {
			return self::oauth_error( 'invalid_request', __( 'One-click connection is switched off for this site.', 'kai-vibe' ), 403 );
		}

		$params = $request->get_params();
		$grant  = isset( $params['grant_type'] ) ? (string) $params['grant_type'] : '';

		if ( 'refresh_token' === $grant ) {
			return $this->grant_refresh( $params );
		}

		if ( 'authorization_code' === $grant ) {
			return $this->grant_code( $params );
		}

		return self::oauth_error( 'unsupported_grant_type', __( 'Only authorization_code and refresh_token are supported.', 'kai-vibe' ), 400 );
	}

	/**
	 * @param array $params Request params.
	 * @return \WP_REST_Response
	 */
	private function grant_code( array $params ) {
		$code     = isset( $params['code'] ) ? (string) $params['code'] : '';
		$verifier = isset( $params['code_verifier'] ) ? (string) $params['code_verifier'] : '';
		$client_id = isset( $params['client_id'] ) ? sanitize_text_field( (string) $params['client_id'] ) : '';

		$pending = $code ? get_transient( self::CODE_PREFIX . $code ) : false;

		// One use only: burn it before anything else can go wrong.
		if ( $code ) {
			delete_transient( self::CODE_PREFIX . $code );
		}

		if ( ! is_array( $pending ) ) {
			return self::oauth_error( 'invalid_grant', __( 'That authorization code is unknown or has already been used.', 'kai-vibe' ), 400 );
		}

		if ( $pending['client_id'] !== $client_id ) {
			return self::oauth_error( 'invalid_grant', __( 'That code was issued to a different app.', 'kai-vibe' ), 400 );
		}

		$sent = isset( $params['redirect_uri'] ) && is_scalar( $params['redirect_uri'] ) ? (string) $params['redirect_uri'] : '';

		if ( ! hash_equals( (string) $pending['redirect_uri'], $sent ) ) {
			return self::oauth_error( 'invalid_grant', __( 'The redirect_uri does not match the one the code was issued for.', 'kai-vibe' ), 400 );
		}

		if ( '' === $verifier || ! hash_equals( $pending['challenge'], self::s256( $verifier ) ) ) {
			return self::oauth_error( 'invalid_grant', __( 'The PKCE verifier does not match.', 'kai-vibe' ), 400 );
		}

		$client = self::client( $client_id );

		if ( ! $client ) {
			return self::oauth_error( 'invalid_client', __( 'That app is no longer registered.', 'kai-vibe' ), 400 );
		}

		$user = get_userdata( (int) $pending['user_id'] );

		if ( ! $user ) {
			return self::oauth_error( 'invalid_grant', __( 'The approving user no longer exists.', 'kai-vibe' ), 400 );
		}

		// The connection is capped by the approving user's own role, so it is
		// granted every scope and WordPress decides the rest.
		$issued = TokenManager::create(
			array(
				'label'       => $client['client_name'],
				'scopes'      => array_keys( Scopes::all() ),
				'user_id'     => (int) $user->ID,
				'expires'     => time() + self::TOKEN_TTL,
				'kind'        => TokenManager::KIND_OAUTH,
				'client_id'   => $client_id,
				'client_name' => $client['client_name'],
				'refresh'     => true,
				'created_by'  => (int) $user->ID,
			)
		);

		if ( is_wp_error( $issued ) ) {
			return self::oauth_error( 'server_error', $issued->get_error_message(), 500 );
		}

		self::touch_client( $client_id );

		kaiv_audit(
			'oauth.connected',
			array(
				'client_id'   => $client_id,
				'client_name' => $client['client_name'],
				'token_id'    => $issued['id'],
				'acts_as'     => $user->user_login,
			)
		);

		return self::token_response( $issued['token'], $issued['refresh'] );
	}

	/**
	 * @param array $params Request params.
	 * @return \WP_REST_Response
	 */
	private function grant_refresh( array $params ) {
		$presented = isset( $params['refresh_token'] ) ? (string) $params['refresh_token'] : '';

		$rotated = TokenManager::refresh( $presented, self::TOKEN_TTL );

		if ( is_wp_error( $rotated ) ) {
			return self::oauth_error( $rotated->get_error_code(), $rotated->get_error_message(), 400 );
		}

		if ( ! empty( $rotated['record']['client_id'] ) ) {
			self::touch_client( $rotated['record']['client_id'] );
		}

		return self::token_response( $rotated['token'], $rotated['refresh'] );
	}

	/**
	 * @param string $access  Access token.
	 * @param string $refresh Refresh token.
	 * @return \WP_REST_Response
	 */
	private static function token_response( $access, $refresh ) {
		$response = new \WP_REST_Response(
			array(
				'access_token'  => $access,
				'token_type'    => 'Bearer',
				'expires_in'    => self::TOKEN_TTL,
				'refresh_token' => $refresh,
				'scope'         => implode( ' ', array_keys( Scopes::all() ) ),
			),
			200
		);

		$response->header( 'Cache-Control', 'no-store' );
		$response->header( 'Pragma', 'no-cache' );

		return $response;
	}

	/* ---------------------------------------------------------------------
	 * Revocation
	 * ------------------------------------------------------------------ */

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public function handle_revoke( $request ) {
		$params    = $request->get_params();
		$presented = isset( $params['token'] ) && is_scalar( $params['token'] ) ? trim( (string) $params['token'] ) : '';

		// The whole credential has to check out. Revoking on the id half alone
		// would let anyone who ever glimpsed an id kill that connection.
		$record = TokenManager::verify( $presented );

		if ( is_wp_error( $record ) ) {
			$record = TokenManager::verify_refresh( $presented );
		}

		if ( ! is_wp_error( $record ) ) {
			TokenManager::revoke( $record['id'] );
		}

		// RFC 7009: an unknown token is still a success, so a client cannot
		// use this endpoint to find out which tokens exist.
		return new \WP_REST_Response( null, 200 );
	}

	/* ---------------------------------------------------------------------
	 * Clients
	 * ------------------------------------------------------------------ */

	/**
	 * @return array<string,array>
	 */
	public static function clients() {
		$clients = get_option( self::CLIENTS_OPTION, array() );

		return is_array( $clients ) ? $clients : array();
	}

	/**
	 * @param string $client_id Client id.
	 * @return array|null
	 */
	public static function client( $client_id ) {
		$clients = self::clients();

		return isset( $clients[ $client_id ] ) ? $clients[ $client_id ] : null;
	}

	/**
	 * @param string $client_id Client id.
	 */
	private static function touch_client( $client_id ) {
		$clients = self::clients();

		if ( ! isset( $clients[ $client_id ] ) ) {
			return;
		}

		$clients[ $client_id ]['last_used'] = time();
		update_option( self::CLIENTS_OPTION, $clients, false );
	}

	/**
	 * Drop registrations that were never completed. A client that registered
	 * and then connected has a last_used stamp and is always kept.
	 *
	 * @param array $clients Current clients.
	 * @return array
	 */
	private static function prune_clients( array $clients ) {
		$max = max( 10, (int) apply_filters( 'kaiv_max_oauth_clients', 100 ) );

		// A registration nobody completed is dead within the hour.
		$cutoff = time() - HOUR_IN_SECONDS;

		$kept = array_filter(
			$clients,
			static function ( $client ) use ( $cutoff ) {
				return ! empty( $client['last_used'] ) || (int) ( isset( $client['created'] ) ? $client['created'] : 0 ) > $cutoff;
			}
		);

		// Still over the ceiling: evict never-used rows oldest first. Without
		// this, a flood of fresh registrations survives every pass and the
		// option row grows without limit.
		if ( count( $kept ) >= $max ) {
			uasort(
				$kept,
				static function ( $a, $b ) {
					$a_used = empty( $a['last_used'] ) ? 0 : 1;
					$b_used = empty( $b['last_used'] ) ? 0 : 1;

					if ( $a_used !== $b_used ) {
						return $a_used <=> $b_used;
					}

					return (int) ( isset( $a['created'] ) ? $a['created'] : 0 ) <=> (int) ( isset( $b['created'] ) ? $b['created'] : 0 );
				}
			);

			$kept = array_slice( $kept, -( $max - 1 ), null, true );
		}

		return $kept;
	}

	/**
	 * @param string $value Value.
	 * @param int    $limit Maximum length.
	 * @return string
	 */
	private static function clip( $value, $limit ) {
		$value = (string) $value;

		return function_exists( 'mb_substr' ) ? mb_substr( $value, 0, $limit ) : substr( $value, 0, $limit );
	}

	/* ---------------------------------------------------------------------
	 * Helpers
	 * ------------------------------------------------------------------ */

	/**
	 * @param string $verifier PKCE verifier.
	 * @return string Base64url S256 challenge.
	 */
	private static function s256( $verifier ) {
		return rtrim( strtr( base64_encode( hash( 'sha256', $verifier, true ) ), '+/', '-_' ), '=' );
	}

	/**
	 * @return string
	 */
	private static function current_url() {
		$requested = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

		return home_url( '/' . ltrim( (string) $requested, '/' ) );
	}

	/**
	 * @param string $code    OAuth error code.
	 * @param string $message Human description.
	 * @param int    $status  HTTP status.
	 * @return \WP_REST_Response
	 */
	private static function oauth_error( $code, $message, $status ) {
		$response = new \WP_REST_Response(
			array(
				'error'             => $code,
				'error_description' => $message,
			),
			$status
		);

		$response->header( 'Cache-Control', 'no-store' );

		return $response;
	}
}
