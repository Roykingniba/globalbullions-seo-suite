<?php
/**
 * Issue, verify and revoke agent tokens.
 *
 * A token looks like:  kaiv_<12-char id>_<43-char secret>
 * Only an HMAC of the secret is stored, so a database dump does not yield
 * working credentials. The plaintext is shown exactly once, at creation.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Auth;

defined( 'ABSPATH' ) || exit;

class TokenManager {

	const OPTION = 'kaiv_tokens';
	const PREFIX = 'kaiv_';

	/** Refresh tokens carry their own prefix so the two can never be confused. */
	const REFRESH_PREFIX = 'kaivr_';

	/** A token the owner created by hand under KAI Vibe -> Tokens. */
	const KIND_MANUAL = 'manual';

	/** A token issued to an AI client through the OAuth flow. */
	const KIND_OAUTH = 'oauth';

	/** How long a connection may keep renewing itself before reconnecting. */
	const REFRESH_LIFETIME = 30 * DAY_IN_SECONDS;

	/**
	 * All stored token records, keyed by token id. Secrets are never included.
	 *
	 * @return array<string,array>
	 */
	public static function all() {
		$tokens = get_option( self::OPTION, array() );
		return is_array( $tokens ) ? $tokens : array();
	}

	/**
	 * @param string $id Token id.
	 * @return array|null
	 */
	public static function get( $id ) {
		$tokens = self::all();
		return isset( $tokens[ $id ] ) ? $tokens[ $id ] : null;
	}

	/**
	 * Mint a new token.
	 *
	 * @param array $args {
	 *     @type string   $label   Human label shown in wp-admin.
	 *     @type string[] $scopes  Granted scopes.
	 *     @type int      $user_id WordPress user the agent acts as.
	 *     @type int      $expires Unix timestamp, 0 for never.
	 * }
	 * @return array|\WP_Error { id, token (plaintext, once), record }
	 */
	public static function create( array $args ) {
		$args = wp_parse_args(
			$args,
			array(
				'label'       => __( 'Untitled agent', 'kai-vibe' ),
				'scopes'      => array( 'site:read', 'content:read' ),
				'user_id'     => get_current_user_id(),
				'expires'     => 0,
				'kind'        => self::KIND_MANUAL,
				'client_id'   => '',
				'client_name' => '',
				'refresh'     => false,
				'created_by'  => get_current_user_id(),
			)
		);

		$user = get_userdata( (int) $args['user_id'] );
		if ( ! $user ) {
			return new \WP_Error( 'kaiv_bad_user', __( 'That user does not exist.', 'kai-vibe' ) );
		}

		$scopes = Scopes::sanitize( $args['scopes'] );
		if ( empty( $scopes ) ) {
			return new \WP_Error( 'kaiv_no_scopes', __( 'Grant the token at least one scope.', 'kai-vibe' ) );
		}

		$id     = substr( bin2hex( random_bytes( 8 ) ), 0, 12 );
		$secret = self::random_secret();

		$refresh_secret = ! empty( $args['refresh'] ) ? self::random_secret() : '';

		$record = array(
			'id'           => $id,
			'label'        => sanitize_text_field( $args['label'] ),
			'hash'         => self::hash( $secret ),
			'scopes'       => $scopes,
			'user_id'      => (int) $user->ID,
			'created'      => time(),
			'created_by'   => (int) $args['created_by'],
			'expires'      => (int) $args['expires'],
			'last_used'    => 0,
			'last_ip'      => '',
			'uses'         => 0,
			'revoked'      => false,
			'kind'         => self::KIND_OAUTH === $args['kind'] ? self::KIND_OAUTH : self::KIND_MANUAL,
			'client_id'    => sanitize_text_field( (string) $args['client_id'] ),
			'client_name'  => sanitize_text_field( (string) $args['client_name'] ),
			'refresh_hash' => '' !== $refresh_secret ? self::hash( $refresh_secret ) : '',
			'refresh_prev' => '',
			'refresh_ends' => '' !== $refresh_secret ? time() + self::REFRESH_LIFETIME : 0,
			'rotated'      => 0,
		);

		$tokens        = self::all();
		$tokens[ $id ] = $record;
		update_option( self::OPTION, $tokens, false );

		kaiv_audit(
			'token.created',
			array(
				'token_id' => $id,
				'label'    => $record['label'],
				'scopes'   => $scopes,
				'acts_as'  => $user->user_login,
			)
		);

		return array(
			'id'      => $id,
			'token'   => self::PREFIX . $id . '_' . $secret,
			'refresh' => '' !== $refresh_secret ? self::REFRESH_PREFIX . $id . '_' . $refresh_secret : '',
			'record'  => $record,
		);
	}

	/**
	 * Verify a presented refresh token without consuming it.
	 *
	 * @param string $presented Raw refresh token.
	 * @return array|\WP_Error Token record on success.
	 */
	public static function verify_refresh( $presented ) {
		$presented = trim( (string) $presented );

		if ( 0 !== strpos( $presented, self::REFRESH_PREFIX ) ) {
			return new \WP_Error( 'kaiv_malformed_token', __( 'Malformed token.', 'kai-vibe' ) );
		}

		$parts = explode( '_', substr( $presented, strlen( self::REFRESH_PREFIX ) ), 2 );

		if ( 2 !== count( $parts ) || '' === $parts[0] || '' === $parts[1] ) {
			return new \WP_Error( 'kaiv_malformed_token', __( 'Malformed token.', 'kai-vibe' ) );
		}

		list( $id, $secret ) = $parts;

		$record = self::get( $id );

		if ( ! $record || empty( $record['refresh_hash'] ) ) {
			self::hash( $secret );
			return new \WP_Error( 'kaiv_unknown_token', __( 'Unknown token.', 'kai-vibe' ) );
		}

		if ( ! hash_equals( (string) $record['refresh_hash'], self::hash( $secret ) ) ) {
			return new \WP_Error( 'kaiv_bad_token', __( 'Invalid token.', 'kai-vibe' ) );
		}

		return $record;
	}

	/**
	 * Exchange a refresh token for a fresh access token.
	 *
	 * One connection stays one stored record for its whole life: the secrets
	 * are replaced in place, so the owner sees a single row per connected
	 * assistant rather than a new one every hour.
	 *
	 * @param string $presented Raw refresh token.
	 * @param int    $lifetime  Seconds the new access token should live.
	 * @return array|\WP_Error { token, refresh, record }
	 */
	public static function refresh( $presented, $lifetime = HOUR_IN_SECONDS ) {
		$presented = trim( (string) $presented );

		if ( 0 !== strpos( $presented, self::REFRESH_PREFIX ) ) {
			return new \WP_Error( 'invalid_grant', __( 'Malformed refresh token.', 'kai-vibe' ), array( 'status' => 400 ) );
		}

		$parts = explode( '_', substr( $presented, strlen( self::REFRESH_PREFIX ) ), 2 );

		if ( 2 !== count( $parts ) || '' === $parts[0] || '' === $parts[1] ) {
			return new \WP_Error( 'invalid_grant', __( 'Malformed refresh token.', 'kai-vibe' ), array( 'status' => 400 ) );
		}

		list( $id, $secret ) = $parts;

		$record = self::get( $id );

		if ( ! $record || empty( $record['refresh_hash'] ) ) {
			self::hash( $secret );
			return new \WP_Error( 'invalid_grant', __( 'Unknown refresh token.', 'kai-vibe' ), array( 'status' => 400 ) );
		}

		// A retired secret coming back means the pair was copied: one of the two
		// holders is not the client. Kill the connection rather than guess.
		if ( ! empty( $record['refresh_prev'] ) && hash_equals( (string) $record['refresh_prev'], self::hash( $secret ) ) ) {
			self::revoke( $id );
			kaiv_audit( 'oauth.refresh_reuse', array( 'token_id' => $id ) );

			return new \WP_Error( 'invalid_grant', __( 'This connection was reset for safety. Connect the assistant again.', 'kai-vibe' ), array( 'status' => 400 ) );
		}

		if ( ! hash_equals( (string) $record['refresh_hash'], self::hash( $secret ) ) ) {
			return new \WP_Error( 'invalid_grant', __( 'Invalid refresh token.', 'kai-vibe' ), array( 'status' => 400 ) );
		}

		if ( ! empty( $record['refresh_ends'] ) && $record['refresh_ends'] < time() ) {
			return new \WP_Error( 'invalid_grant', __( 'This connection has expired. Connect the assistant again.', 'kai-vibe' ), array( 'status' => 400 ) );
		}

		if ( ! empty( $record['revoked'] ) ) {
			return new \WP_Error( 'invalid_grant', __( 'This connection has been disconnected.', 'kai-vibe' ), array( 'status' => 400 ) );
		}

		if ( ! get_userdata( (int) $record['user_id'] ) ) {
			return new \WP_Error( 'invalid_grant', __( 'The user this connection acts as no longer exists.', 'kai-vibe' ), array( 'status' => 400 ) );
		}

		$new_secret  = self::random_secret();
		$new_refresh = self::random_secret();

		$tokens = self::all();

		$tokens[ $id ]['hash']         = self::hash( $new_secret );
		$tokens[ $id ]['refresh_prev'] = $record['refresh_hash'];
		$tokens[ $id ]['refresh_hash'] = self::hash( $new_refresh );
		$tokens[ $id ]['expires']      = time() + max( 60, (int) $lifetime );
		$tokens[ $id ]['rotated']      = (int) ( isset( $tokens[ $id ]['rotated'] ) ? $tokens[ $id ]['rotated'] : 0 ) + 1;

		update_option( self::OPTION, $tokens, false );

		return array(
			'token'   => self::PREFIX . $id . '_' . $new_secret,
			'refresh' => self::REFRESH_PREFIX . $id . '_' . $new_refresh,
			'record'  => $tokens[ $id ],
		);
	}

	/**
	 * Verify a presented bearer token.
	 *
	 * @param string $presented Raw token string from the Authorization header.
	 * @return array|\WP_Error Token record on success.
	 */
	public static function verify( $presented ) {
		$presented = trim( (string) $presented );

		if ( 0 !== strpos( $presented, self::PREFIX ) ) {
			return new \WP_Error( 'kaiv_malformed_token', __( 'Malformed token.', 'kai-vibe' ), array( 'status' => 401 ) );
		}

		$body  = substr( $presented, strlen( self::PREFIX ) );
		$parts = explode( '_', $body, 2 );

		if ( 2 !== count( $parts ) || '' === $parts[0] || '' === $parts[1] ) {
			return new \WP_Error( 'kaiv_malformed_token', __( 'Malformed token.', 'kai-vibe' ), array( 'status' => 401 ) );
		}

		list( $id, $secret ) = $parts;

		$record = self::get( $id );
		if ( ! $record ) {
			// Burn comparable time whether or not the id exists.
			self::hash( $secret );
			return new \WP_Error( 'kaiv_unknown_token', __( 'Unknown token.', 'kai-vibe' ), array( 'status' => 401 ) );
		}

		if ( ! hash_equals( (string) $record['hash'], self::hash( $secret ) ) ) {
			return new \WP_Error( 'kaiv_bad_token', __( 'Invalid token.', 'kai-vibe' ), array( 'status' => 401 ) );
		}

		if ( ! empty( $record['revoked'] ) ) {
			return new \WP_Error( 'kaiv_revoked_token', __( 'This token has been revoked.', 'kai-vibe' ), array( 'status' => 401 ) );
		}

		if ( ! empty( $record['expires'] ) && $record['expires'] < time() ) {
			return new \WP_Error( 'kaiv_expired_token', __( 'This token has expired.', 'kai-vibe' ), array( 'status' => 401 ) );
		}

		if ( ! get_userdata( (int) $record['user_id'] ) ) {
			return new \WP_Error( 'kaiv_orphan_token', __( 'The user this token acts as no longer exists.', 'kai-vibe' ), array( 'status' => 401 ) );
		}

		return $record;
	}

	/**
	 * Record a successful use. Throttled so we do not write on every request.
	 *
	 * @param string $id Token id.
	 * @param string $ip Client IP.
	 */
	public static function touch( $id, $ip = '' ) {
		$now  = time();
		$seen = (int) get_transient( 'kaiv_touch_' . $id );

		// Sub-minute activity is not worth a write. It used to be stashed in the
		// object cache instead, which let an in-flight request put a pre-revoke
		// copy of the whole token table back and undo a disconnect.
		if ( $now - $seen < MINUTE_IN_SECONDS ) {
			return;
		}

		set_transient( 'kaiv_touch_' . $id, $now, 5 * MINUTE_IN_SECONDS );

		wp_cache_delete( self::OPTION, 'options' );

		$tokens = self::all();

		if ( ! isset( $tokens[ $id ] ) || ! empty( $tokens[ $id ]['revoked'] ) ) {
			return;
		}

		$tokens[ $id ]['uses']      = (int) $tokens[ $id ]['uses'] + 1;
		$tokens[ $id ]['last_ip']   = $ip;
		$tokens[ $id ]['last_used'] = $now;

		update_option( self::OPTION, $tokens, false );
	}

	/**
	 * @param string $id Token id.
	 * @return bool
	 */
	public static function revoke( $id ) {
		wp_cache_delete( self::OPTION, 'options' );

		$tokens = self::all();
		if ( ! isset( $tokens[ $id ] ) ) {
			return false;
		}

		$tokens[ $id ]['revoked']    = true;
		$tokens[ $id ]['revoked_at'] = time();
		update_option( self::OPTION, $tokens, false );

		kaiv_audit( 'token.revoked', array( 'token_id' => $id, 'label' => $tokens[ $id ]['label'] ) );
		return true;
	}

	/**
	 * @param string $id Token id.
	 * @return bool
	 */
	public static function delete( $id ) {
		$tokens = self::all();
		if ( ! isset( $tokens[ $id ] ) ) {
			return false;
		}

		$label = $tokens[ $id ]['label'];
		unset( $tokens[ $id ] );
		update_option( self::OPTION, $tokens, false );

		kaiv_audit( 'token.deleted', array( 'token_id' => $id, 'label' => $label ) );
		return true;
	}

	/**
	 * Update mutable fields on a token. Scopes and expiry only — never the secret.
	 *
	 * @param string $id      Token id.
	 * @param array  $changes Fields to change.
	 * @return bool
	 */
	public static function update( $id, array $changes ) {
		$tokens = self::all();
		if ( ! isset( $tokens[ $id ] ) ) {
			return false;
		}

		if ( isset( $changes['label'] ) ) {
			$tokens[ $id ]['label'] = sanitize_text_field( $changes['label'] );
		}
		if ( isset( $changes['scopes'] ) ) {
			$tokens[ $id ]['scopes'] = Scopes::sanitize( $changes['scopes'] );
		}
		if ( isset( $changes['expires'] ) ) {
			$tokens[ $id ]['expires'] = (int) $changes['expires'];
		}

		update_option( self::OPTION, $tokens, false );
		kaiv_audit( 'token.updated', array( 'token_id' => $id, 'changes' => array_keys( $changes ) ) );
		return true;
	}

	/**
	 * URL-safe high entropy secret.
	 *
	 * @return string
	 */
	private static function random_secret() {
		return rtrim( strtr( base64_encode( random_bytes( 32 ) ), '+/', '-_' ), '=' );
	}

	/**
	 * Keyed hash of the secret. Site salts mean a stolen row is useless elsewhere.
	 *
	 * @param string $secret Secret half of the token.
	 * @return string
	 */
	private static function hash( $secret ) {
		return hash_hmac( 'sha256', $secret, wp_salt( 'auth' ) . '|kaiv' );
	}
}
