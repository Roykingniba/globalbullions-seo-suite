<?php
/**
 * Small global helpers. Everything else lives in classes.
 *
 * @package KaiVibe
 */

defined( 'ABSPATH' ) || exit;

/**
 * Read a plugin setting.
 *
 * @param string $key     Setting key.
 * @param mixed  $default Fallback when unset.
 * @return mixed
 */
function kaiv_setting( $key, $default = null ) {
	return KaiVibe\Settings::get( $key, $default );
}

/**
 * Write to the audit log.
 *
 * @param string $action  Machine name of what happened.
 * @param array  $context Arbitrary detail.
 */
function kaiv_audit( $action, array $context = array() ) {
	KaiVibe\Security\AuditLog::record( $action, $context );
}

/**
 * Truthy check that treats "0", "", "false", "no" as false.
 *
 * @param mixed $value Raw value.
 * @return bool
 */
function kaiv_bool( $value ) {
	if ( is_string( $value ) ) {
		return ! in_array( strtolower( trim( $value ) ), array( '', '0', 'false', 'no', 'off' ), true );
	}
	return (bool) $value;
}

/**
 * Recursively strip values that are null so tool payloads stay compact.
 *
 * @param array $data Input.
 * @return array
 */
function kaiv_compact( array $data ) {
	foreach ( $data as $key => $value ) {
		if ( null === $value ) {
			unset( $data[ $key ] );
		} elseif ( is_array( $value ) ) {
			$data[ $key ] = kaiv_compact( $value );
		}
	}
	return $data;
}
