<?php
/**
 * The approval screen.
 *
 * This is the only thing a person has to read to connect an assistant, so it
 * says who is asking, what they will be able to do and whose account they will
 * be doing it as — in that order, in plain words, with two buttons.
 *
 * @package KaiVibe
 *
 * @var array    $kaiv_client   Registered OAuth client.
 * @var \WP_User $kaiv_user     The logged-in user who would be approving.
 * @var string[] $kaiv_roles    Translated role names for that user.
 * @var string   $kaiv_redirect Where the authorization code will be sent.
 */

defined( 'ABSPATH' ) || exit;

$kaiv_name = $kaiv_client['client_name'];

// The name and the site an app claims are both fields it typed about itself at
// registration. The only thing that is actually load-bearing is where the code
// gets sent, so that is what this screen shows.
$kaiv_target = (string) wp_parse_url( $kaiv_redirect, PHP_URL_HOST );

if ( '' === $kaiv_target ) {
	$kaiv_target = $kaiv_redirect;
}

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex, nofollow">
	<title><?php echo esc_html( sprintf( /* translators: %s: app name. */ __( 'Connect %s', 'kai-vibe' ), $kaiv_name ) ); ?></title>
	<style>
		:root {
			color-scheme: light dark;
			--kaiv-bg: #f1f2f4;
			--kaiv-card: #fff;
			--kaiv-ink: #1d2125;
			--kaiv-muted: #5c6670;
			--kaiv-line: #dfe2e6;
			--kaiv-accent: #2063d8;
			--kaiv-accent-ink: #fff;
			--kaiv-warn-bg: #fff8e5;
			--kaiv-warn-line: #f0d48a;
			--kaiv-warn-ink: #6b4d05;
		}
		@media (prefers-color-scheme: dark) {
			:root {
				--kaiv-bg: #16181c;
				--kaiv-card: #202327;
				--kaiv-ink: #e8eaed;
				--kaiv-muted: #a3abb4;
				--kaiv-line: #343940;
				--kaiv-accent: #5b93f5;
				--kaiv-accent-ink: #10131a;
				--kaiv-warn-bg: #2c2513;
				--kaiv-warn-line: #5c4d1e;
				--kaiv-warn-ink: #f0d48a;
			}
		}
		* { box-sizing: border-box; }
		body {
			margin: 0;
			padding: 24px 16px 64px;
			background: var(--kaiv-bg);
			color: var(--kaiv-ink);
			font: 16px/1.55 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
			display: flex;
			justify-content: center;
		}
		.kaiv-sheet { width: 100%; max-width: 460px; }
		.kaiv-card {
			background: var(--kaiv-card);
			border: 1px solid var(--kaiv-line);
			border-radius: 14px;
			padding: 28px 24px;
			box-shadow: 0 1px 2px rgba(0,0,0,.05), 0 8px 24px rgba(0,0,0,.06);
		}
		.kaiv-mark {
			width: 52px; height: 52px;
			border-radius: 12px;
			object-fit: contain;
			background: var(--kaiv-bg);
			border: 1px solid var(--kaiv-line);
			display: block;
			margin: 0 auto 16px;
		}
		h1 {
			margin: 0 0 6px;
			font-size: 21px;
			line-height: 1.3;
			text-align: center;
			font-weight: 650;
		}
		.kaiv-sub {
			margin: 0 0 22px;
			text-align: center;
			color: var(--kaiv-muted);
			font-size: 14px;
			word-break: break-word;
		}
		.kaiv-rows {
			border: 1px solid var(--kaiv-line);
			border-radius: 10px;
			overflow: hidden;
			margin: 0 0 18px;
		}
		.kaiv-row {
			display: flex;
			gap: 12px;
			padding: 13px 15px;
			border-bottom: 1px solid var(--kaiv-line);
			font-size: 14.5px;
		}
		.kaiv-row:last-child { border-bottom: 0; }
		.kaiv-row b { font-weight: 600; }
		.kaiv-tick { flex: 0 0 auto; width: 18px; text-align: center; color: var(--kaiv-accent); font-weight: 700; }
		.kaiv-note {
			background: var(--kaiv-warn-bg);
			border: 1px solid var(--kaiv-warn-line);
			color: var(--kaiv-warn-ink);
			border-radius: 10px;
			padding: 12px 15px;
			font-size: 13.5px;
			margin: 0 0 20px;
		}
		.kaiv-actions { display: flex; flex-direction: column; gap: 10px; }
		button {
			font: inherit;
			font-weight: 600;
			border-radius: 9px;
			padding: 13px 18px;
			cursor: pointer;
			border: 1px solid transparent;
			width: 100%;
		}
		.kaiv-approve { background: var(--kaiv-accent); color: var(--kaiv-accent-ink); border-color: var(--kaiv-accent); font-size: 16px; }
		.kaiv-approve:hover { filter: brightness(1.07); }
		.kaiv-deny { background: transparent; color: var(--kaiv-muted); border-color: var(--kaiv-line); }
		.kaiv-deny:hover { color: var(--kaiv-ink); }
		.kaiv-foot {
			margin: 20px 0 0;
			text-align: center;
			font-size: 12.5px;
			color: var(--kaiv-muted);
		}
		.kaiv-foot a { color: inherit; }
	</style>
</head>
<body>
	<div class="kaiv-sheet">
		<div class="kaiv-card">

			<?php if ( ! empty( $kaiv_client['logo_uri'] ) ) : ?>
				<img class="kaiv-mark" src="<?php echo esc_url( $kaiv_client['logo_uri'] ); ?>" alt="">
			<?php endif; ?>

			<h1>
				<?php
				printf(
					/* translators: 1: app name, 2: site name. */
					esc_html__( 'Let %1$s work on %2$s?', 'kai-vibe' ),
					'<b>' . esc_html( $kaiv_name ) . '</b>',
					esc_html( get_bloginfo( 'name' ) )
				);
				?>
			</h1>

			<p class="kaiv-sub">
				<?php
				printf(
					/* translators: %s: the host the sign-in will be handed back to. */
					esc_html__( 'Signing in will be handed back to %s', 'kai-vibe' ),
					'<b>' . esc_html( $kaiv_target ) . '</b>'
				);
				?>
				<br>
				<small><?php esc_html_e( 'If that is not the app you are actually using, close this page.', 'kai-vibe' ); ?></small>
			</p>

			<div class="kaiv-rows">
				<div class="kaiv-row">
					<span class="kaiv-tick">&#10003;</span>
					<span>
						<?php
						printf(
							/* translators: 1: user login, 2: role names. */
							esc_html__( 'It will act as %1$s (%2$s), and can do exactly what that account can do — no more.', 'kai-vibe' ),
							'<b>' . esc_html( $kaiv_user->user_login ) . '</b>',
							esc_html( implode( ', ', $kaiv_roles ) )
						);
						?>
					</span>
				</div>
				<div class="kaiv-row">
					<span class="kaiv-tick">&#10003;</span>
					<span><?php esc_html_e( 'Deleting things, installing plugins and editing files stop and wait for you to approve them.', 'kai-vibe' ); ?></span>
				</div>
				<div class="kaiv-row">
					<span class="kaiv-tick">&#10003;</span>
					<span><?php esc_html_e( 'Every change is recorded with a copy of what was there before, so you can undo it.', 'kai-vibe' ); ?></span>
				</div>
				<div class="kaiv-row">
					<span class="kaiv-tick">&#10003;</span>
					<span><?php esc_html_e( 'You can disconnect it at any time from your dashboard.', 'kai-vibe' ); ?></span>
				</div>
			</div>

			<?php if ( user_can( $kaiv_user, 'edit_themes' ) || user_can( $kaiv_user, 'install_plugins' ) ) : ?>
				<p class="kaiv-note">
					<?php esc_html_e( 'Your account can edit files and manage plugins, so this connection will be able to as well once you approve those actions. If that is more than you want, log in as an editor instead and connect from there.', 'kai-vibe' ); ?>
				</p>
			<?php endif; ?>

			<form method="post" action="">
				<?php
				printf( '<input type="hidden" name="kaiv_nonce" value="%s">', esc_attr( wp_create_nonce( 'kaiv_authorize' ) ) );
				?>

				<div class="kaiv-actions">
					<button type="submit" name="approve" value="1" class="kaiv-approve"><?php esc_html_e( 'Connect', 'kai-vibe' ); ?></button>
					<button type="submit" name="deny" value="1" class="kaiv-deny"><?php esc_html_e( 'Not now', 'kai-vibe' ); ?></button>
				</div>
			</form>
		</div>

		<p class="kaiv-foot">
			<?php esc_html_e( 'Connected through KAI Vibe. Nothing is sent to anyone but the assistant you are connecting.', 'kai-vibe' ); ?>
		</p>
	</div>
</body>
</html>
