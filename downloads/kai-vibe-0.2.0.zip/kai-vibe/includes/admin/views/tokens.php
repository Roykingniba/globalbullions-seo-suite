<?php
/**
 * Token management.
 *
 * @package KaiVibe
 *
 * @var array|false $fresh  Freshly created token, shown once.
 * @var string|false $error Error from the last attempt.
 * @var array       $tokens Stored tokens.
 * @var array       $scopes Scope vocabulary.
 */

defined( 'ABSPATH' ) || exit;

/*
 * Two very different things live in one store: connections an assistant made
 * for itself, and keys the owner typed out by hand. Records written before
 * the OAuth server existed have no 'kind' at all, so anything that is not
 * explicitly a connection is treated as hand-made.
 */
$kaiv_connections = array();
$kaiv_manual      = array();

foreach ( $tokens as $kaiv_id => $kaiv_record ) {
	if ( isset( $kaiv_record['kind'] ) && \KaiVibe\Auth\TokenManager::KIND_OAUTH === $kaiv_record['kind'] ) {
		$kaiv_connections[ $kaiv_id ] = $kaiv_record;
	} else {
		$kaiv_manual[ $kaiv_id ] = $kaiv_record;
	}
}

$kaiv_clients = \KaiVibe\Auth\OAuth::clients();
?>
<div class="wrap kaiv-wrap">
	<h1><?php esc_html_e( 'Tokens', 'kai-vibe' ); ?></h1>

	<?php \KaiVibe\Admin\Admin::notice(); ?>

	<?php if ( $error ) : ?>
		<div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div>
	<?php endif; ?>

	<?php if ( $fresh ) : ?>
		<div class="kaiv-card kaiv-fresh-token">
			<h2><?php esc_html_e( 'Your new token', 'kai-vibe' ); ?></h2>
			<p><strong><?php esc_html_e( 'Copy it now. Only a hash is stored, so this is the only time it can be shown.', 'kai-vibe' ); ?></strong></p>

			<div class="kaiv-copy-row">
				<input type="text" readonly class="large-text code" id="kaiv-fresh" value="<?php echo esc_attr( $fresh['token'] ); ?>">
				<button type="button" class="button button-primary kaiv-copy" data-target="kaiv-fresh"><?php esc_html_e( 'Copy', 'kai-vibe' ); ?></button>
			</div>

			<p class="description">
				<?php esc_html_e( 'Send it as an Authorization: Bearer header. If you lose it, revoke this token and mint another — there is no recovery.', 'kai-vibe' ); ?>
			</p>
		</div>
	<?php endif; ?>

	<div class="kaiv-cards">
		<div class="kaiv-card">
			<h2><?php esc_html_e( 'New token', 'kai-vibe' ); ?></h2>

			<form method="post">
				<?php wp_nonce_field( 'kaiv_create_token' ); ?>
				<input type="hidden" name="kaiv_action" value="create_token">

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="kaiv-label"><?php esc_html_e( 'Label', 'kai-vibe' ); ?></label></th>
						<td>
							<input type="text" name="label" id="kaiv-label" class="regular-text" required
								placeholder="<?php esc_attr_e( 'e.g. Claude — content team', 'kai-vibe' ); ?>">
							<p class="description"><?php esc_html_e( 'Name it after who or what will use it, so the activity log is readable later.', 'kai-vibe' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="kaiv-user"><?php esc_html_e( 'Act as', 'kai-vibe' ); ?></label></th>
						<td>
							<?php
							wp_dropdown_users(
								array(
									'name'     => 'user_id',
									'id'       => 'kaiv-user',
									'selected' => get_current_user_id(),
									'role__in' => array( 'administrator', 'editor', 'author', 'shop_manager' ),
								)
							);
							?>
							<p class="description"><?php esc_html_e( 'The agent inherits this user\'s capabilities and nothing more. Pick the least privileged account that can do the job — an editor for content work, not an administrator.', 'kai-vibe' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="kaiv-expires"><?php esc_html_e( 'Expires', 'kai-vibe' ); ?></label></th>
						<td>
							<select name="expires_days" id="kaiv-expires">
								<option value="7"><?php esc_html_e( '7 days', 'kai-vibe' ); ?></option>
								<option value="30" selected><?php esc_html_e( '30 days', 'kai-vibe' ); ?></option>
								<option value="90"><?php esc_html_e( '90 days', 'kai-vibe' ); ?></option>
								<option value="365"><?php esc_html_e( '1 year', 'kai-vibe' ); ?></option>
								<option value="0"><?php esc_html_e( 'Never', 'kai-vibe' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Scopes', 'kai-vibe' ); ?></th>
						<td>
							<fieldset class="kaiv-scopes">
								<p class="kaiv-presets">
									<button type="button" class="button button-small kaiv-preset" data-preset="read"><?php esc_html_e( 'Read only', 'kai-vibe' ); ?></button>
									<button type="button" class="button button-small kaiv-preset" data-preset="content"><?php esc_html_e( 'Content editor', 'kai-vibe' ); ?></button>
									<button type="button" class="button button-small kaiv-preset" data-preset="developer"><?php esc_html_e( 'Developer', 'kai-vibe' ); ?></button>
									<button type="button" class="button button-small kaiv-preset" data-preset="none"><?php esc_html_e( 'Clear', 'kai-vibe' ); ?></button>
								</p>

								<?php foreach ( $scopes as $kaiv_key => $kaiv_scope ) : ?>
									<label class="kaiv-scope-row">
										<input type="checkbox" name="scopes[]" value="<?php echo esc_attr( $kaiv_key ); ?>"
											<?php checked( in_array( $kaiv_key, array( 'site:read', 'content:read' ), true ) ); ?>>
										<code><?php echo esc_html( $kaiv_key ); ?></code>
										<span class="kaiv-risk kaiv-risk-<?php echo esc_attr( $kaiv_scope[2] ); ?>"><?php echo esc_html( $kaiv_scope[2] ); ?></span>
										<span class="kaiv-scope-desc"><?php echo esc_html( $kaiv_scope[1] ); ?></span>
									</label>
								<?php endforeach; ?>
							</fieldset>
						</td>
					</tr>
				</table>

				<?php submit_button( __( 'Create token', 'kai-vibe' ) ); ?>
			</form>
		</div>
	</div>

	<?php if ( empty( $kaiv_connections ) && empty( $kaiv_manual ) ) : ?>
		<h2><?php esc_html_e( 'Nothing is connected yet', 'kai-vibe' ); ?></h2>

		<div class="kaiv-empty">
			<p><?php esc_html_e( 'No assistant can reach this site until something is connected. The easiest way is to let one connect itself — the Connect screen has the address to hand it, and you approve the connection here in WordPress.', 'kai-vibe' ); ?></p>
			<p>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=kai-vibe' ) ); ?>" class="button button-primary">
					<?php esc_html_e( 'Open the Connect screen', 'kai-vibe' ); ?>
				</a>
			</p>
			<p class="description"><?php esc_html_e( 'Or create a key by hand above, if the assistant you use cannot connect on its own.', 'kai-vibe' ); ?></p>
		</div>
	<?php endif; ?>

	<?php if ( ! empty( $kaiv_connections ) ) : ?>
		<h2><?php esc_html_e( 'Connected assistants', 'kai-vibe' ); ?></h2>
		<p class="description"><?php esc_html_e( 'These connected themselves and you approved them. Each one can do everything the WordPress user it acts as can do. Disconnecting takes effect immediately.', 'kai-vibe' ); ?></p>

		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'App', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Acts as', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Last used', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Connected', 'kai-vibe' ); ?></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $kaiv_connections as $kaiv_connection ) : ?>
				<?php
				$kaiv_app = isset( $kaiv_connection['client_name'] ) && '' !== $kaiv_connection['client_name']
					? $kaiv_connection['client_name']
					: ( isset( $kaiv_connection['label'] ) ? $kaiv_connection['label'] : __( 'AI assistant', 'kai-vibe' ) );

				$kaiv_actor = get_userdata( isset( $kaiv_connection['user_id'] ) ? (int) $kaiv_connection['user_id'] : 0 );
				?>
				<tr>
					<td>
						<strong class="kaiv-app-name"><?php echo esc_html( $kaiv_app ); ?></strong>
						<?php if ( ! empty( $kaiv_connection['revoked'] ) ) : ?>
							<span class="kaiv-risk kaiv-risk-critical"><?php esc_html_e( 'disconnected', 'kai-vibe' ); ?></span>
						<?php endif; ?>
					</td>
					<td><?php echo wp_kses_post( $kaiv_actor ? esc_html( $kaiv_actor->user_login ) : '<em>' . esc_html__( 'deleted user', 'kai-vibe' ) . '</em>' ); ?></td>
					<td>
						<?php
						echo wp_kses_post(
							! empty( $kaiv_connection['last_used'] )
								? esc_html(
									sprintf(
										/* translators: %s: human readable time period, e.g. "5 mins". */
										__( '%s ago', 'kai-vibe' ),
										human_time_diff( (int) $kaiv_connection['last_used'] )
									)
								)
								: '<span class="kaiv-muted">' . esc_html__( 'never', 'kai-vibe' ) . '</span>'
						);
						?>
					</td>
					<td>
						<?php
						echo wp_kses_post(
							! empty( $kaiv_connection['created'] )
								? esc_html(
									sprintf(
										/* translators: %s: human readable time period, e.g. "3 days". */
										__( '%s ago', 'kai-vibe' ),
										human_time_diff( (int) $kaiv_connection['created'] )
									)
								)
								: '<span class="kaiv-muted">' . esc_html__( 'unknown', 'kai-vibe' ) . '</span>'
						);
						?>
					</td>
					<td class="kaiv-actions">
						<?php if ( empty( $kaiv_connection['revoked'] ) ) : ?>
							<form method="post" class="kaiv-inline">
								<?php wp_nonce_field( 'kaiv_revoke_token' ); ?>
								<input type="hidden" name="kaiv_action" value="revoke_token">
								<input type="hidden" name="token_id" value="<?php echo esc_attr( $kaiv_connection['id'] ); ?>">
								<button class="button button-small" onclick="return confirm('<?php esc_attr_e( 'Disconnect this assistant? It stops working immediately and has to be connected again from scratch.', 'kai-vibe' ); ?>')">
									<?php esc_html_e( 'Disconnect', 'kai-vibe' ); ?>
								</button>
							</form>
						<?php else : ?>
							<form method="post" class="kaiv-inline">
								<?php wp_nonce_field( 'kaiv_delete_token' ); ?>
								<input type="hidden" name="kaiv_action" value="delete_token">
								<input type="hidden" name="token_id" value="<?php echo esc_attr( $kaiv_connection['id'] ); ?>">
								<button class="button button-small button-link-delete" onclick="return confirm('<?php esc_attr_e( 'Remove this disconnected assistant from the list?', 'kai-vibe' ); ?>')">
									<?php esc_html_e( 'Remove', 'kai-vibe' ); ?>
								</button>
							</form>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>

	<?php if ( ! empty( $kaiv_manual ) ) : ?>
		<h2><?php esc_html_e( 'Keys you made by hand', 'kai-vibe' ); ?></h2>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Label', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Acts as', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Scopes', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Last used', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Expires', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Status', 'kai-vibe' ); ?></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $kaiv_manual as $kaiv_token ) : ?>
				<?php
				$kaiv_user    = get_userdata( (int) $kaiv_token['user_id'] );
				$kaiv_expired = ! empty( $kaiv_token['expires'] ) && $kaiv_token['expires'] < time();
				?>
				<tr>
					<td>
						<strong><?php echo esc_html( $kaiv_token['label'] ); ?></strong><br>
						<code class="kaiv-muted">kaiv_<?php echo esc_html( $kaiv_token['id'] ); ?>_…</code>
					</td>
					<td><?php echo wp_kses_post( $kaiv_user ? esc_html( $kaiv_user->user_login ) : '<em>' . esc_html__( 'deleted user', 'kai-vibe' ) . '</em>' ); ?></td>
					<td class="kaiv-scope-cell">
						<?php foreach ( (array) $kaiv_token['scopes'] as $kaiv_scope ) : ?>
							<code><?php echo esc_html( $kaiv_scope ); ?></code>
						<?php endforeach; ?>
					</td>
					<td>
						<?php
						echo wp_kses_post(
							$kaiv_token['last_used']
								? esc_html( human_time_diff( $kaiv_token['last_used'] ) . ' ago' )
								: '<span class="kaiv-muted">' . esc_html__( 'never', 'kai-vibe' ) . '</span>'
						);
						?>
						<br><span class="kaiv-muted"><?php echo esc_html( sprintf( '%d calls', (int) $kaiv_token['uses'] ) ); ?></span>
					</td>
					<td>
						<?php
						echo wp_kses_post(
							$kaiv_token['expires']
								? esc_html( gmdate( 'Y-m-d', $kaiv_token['expires'] ) )
								: '<span class="kaiv-muted">' . esc_html__( 'never', 'kai-vibe' ) . '</span>'
						);
						?>
					</td>
					<td>
						<?php if ( ! empty( $kaiv_token['revoked'] ) ) : ?>
							<span class="kaiv-risk kaiv-risk-critical"><?php esc_html_e( 'revoked', 'kai-vibe' ); ?></span>
						<?php elseif ( $kaiv_expired ) : ?>
							<span class="kaiv-risk kaiv-risk-high"><?php esc_html_e( 'expired', 'kai-vibe' ); ?></span>
						<?php else : ?>
							<span class="kaiv-risk kaiv-risk-low"><?php esc_html_e( 'active', 'kai-vibe' ); ?></span>
						<?php endif; ?>
					</td>
					<td class="kaiv-actions">
						<?php if ( empty( $kaiv_token['revoked'] ) ) : ?>
							<form method="post" class="kaiv-inline">
								<?php wp_nonce_field( 'kaiv_revoke_token' ); ?>
								<input type="hidden" name="kaiv_action" value="revoke_token">
								<input type="hidden" name="token_id" value="<?php echo esc_attr( $kaiv_token['id'] ); ?>">
								<button class="button button-small" onclick="return confirm('<?php esc_attr_e( 'Revoke this token? Any agent using it stops working immediately.', 'kai-vibe' ); ?>')">
									<?php esc_html_e( 'Revoke', 'kai-vibe' ); ?>
								</button>
							</form>
						<?php endif; ?>

						<form method="post" class="kaiv-inline">
							<?php wp_nonce_field( 'kaiv_delete_token' ); ?>
							<input type="hidden" name="kaiv_action" value="delete_token">
							<input type="hidden" name="token_id" value="<?php echo esc_attr( $kaiv_token['id'] ); ?>">
							<button class="button button-small button-link-delete" onclick="return confirm('<?php esc_attr_e( 'Delete this token permanently?', 'kai-vibe' ); ?>')">
								<?php esc_html_e( 'Delete', 'kai-vibe' ); ?>
							</button>
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>

	<?php if ( ! empty( $kaiv_clients ) ) : ?>
		<details class="kaiv-clients">
			<summary><?php esc_html_e( 'Apps that have registered with this site', 'kai-vibe' ); ?></summary>

			<p class="description"><?php esc_html_e( 'Any app can announce itself here before asking to connect, and announcing itself grants it nothing. Only the rows in Connected assistants above can actually reach your site. The names and addresses below are supplied by the app itself, so treat them as claims rather than facts.', 'kai-vibe' ); ?></p>

			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Name it gave', 'kai-vibe' ); ?></th>
						<th><?php esc_html_e( 'Website', 'kai-vibe' ); ?></th>
						<th><?php esc_html_e( 'Registered', 'kai-vibe' ); ?></th>
						<th><?php esc_html_e( 'Ever connected', 'kai-vibe' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $kaiv_clients as $kaiv_client ) : ?>
					<?php
					$kaiv_client_host = isset( $kaiv_client['client_uri'] ) && '' !== $kaiv_client['client_uri']
						? wp_parse_url( $kaiv_client['client_uri'], PHP_URL_HOST )
						: '';
					?>
					<tr>
						<td><?php echo esc_html( isset( $kaiv_client['client_name'] ) && '' !== $kaiv_client['client_name'] ? $kaiv_client['client_name'] : __( 'unnamed', 'kai-vibe' ) ); ?></td>
						<td>
							<?php if ( $kaiv_client_host ) : ?>
								<code><?php echo esc_html( $kaiv_client_host ); ?></code>
							<?php else : ?>
								<span class="kaiv-muted"><?php esc_html_e( 'none given', 'kai-vibe' ); ?></span>
							<?php endif; ?>
						</td>
						<td>
							<?php
							echo wp_kses_post(
								! empty( $kaiv_client['created'] )
									? esc_html(
										sprintf(
											/* translators: %s: human readable time period, e.g. "2 hours". */
											__( '%s ago', 'kai-vibe' ),
											human_time_diff( (int) $kaiv_client['created'] )
										)
									)
									: '<span class="kaiv-muted">' . esc_html__( 'unknown', 'kai-vibe' ) . '</span>'
							);
							?>
						</td>
						<td>
							<?php
							echo wp_kses_post(
								! empty( $kaiv_client['last_used'] )
									? esc_html(
										sprintf(
											/* translators: %s: human readable time period, e.g. "2 hours". */
											__( '%s ago', 'kai-vibe' ),
											human_time_diff( (int) $kaiv_client['last_used'] )
										)
									)
									: '<span class="kaiv-muted">' . esc_html__( 'never', 'kai-vibe' ) . '</span>'
							);
							?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</details>
	<?php endif; ?>
</div>
