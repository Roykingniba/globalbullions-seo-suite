<?php
/**
 * Change journal, with one-click rollback.
 *
 * @package KaiVibe
 *
 * @var array $journal Query result { items, total }.
 * @var int   $page    Current page.
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap kaiv-wrap">
	<h1><?php esc_html_e( 'Changes', 'kai-vibe' ); ?></h1>

	<p class="kaiv-lede">
		<?php esc_html_e( 'Everything an agent overwrote, with the previous state kept alongside it. This covers ground WordPress revisions do not: post meta, options, terms and theme files. Undo puts the old value back.', 'kai-vibe' ); ?>
	</p>

	<?php \KaiVibe\Admin\Admin::notice(); ?>

	<?php if ( empty( $journal['items'] ) ) : ?>
		<p><?php esc_html_e( 'Nothing has been changed through an agent yet.', 'kai-vibe' ); ?></p>
	<?php else : ?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'When', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Change', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Type', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Target', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Token', 'kai-vibe' ); ?></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $journal['items'] as $kaiv_entry ) : ?>
				<?php $kaiv_token = \KaiVibe\Auth\TokenManager::get( $kaiv_entry['token_id'] ); ?>
				<tr class="<?php echo esc_attr( $kaiv_entry['undone'] ? 'kaiv-undone' : '' ); ?>">
					<td title="<?php echo esc_attr( $kaiv_entry['created_at'] ); ?>">
						<?php echo esc_html( human_time_diff( strtotime( $kaiv_entry['created_at'] . ' UTC' ) ) . ' ago' ); ?>
					</td>
					<td><?php echo esc_html( $kaiv_entry['label'] ); ?></td>
					<td><code><?php echo esc_html( $kaiv_entry['kind'] ); ?></code></td>
					<td><code><?php echo esc_html( $kaiv_entry['target'] ); ?></code></td>
					<td><?php echo wp_kses_post( $kaiv_token ? esc_html( $kaiv_token['label'] ) : '<span class="kaiv-muted">—</span>' ); ?></td>
					<td class="kaiv-actions">
						<?php if ( $kaiv_entry['undone'] ) : ?>
							<span class="kaiv-muted"><?php esc_html_e( 'undone', 'kai-vibe' ); ?></span>
						<?php else : ?>
							<form method="post" class="kaiv-inline">
								<?php wp_nonce_field( 'kaiv_undo' ); ?>
								<input type="hidden" name="kaiv_action" value="undo">
								<input type="hidden" name="change_id" value="<?php echo esc_attr( $kaiv_entry['id'] ); ?>">
								<button class="button button-small" onclick="return confirm('<?php esc_attr_e( 'Restore the previous state?', 'kai-vibe' ); ?>')">
									<?php esc_html_e( 'Undo', 'kai-vibe' ); ?>
								</button>
							</form>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>

		<?php
		$kaiv_pages = (int) ceil( $journal['total'] / 50 );

		if ( $kaiv_pages > 1 ) :
			?>
			<div class="tablenav"><div class="tablenav-pages">
				<?php
				echo wp_kses_post(
					paginate_links(
						array(
							'base'    => add_query_arg( 'paged', '%#%' ),
							'format'  => '',
							'current' => $page,
							'total'   => $kaiv_pages,
						)
					)
				);
				?>
			</div></div>
		<?php endif; ?>
	<?php endif; ?>

	<p class="description">
		<?php
		printf(
			/* translators: %d: retention in days. */
			esc_html__( 'Journal entries are kept for %d days, then pruned.', 'kai-vibe' ),
			(int) kaiv_setting( 'journal_retention_days', 14 )
		);
		?>
	</p>
</div>
