<?php
/**
 * Connect screen.
 *
 * Written for someone who has never heard of MCP. The whole job is one line of
 * text and two button presses, so that is what the page leads with. Keys,
 * scopes and config files still exist, but they are folded away for the people
 * who actually need them.
 *
 * @package KaiVibe
 *
 * @var string $endpoint MCP endpoint URL.
 * @var array  $tokens   Existing tokens.
 */

defined( 'ABSPATH' ) || exit;

$kaiv_active_tokens = array_filter(
	$tokens,
	static function ( $token ) {
		return empty( $token['revoked'] ) && ( empty( $token['expires'] ) || $token['expires'] > time() );
	}
);

$kaiv_connections = array_filter(
	$tokens,
	static function ( $token ) {
		return empty( $token['revoked'] )
			&& isset( $token['kind'] )
			&& \KaiVibe\Auth\TokenManager::KIND_OAUTH === $token['kind'];
	}
);

$kaiv_is_ssl     = 0 === strpos( $endpoint, 'https://' );
$kaiv_one_click  = \KaiVibe\Auth\OAuth::enabled() && $kaiv_is_ssl;
$kaiv_root_ok    = \KaiVibe\Auth\OAuth::owns_domain_root();
$kaiv_ready      = $kaiv_is_ssl && kaiv_setting( 'enabled', true );
?>
<div class="wrap kaiv-wrap">
	<h1 class="kaiv-brand">
		<img src="<?php echo esc_url( KAIV_URL . 'assets/logo.svg' ); ?>"
			alt="<?php esc_attr_e( 'KAI Vibe', 'kai-vibe' ); ?>" width="310" height="88">
		<span class="kaiv-version"><?php echo esc_html( KAIV_VERSION ); ?></span>
	</h1>

	<p class="kaiv-lede">
		<?php esc_html_e( 'KAI Vibe lets an AI assistant work on this website for you. Connect it once, then just ask for what you want in plain English — write a post, fix a page, tidy up the images. You approve anything risky, and every change can be undone.', 'kai-vibe' ); ?>
	</p>

	<?php \KaiVibe\Admin\Admin::notice(); ?>

	<?php if ( ! $kaiv_is_ssl ) : ?>
		<div class="notice notice-error inline">
			<p>
				<strong><?php esc_html_e( 'This site is not using HTTPS yet.', 'kai-vibe' ); ?></strong>
				<?php esc_html_e( 'For your security, KAI Vibe will not accept connections over an unencrypted link. Ask your web host to add a free SSL certificate, then come back here.', 'kai-vibe' ); ?>
			</p>
		</div>
	<?php endif; ?>

	<?php if ( ! empty( $kaiv_connections ) ) : ?>
		<div class="kaiv-connected-banner">
			<span class="kaiv-dot is-on"></span>
			<?php
			printf(
				esc_html(
					/* translators: %d: number of connected assistants. */
					_n(
						'%d assistant is connected to this site.',
						'%d assistants are connected to this site.',
						count( $kaiv_connections ),
						'kai-vibe'
					)
				),
				count( $kaiv_connections )
			);
			?>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=kai-vibe-tokens' ) ); ?>">
				<?php esc_html_e( 'See them, or disconnect one', 'kai-vibe' ); ?>
			</a>
		</div>
	<?php endif; ?>

	<!-- ── The address ───────────────────────────────────────────────────── -->

	<div class="kaiv-hero">
		<h2><?php esc_html_e( 'Your website address for AI', 'kai-vibe' ); ?></h2>
		<p><?php esc_html_e( 'This one line is everything an assistant needs. Copy it, paste it into the app, and it will ask you to log in and press a button. There is no key to find and nothing to type.', 'kai-vibe' ); ?></p>

		<div class="kaiv-copy-row kaiv-copy-hero">
			<input type="text" readonly class="large-text code" id="kaiv-endpoint" value="<?php echo esc_attr( $endpoint ); ?>">
			<button type="button" class="button button-primary button-hero kaiv-copy" data-target="kaiv-endpoint">
				<?php esc_html_e( 'Copy', 'kai-vibe' ); ?>
			</button>
		</div>

		<p class="description">
			<?php esc_html_e( 'Nothing happens if you open this in a browser — it is not a web page. That is normal.', 'kai-vibe' ); ?>
		</p>
	</div>

	<?php if ( ! $kaiv_one_click && $kaiv_is_ssl ) : ?>
		<div class="notice notice-warning inline">
			<p>
				<strong><?php esc_html_e( 'One-click connection is switched off.', 'kai-vibe' ); ?></strong>
				<?php esc_html_e( 'Assistants can still connect, but only with a key you create by hand. Turn it back on under Settings to make connecting a two-button job.', 'kai-vibe' ); ?>
			</p>
		</div>
	<?php endif; ?>

	<!-- ── The two button presses ────────────────────────────────────────── -->

	<div class="kaiv-card">
		<h2><?php esc_html_e( 'How to connect', 'kai-vibe' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Pick the app you use. If yours is not listed, look for "MCP", "connectors" or "custom tools" in its settings — the address above goes in the one box it asks for.', 'kai-vibe' ); ?></p>

		<div class="kaiv-tabs">
			<div class="kaiv-tab-buttons" role="tablist">
				<button type="button" class="button kaiv-tab-button is-active" data-tab="claude-app" role="tab"><?php esc_html_e( 'Claude', 'kai-vibe' ); ?></button>
				<button type="button" class="button kaiv-tab-button" data-tab="chatgpt" role="tab"><?php esc_html_e( 'ChatGPT', 'kai-vibe' ); ?></button>
				<button type="button" class="button kaiv-tab-button" data-tab="other-app" role="tab"><?php esc_html_e( 'Any other app', 'kai-vibe' ); ?></button>
			</div>

			<div class="kaiv-tab-panel is-active" data-tab="claude-app">
				<ol class="kaiv-substeps kaiv-substeps-big">
					<li><?php esc_html_e( 'In Claude, open Settings, then Connectors, then "Add custom connector".', 'kai-vibe' ); ?></li>
					<li><?php esc_html_e( 'Give it any name you like — "My website" is fine — and paste the address above into the URL box.', 'kai-vibe' ); ?></li>
					<li><?php esc_html_e( 'Press Connect. Your browser opens on this site.', 'kai-vibe' ); ?></li>
					<li><?php esc_html_e( 'Log in to WordPress if it asks, then press the blue Connect button.', 'kai-vibe' ); ?></li>
				</ol>
				<p class="kaiv-done-note"><?php esc_html_e( 'That is the whole thing. Claude comes back connected.', 'kai-vibe' ); ?></p>
			</div>

			<div class="kaiv-tab-panel" data-tab="chatgpt">
				<ol class="kaiv-substeps kaiv-substeps-big">
					<li><?php esc_html_e( 'In ChatGPT, open Settings, then Connectors, and choose to add one.', 'kai-vibe' ); ?></li>
					<li><?php esc_html_e( 'Paste the address above into the server URL box and pick OAuth as the sign-in method if it asks.', 'kai-vibe' ); ?></li>
					<li><?php esc_html_e( 'Press Connect. Your browser opens on this site.', 'kai-vibe' ); ?></li>
					<li><?php esc_html_e( 'Log in to WordPress if it asks, then press the blue Connect button.', 'kai-vibe' ); ?></li>
				</ol>
				<p class="kaiv-done-note"><?php esc_html_e( 'Connectors are not on every ChatGPT plan. If you cannot find the screen, your plan may not include them yet.', 'kai-vibe' ); ?></p>
			</div>

			<div class="kaiv-tab-panel" data-tab="other-app">
				<p><?php esc_html_e( 'Anything that speaks MCP will work. Look for the box asking for a server URL and paste the address above into it.', 'kai-vibe' ); ?></p>
				<ul class="kaiv-facts">
					<li><strong><?php esc_html_e( 'Connection type', 'kai-vibe' ); ?></strong> <code>Streamable HTTP</code></li>
					<li><strong><?php esc_html_e( 'Sign-in method', 'kai-vibe' ); ?></strong> <code>OAuth 2.1</code> <?php esc_html_e( '(the app registers itself — there is no client ID or secret to enter)', 'kai-vibe' ); ?></li>
					<li><strong><?php esc_html_e( 'If it only offers a token', 'kai-vibe' ); ?></strong> <?php esc_html_e( 'use the folded section below instead.', 'kai-vibe' ); ?></li>
				</ul>
			</div>
		</div>
	</div>

	<!-- ── For tools that live in a config file ──────────────────────────── -->

	<details class="kaiv-card kaiv-devbox">
		<summary>
			<strong><?php esc_html_e( 'Connecting a coding tool or an automation?', 'kai-vibe' ); ?></strong>
			<span><?php esc_html_e( 'Claude Code, Cursor, VS Code, Windsurf, n8n and similar. Most of these can also connect on their own, but some want a settings file.', 'kai-vibe' ); ?></span>
		</summary>

		<div class="kaiv-tabs">
			<div class="kaiv-tab-buttons" role="tablist">
				<button type="button" class="button kaiv-tab-button is-active" data-tab="cc" role="tab"><?php esc_html_e( 'Claude Code', 'kai-vibe' ); ?></button>
				<button type="button" class="button kaiv-tab-button" data-tab="editors" role="tab"><?php esc_html_e( 'Cursor / VS Code / Windsurf', 'kai-vibe' ); ?></button>
				<button type="button" class="button kaiv-tab-button" data-tab="token" role="tab"><?php esc_html_e( 'With a key instead', 'kai-vibe' ); ?></button>
			</div>

			<div class="kaiv-tab-panel is-active" data-tab="cc">
				<p><?php esc_html_e( 'Run this once. It will open your browser so you can press Connect, exactly like the apps above.', 'kai-vibe' ); ?></p>
				<div class="kaiv-copy-row">
					<input type="text" readonly class="large-text code" id="kaiv-cc" value="<?php echo esc_attr( 'claude mcp add --transport http kai-vibe ' . $endpoint ); ?>">
					<button type="button" class="button kaiv-copy" data-target="kaiv-cc"><?php esc_html_e( 'Copy', 'kai-vibe' ); ?></button>
				</div>
				<p class="description"><?php esc_html_e( 'Then run /mcp inside Claude Code and choose to authenticate.', 'kai-vibe' ); ?></p>
			</div>

			<div class="kaiv-tab-panel" data-tab="editors">
				<p><?php esc_html_e( 'Add this to the app\'s MCP settings file. It will prompt you to sign in the first time it connects.', 'kai-vibe' ); ?></p>
				<pre class="kaiv-pre"><code><?php
				echo esc_html(
					wp_json_encode(
						array(
							'mcpServers' => array(
								'kai-vibe' => array(
									'type' => 'http',
									'url'  => $endpoint,
								),
							),
						),
						JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
					)
				);
				?></code></pre>
				<p class="description"><?php esc_html_e( 'Some builds still expect "serverUrl" rather than "url", and some want the block under "servers" rather than "mcpServers". If one shape does not take, try the other.', 'kai-vibe' ); ?></p>
			</div>

			<div class="kaiv-tab-panel" data-tab="token">
				<p><?php esc_html_e( 'A few tools cannot sign in for themselves and want a fixed key. Make one, then paste it where YOUR-KEY appears.', 'kai-vibe' ); ?></p>

				<p>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=kai-vibe-tokens' ) ); ?>" class="button">
						<?php esc_html_e( 'Make a key', 'kai-vibe' ); ?>
					</a>
				</p>

				<pre class="kaiv-pre"><code><?php
				echo esc_html(
					wp_json_encode(
						array(
							'mcpServers' => array(
								'kai-vibe' => array(
									'type'    => 'http',
									'url'     => $endpoint,
									'headers' => array( 'Authorization' => 'Bearer YOUR-KEY' ),
								),
							),
						),
						JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
					)
				);
				?></code></pre>

				<p class="description"><?php esc_html_e( 'A key you make by hand only does the jobs you tick, so it is the safer option if you are handing the connection to something you did not write yourself.', 'kai-vibe' ); ?></p>
			</div>
		</div>

		<?php if ( ! $kaiv_root_ok ) : ?>
			<div class="notice notice-warning inline">
				<p>
					<strong><?php esc_html_e( 'WordPress is installed in a subfolder here.', 'kai-vibe' ); ?></strong>
					<?php esc_html_e( 'One-click connection still works with apps that follow the pointer this site sends them, which is most of them. An app that insists on looking at the very top of the domain will not find it, and will need a key instead.', 'kai-vibe' ); ?>
				</p>
			</div>
		<?php endif; ?>
	</details>

	<!-- ── What to say ───────────────────────────────────────────────────── -->

	<div class="kaiv-card">
		<h2><?php esc_html_e( 'Once connected, try asking for…', 'kai-vibe' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Talk to it the way you would talk to an assistant. You do not need to know any commands.', 'kai-vibe' ); ?></p>

		<div class="kaiv-examples">
			<?php
			$kaiv_examples = array(
				__( 'Writing', 'kai-vibe' )     => array(
					__( '“Draft a blog post about our new opening hours, and match the style of my last three posts.”', 'kai-vibe' ),
					__( '“Give every published post a proper excerpt — show me the list first.”', 'kai-vibe' ),
				),
				__( 'Fixing', 'kai-vibe' )      => array(
					__( '“The About page looks broken. Work out why and fix it.”', 'kai-vibe' ),
					__( '“Find every page that still mentions our old phone number and update it.”', 'kai-vibe' ),
				),
				__( 'Tidying up', 'kai-vibe' )  => array(
					__( '“Add alt text to any image that is missing it.”', 'kai-vibe' ),
					__( '“Which of my plugins are out of date or no longer being used?”', 'kai-vibe' ),
				),
				__( 'Checking', 'kai-vibe' )    => array(
					__( '“Give me a health check of this site and tell me what to worry about.”', 'kai-vibe' ),
					__( '“What changed on the site this week?”', 'kai-vibe' ),
				),
			);

			foreach ( $kaiv_examples as $kaiv_group => $kaiv_lines ) :
				?>
				<div class="kaiv-example-group">
					<h3><?php echo esc_html( $kaiv_group ); ?></h3>
					<ul>
						<?php foreach ( $kaiv_lines as $kaiv_line ) : ?>
							<li><?php echo esc_html( $kaiv_line ); ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endforeach; ?>
		</div>
	</div>

	<!-- ── Safety ────────────────────────────────────────────────────────── -->

	<div class="kaiv-card">
		<h2><?php esc_html_e( 'What keeps this safe', 'kai-vibe' ); ?></h2>

		<div class="kaiv-safety">
			<div>
				<h3><?php esc_html_e( 'It asks first', 'kai-vibe' ); ?></h3>
				<p><?php esc_html_e( 'Anything risky — deleting things, installing plugins, changing your theme — stops and waits for you to approve it. You will see a notice in your dashboard.', 'kai-vibe' ); ?></p>
			</div>
			<div>
				<h3><?php esc_html_e( 'You can undo it', 'kai-vibe' ); ?></h3>
				<p><?php esc_html_e( 'Every change is saved with a copy of what was there before. If something goes wrong, press Undo on the Changes screen.', 'kai-vibe' ); ?></p>
			</div>
			<div>
				<h3><?php esc_html_e( 'It cannot do more than you allow', 'kai-vibe' ); ?></h3>
				<p><?php esc_html_e( 'Each key is limited to the jobs you tick, and to the permissions of the user account you point it at. It never sees passwords.', 'kai-vibe' ); ?></p>
			</div>
			<div>
				<h3><?php esc_html_e( 'You can watch everything', 'kai-vibe' ); ?></h3>
				<p><?php esc_html_e( 'The Activity screen records every single thing the assistant did, and when. Nothing happens invisibly.', 'kai-vibe' ); ?></p>
			</div>
		</div>
	</div>

	<!-- ── Status + technical detail, folded away ────────────────────────── -->

	<div class="kaiv-card">
		<h2><?php esc_html_e( 'Status', 'kai-vibe' ); ?></h2>

		<ul class="kaiv-status">
			<li>
				<span class="kaiv-dot <?php echo esc_attr( $kaiv_connected ? 'is-on' : 'is-warn' ); ?>"></span>
				<?php
				echo esc_html(
					$kaiv_connected
						? __( 'Ready to connect', 'kai-vibe' )
						: __( 'Not ready yet — work through the steps above', 'kai-vibe' )
				);
				?>
			</li>
			<li>
				<span class="kaiv-dot <?php echo esc_attr( kaiv_setting( 'enabled', true ) ? 'is-on' : 'is-off' ); ?>"></span>
				<?php
				echo esc_html(
					kaiv_setting( 'enabled', true )
						? __( 'Connections are switched on', 'kai-vibe' )
						: __( 'Connections are switched off in Settings', 'kai-vibe' )
				);
				?>
			</li>
			<li>
				<span class="kaiv-dot <?php echo esc_attr( kaiv_setting( 'approval_required', true ) ? 'is-on' : 'is-warn' ); ?>"></span>
				<?php
				echo esc_html(
					kaiv_setting( 'approval_required', true )
						? __( 'Risky actions need your approval', 'kai-vibe' )
						: __( 'Risky actions run without asking — turn approvals back on in Settings', 'kai-vibe' )
				);
				?>
			</li>
			<li>
				<span class="kaiv-dot is-on"></span>
				<?php
				printf(
					/* translators: %d: number of jobs. */
					esc_html__( '%d jobs available to the assistant', 'kai-vibe' ),
					(int) kaiv()->tools()->count()
				);
				?>
			</li>
		</ul>

		<details class="kaiv-technical">
			<summary><?php esc_html_e( 'Technical details', 'kai-vibe' ); ?></summary>

			<p><?php esc_html_e( 'KAI Vibe turns this site into an MCP (Model Context Protocol) server. It is served by WordPress itself — there is no third-party service in between, and your content is never sent anywhere except to the AI assistant you connect.', 'kai-vibe' ); ?></p>

			<table class="widefat striped">
				<tbody>
					<tr><td><?php esc_html_e( 'Endpoint', 'kai-vibe' ); ?></td><td><code><?php echo esc_html( $endpoint ); ?></code></td></tr>
					<tr><td><?php esc_html_e( 'Transport', 'kai-vibe' ); ?></td><td><code>Streamable HTTP</code></td></tr>
					<tr><td><?php esc_html_e( 'Protocol version', 'kai-vibe' ); ?></td><td><code><?php echo esc_html( \KaiVibe\Mcp\Server::PROTOCOL_VERSION ); ?></code></td></tr>
					<tr><td><?php esc_html_e( 'Authentication', 'kai-vibe' ); ?></td><td><code>OAuth 2.1 + PKCE</code>, <?php esc_html_e( 'or', 'kai-vibe' ); ?> <code>Authorization: Bearer &lt;key&gt;</code></td></tr>
					<tr><td><?php esc_html_e( 'Client registration', 'kai-vibe' ); ?></td><td><code><?php esc_html_e( 'Dynamic (RFC 7591) — no client ID or secret', 'kai-vibe' ); ?></code></td></tr>
					<tr><td><?php esc_html_e( 'Resource metadata', 'kai-vibe' ); ?></td><td><code><?php echo esc_html( \KaiVibe\Auth\OAuth::resource_metadata_url() ); ?></code></td></tr>
					<tr><td><?php esc_html_e( 'Authorization server', 'kai-vibe' ); ?></td><td><code><?php echo esc_html( \KaiVibe\Auth\OAuth::issuer() ); ?></code></td></tr>
					<tr><td><?php esc_html_e( 'Status check', 'kai-vibe' ); ?></td><td><code><?php echo esc_html( rest_url( KAIV_REST_NS . '/info' ) ); ?></code></td></tr>
				</tbody>
			</table>

			<p><?php esc_html_e( 'Confirm discovery is reachable:', 'kai-vibe' ); ?></p>
			<pre class="kaiv-pre"><code>curl -s <?php echo esc_html( \KaiVibe\Auth\OAuth::resource_metadata_url() ); ?></code></pre>

			<p><?php esc_html_e( 'Test the connection from a terminal:', 'kai-vibe' ); ?></p>
			<pre class="kaiv-pre"><code>curl -s <?php echo esc_html( $endpoint ); ?> \
  -H "Authorization: Bearer YOUR-KEY" \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'</code></pre>
		</details>
	</div>
</div>
