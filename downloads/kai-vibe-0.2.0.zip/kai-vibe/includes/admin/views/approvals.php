<?php
/**
 * Approval queue.
 *
 * @package KaiVibe
 *
 * @var array $pending Requests awaiting a decision.
 * @var array $history Recently decided requests.
 */

defined( 'ABSPATH' ) || exit;

use KaiVibe\Security\Approval;
?>
<div class="wrap kaiv-wrap">
	<h1><?php esc_html_e( 'Approvals', 'kai-vibe' ); ?></h1>

	<p class="kaiv-lede">
		<?php esc_html_e( 'Destructive operations stop here and wait for you. Approving one lets the agent complete that exact operation once — same tool, same arguments. Anything else needs a fresh approval.', 'kai-vibe' ); ?>
	</p>

	<?php \KaiVibe\Admin\Admin::notice(); ?>

	<?php if ( ! kaiv_setting( 'approval_required', true ) ) : ?>
		<div class="notice notice-warning inline">
			<p><?php esc_html_e( 'The approval gate is switched off, so agents perform destructive operations without asking. Nothing will queue here.', 'kai-vibe' ); ?></p>
		</div>
	<?php endif; ?>

	<h2><?php esc_html_e( 'Waiting on you', 'kai-vibe' ); ?></h2>

	<?php if ( empty( $pending ) ) : ?>
		<p><?php esc_html_e( 'Nothing waiting.', 'kai-vibe' ); ?></p>
	<?php else : ?>
		<?php foreach ( $pending as $kaiv_request ) : ?>
			<?php $kaiv_user = get_userdata( (int) $kaiv_request['user_id'] ); ?>
			<div class="kaiv-card kaiv-approval">
				<h3>
					<code><?php echo esc_html( $kaiv_request['tool'] ); ?></code>
					<span class="kaiv-muted">
						<?php
						printf(
							/* translators: 1: user login, 2: relative time. */
							esc_html__( 'requested by %1$s, %2$s ago', 'kai-vibe' ),
							esc_html( $kaiv_user ? $kaiv_user->user_login : 'unknown' ),
							esc_html( human_time_diff( $kaiv_request['created'] ) )
						);
						?>
					</span>
				</h3>

				<p class="kaiv-summary"><?php echo esc_html( $kaiv_request['summary'] ); ?></p>

				<details>
					<summary><?php esc_html_e( 'Full arguments', 'kai-vibe' ); ?></summary>
					<pre class="kaiv-pre"><code><?php echo esc_html( wp_json_encode( $kaiv_request['arguments'], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></code></pre>
				</details>

				<p class="kaiv-muted">
					<?php
					printf(
						/* translators: %s: relative time. */
						esc_html__( 'Expires in %s.', 'kai-vibe' ),
						esc_html( human_time_diff( time(), $kaiv_request['expires'] ) )
					);
					?>
				</p>

				<div class="kaiv-actions">
					<form method="post" class="kaiv-inline">
						<?php wp_nonce_field( 'kaiv_approve' ); ?>
						<input type="hidden" name="kaiv_action" value="approve">
						<input type="hidden" name="approval_id" value="<?php echo esc_attr( $kaiv_request['id'] ); ?>">
						<button class="button button-primary"><?php esc_html_e( 'Approve', 'kai-vibe' ); ?></button>
					</form>

					<form method="post" class="kaiv-inline">
						<?php wp_nonce_field( 'kaiv_deny' ); ?>
						<input type="hidden" name="kaiv_action" value="deny">
						<input type="hidden" name="approval_id" value="<?php echo esc_attr( $kaiv_request['id'] ); ?>">
						<button class="button"><?php esc_html_e( 'Decline', 'kai-vibe' ); ?></button>
					</form>
				</div>
			</div>
		<?php endforeach; ?>
	<?php endif; ?>

	<?php if ( ! empty( $history ) ) : ?>
		<h2><?php esc_html_e( 'Recently decided', 'kai-vibe' ); ?></h2>

		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Tool', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Summary', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Outcome', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'When', 'kai-vibe' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $history as $kaiv_request ) : ?>
				<tr>
					<td><code><?php echo esc_html( $kaiv_request['tool'] ); ?></code></td>
					<td><?php echo esc_html( $kaiv_request['summary'] ); ?></td>
					<td>
						<span class="kaiv-risk kaiv-risk-<?php echo Approval::DENIED === $kaiv_request['status'] ? 'critical' : 'low'; ?>">
							<?php echo esc_html( $kaiv_request['status'] ); ?>
						</span>
					</td>
					<td><?php echo esc_html( human_time_diff( isset( $kaiv_request['decided'] ) ? $kaiv_request['decided'] : $kaiv_request['created'] ) . ' ago' ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
</div>
