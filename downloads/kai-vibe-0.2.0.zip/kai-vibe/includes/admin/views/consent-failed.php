<?php
/**
 * Shown when a connection attempt cannot safely be bounced back to the app.
 *
 * @package KaiVibe
 *
 * @var string $kaiv_message Plain-language explanation.
 */

defined( 'ABSPATH' ) || exit;

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex, nofollow">
	<title><?php esc_html_e( 'Connection stopped', 'kai-vibe' ); ?></title>
	<style>
		:root {
			color-scheme: light dark;
			--kaiv-bg: #f1f2f4;
			--kaiv-card: #fff;
			--kaiv-ink: #1d2125;
			--kaiv-muted: #5c6670;
			--kaiv-line: #dfe2e6;
		}
		@media (prefers-color-scheme: dark) {
			:root {
				--kaiv-bg: #16181c;
				--kaiv-card: #202327;
				--kaiv-ink: #e8eaed;
				--kaiv-muted: #a3abb4;
				--kaiv-line: #343940;
			}
		}
		* { box-sizing: border-box; }
		body {
			margin: 0;
			padding: 24px 16px 64px;
			background: var(--kaiv-bg);
			color: var(--kaiv-ink);
			font: 16px/1.55 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
			display: flex;
			justify-content: center;
		}
		.kaiv-card {
			width: 100%;
			max-width: 460px;
			background: var(--kaiv-card);
			border: 1px solid var(--kaiv-line);
			border-radius: 14px;
			padding: 28px 24px;
			text-align: center;
			box-shadow: 0 1px 2px rgba(0,0,0,.05), 0 8px 24px rgba(0,0,0,.06);
		}
		h1 { margin: 0 0 10px; font-size: 20px; font-weight: 650; }
		p { margin: 0; color: var(--kaiv-muted); font-size: 14.5px; }
	</style>
</head>
<body>
	<div class="kaiv-card">
		<h1><?php esc_html_e( 'Connection stopped', 'kai-vibe' ); ?></h1>
		<p><?php echo esc_html( $kaiv_message ); ?></p>
	</div>
</body>
</html>
