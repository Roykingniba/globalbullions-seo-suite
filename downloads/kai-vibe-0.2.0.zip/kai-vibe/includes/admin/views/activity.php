<?php
/**
 * Audit log.
 *
 * @package KaiVibe
 *
 * @var array  $log    Query result { items, total, pages }.
 * @var int    $page   Current page.
 * @var string $search Current search term.
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap kaiv-wrap">
	<h1><?php esc_html_e( 'Activity', 'kai-vibe' ); ?></h1>

	<p class="kaiv-lede">
		<?php esc_html_e( 'Every tool call, authentication attempt and token change, with the arguments used. Values that look like credentials are redacted before they are written.', 'kai-vibe' ); ?>
	</p>

	<form method="get" class="kaiv-search">
		<input type="hidden" name="page" value="kai-vibe-activity">
		<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>"
			placeholder="<?php esc_attr_e( 'Search actions and arguments…', 'kai-vibe' ); ?>" class="regular-text">
		<button class="button"><?php esc_html_e( 'Search', 'kai-vibe' ); ?></button>
	</form>

	<?php if ( empty( $log['items'] ) ) : ?>
		<p><?php esc_html_e( 'Nothing logged yet.', 'kai-vibe' ); ?></p>
	<?php else : ?>
		<table class="widefat striped kaiv-log">
			<thead>
				<tr>
					<th><?php esc_html_e( 'When', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Action', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Token', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'User', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Result', 'kai-vibe' ); ?></th>
					<th><?php esc_html_e( 'Detail', 'kai-vibe' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $log['items'] as $kaiv_row ) : ?>
				<?php
				$kaiv_user  = get_userdata( (int) $kaiv_row['user_id'] );
				$kaiv_token = \KaiVibe\Auth\TokenManager::get( $kaiv_row['token_id'] );
				?>
				<tr>
					<td title="<?php echo esc_attr( $kaiv_row['created_at'] ); ?>">
						<?php echo esc_html( human_time_diff( strtotime( $kaiv_row['created_at'] . ' UTC' ) ) . ' ago' ); ?>
					</td>
					<td><code><?php echo esc_html( $kaiv_row['action'] ); ?></code></td>
					<td>
						<?php echo wp_kses_post( $kaiv_token ? esc_html( $kaiv_token['label'] ) : '<span class="kaiv-muted">—</span>' ); ?>
					</td>
					<td><?php echo wp_kses_post( $kaiv_user ? esc_html( $kaiv_user->user_login ) : '<span class="kaiv-muted">—</span>' ); ?></td>
					<td>
						<span class="kaiv-risk kaiv-risk-<?php echo 'ok' === $kaiv_row['status'] ? 'low' : 'high'; ?>">
							<?php echo esc_html( $kaiv_row['status'] ); ?>
						</span>
						<?php if ( $kaiv_row['duration_ms'] ) : ?>
							<span class="kaiv-muted"><?php echo esc_html( $kaiv_row['duration_ms'] . 'ms' ); ?></span>
						<?php endif; ?>
					</td>
					<td>
						<?php if ( ! empty( $kaiv_row['context'] ) ) : ?>
							<details>
								<summary><?php esc_html_e( 'View', 'kai-vibe' ); ?></summary>
								<pre class="kaiv-pre"><code><?php echo esc_html( wp_json_encode( $kaiv_row['context'], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></code></pre>
							</details>
						<?php else : ?>
							<span class="kaiv-muted">—</span>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>

		<?php if ( $log['pages'] > 1 ) : ?>
			<div class="tablenav"><div class="tablenav-pages">
				<?php
				echo wp_kses_post(
					paginate_links(
						array(
							'base'    => add_query_arg( 'paged', '%#%' ),
							'format'  => '',
							'current' => $page,
							'total'   => (int) $log['pages'],
						)
					)
				);
				?>
			</div></div>
		<?php endif; ?>
	<?php endif; ?>
</div>
