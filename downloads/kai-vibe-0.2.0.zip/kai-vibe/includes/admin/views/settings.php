<?php
/**
 * Settings.
 *
 * @package KaiVibe
 *
 * @var array $settings Current settings.
 */

defined( 'ABSPATH' ) || exit;

$kaiv_cli_available = \KaiVibe\Tools\CliTools::is_available();
?>
<div class="wrap kaiv-wrap">
	<h1><?php esc_html_e( 'Settings', 'kai-vibe' ); ?></h1>

	<?php \KaiVibe\Admin\Admin::notice(); ?>

	<form method="post">
		<?php wp_nonce_field( 'kaiv_save_settings' ); ?>
		<input type="hidden" name="kaiv_action" value="save_settings">

		<h2><?php esc_html_e( 'Endpoint', 'kai-vibe' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'MCP endpoint', 'kai-vibe' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="enabled" value="1" <?php checked( $settings['enabled'] ); ?>>
						<?php esc_html_e( 'Accept connections', 'kai-vibe' ); ?>
					</label>
					<p class="description"><?php esc_html_e( 'Unticking this is the fastest way to cut every agent off at once, without deleting tokens.', 'kai-vibe' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'One-click connection', 'kai-vibe' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="oauth_enabled" value="1" <?php checked( $settings['oauth_enabled'] ); ?>>
						<?php esc_html_e( 'Let an assistant connect itself, with your approval', 'kai-vibe' ); ?>
					</label>
					<p class="description"><?php esc_html_e( 'On: an assistant given this site\'s address asks the person to log in to WordPress and press Connect, and that is the whole setup — nothing to copy or paste. Off: connections only work with a key you create by hand on the Tokens screen.', 'kai-vibe' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="kaiv-ip"><?php esc_html_e( 'IP allowlist', 'kai-vibe' ); ?></label></th>
				<td>
					<textarea name="ip_allowlist" id="kaiv-ip" rows="3" class="large-text code"
						placeholder="203.0.113.4&#10;198.51.100.0/24"><?php echo esc_textarea( implode( "\n", (array) $settings['ip_allowlist'] ) ); ?></textarea>
					<p class="description"><?php esc_html_e( 'One address or CIDR block per line. Leave empty to allow any. Only set this if your agent connects from a fixed address.', 'kai-vibe' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Rate limit', 'kai-vibe' ); ?></th>
				<td>
					<input type="number" name="rate_limit" value="<?php echo esc_attr( $settings['rate_limit'] ); ?>" min="0" class="small-text">
					<?php esc_html_e( 'calls per', 'kai-vibe' ); ?>
					<input type="number" name="rate_window" value="<?php echo esc_attr( $settings['rate_window'] ); ?>" min="1" class="small-text">
					<?php esc_html_e( 'seconds, per token', 'kai-vibe' ); ?>
					<p class="description"><?php esc_html_e( 'Zero disables the limit. The default stops a looping agent from hammering the database without getting in the way of normal work.', 'kai-vibe' ); ?></p>
				</td>
			</tr>
		</table>

		<h2><?php esc_html_e( 'Approvals', 'kai-vibe' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'Human approval', 'kai-vibe' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="approval_required" value="1" <?php checked( $settings['approval_required'] ); ?>>
						<?php esc_html_e( 'Require approval for destructive operations', 'kai-vibe' ); ?>
					</label>
					<p class="description"><?php esc_html_e( 'Covers installing and deleting plugins, switching themes, writing files, SQL writes, WP-CLI, user changes and permanent deletions. Strongly recommended on a live site.', 'kai-vibe' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="kaiv-ttl"><?php esc_html_e( 'Approval window', 'kai-vibe' ); ?></label></th>
				<td>
					<input type="number" name="approval_ttl_minutes" id="kaiv-ttl" value="<?php echo esc_attr( (int) round( $settings['approval_ttl'] / MINUTE_IN_SECONDS ) ); ?>" min="1" class="small-text">
					<?php esc_html_e( 'minutes', 'kai-vibe' ); ?>
					<p class="description"><?php esc_html_e( 'How long a request stays open, and how long an approval remains usable once granted.', 'kai-vibe' ); ?></p>
				</td>
			</tr>
		</table>

		<h2><?php esc_html_e( 'Filesystem', 'kai-vibe' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'Allowed roots', 'kai-vibe' ); ?></th>
				<td>
					<p><code><?php echo esc_html( WP_CONTENT_DIR ); ?></code> <span class="kaiv-muted"><?php esc_html_e( '(always allowed)', 'kai-vibe' ); ?></span></p>
					<textarea name="fs_extra_roots" rows="2" class="large-text code"><?php echo esc_textarea( implode( "\n", (array) $settings['fs_extra_roots'] ) ); ?></textarea>
					<p class="description"><?php esc_html_e( 'Extra absolute paths, one per line. Everything outside these roots is refused, and wp-config.php is never readable regardless.', 'kai-vibe' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'PHP files', 'kai-vibe' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="fs_allow_php" value="1" <?php checked( $settings['fs_allow_php'] ); ?>>
						<?php esc_html_e( 'Allow agents to write PHP files', 'kai-vibe' ); ?>
					</label>
					<p class="description"><?php esc_html_e( 'Needed for real theme and plugin work. Writes are syntax-checked before they land, but a logic error in an active theme still breaks the site — turn this off on production unless you mean it.', 'kai-vibe' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="kaiv-max"><?php esc_html_e( 'Maximum file size', 'kai-vibe' ); ?></label></th>
				<td>
					<input type="number" name="fs_max_bytes" id="kaiv-max" value="<?php echo esc_attr( (int) round( $settings['fs_max_bytes'] / 1024 ) ); ?>" min="1" class="small-text"> KB
				</td>
			</tr>
		</table>

		<h2><?php esc_html_e( 'WP-CLI', 'kai-vibe' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'Command execution', 'kai-vibe' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="cli_enabled" value="1" <?php checked( $settings['cli_enabled'] ); ?> <?php disabled( ! $kaiv_cli_available ); ?>>
						<?php esc_html_e( 'Allow agents to run WP-CLI commands', 'kai-vibe' ); ?>
					</label>
					<?php if ( ! $kaiv_cli_available ) : ?>
						<p class="description"><strong><?php esc_html_e( 'This server does not let PHP start processes, so WP-CLI cannot be used here.', 'kai-vibe' ); ?></strong></p>
					<?php else : ?>
						<p class="description"><?php esc_html_e( 'The most powerful thing in this plugin. Every command is denylist-checked and approval-gated, but it still runs as the web server user.', 'kai-vibe' ); ?></p>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="kaiv-binary"><?php esc_html_e( 'Binary path', 'kai-vibe' ); ?></label></th>
				<td>
					<input type="text" name="cli_binary" id="kaiv-binary" value="<?php echo esc_attr( $settings['cli_binary'] ); ?>" class="regular-text code">
					<p class="description"><?php esc_html_e( 'Usually just "wp". Use a full path if it is not on the web server\'s PATH.', 'kai-vibe' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="kaiv-timeout"><?php esc_html_e( 'Timeout', 'kai-vibe' ); ?></label></th>
				<td>
					<input type="number" name="cli_timeout" id="kaiv-timeout" value="<?php echo esc_attr( $settings['cli_timeout'] ); ?>" min="5" class="small-text">
					<?php esc_html_e( 'seconds', 'kai-vibe' ); ?>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="kaiv-denylist"><?php esc_html_e( 'Blocked commands', 'kai-vibe' ); ?></label></th>
				<td>
					<textarea name="cli_denylist" id="kaiv-denylist" rows="5" class="large-text code"><?php echo esc_textarea( implode( "\n", (array) $settings['cli_denylist'] ) ); ?></textarea>
					<p class="description"><?php esc_html_e( 'One prefix per line. Any command starting with one of these is refused.', 'kai-vibe' ); ?></p>
				</td>
			</tr>
		</table>

		<h2><?php esc_html_e( 'Database', 'kai-vibe' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'SQL access', 'kai-vibe' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="db_read_enabled" value="1" <?php checked( $settings['db_read_enabled'] ); ?>>
						<?php esc_html_e( 'Allow read queries (SELECT, SHOW, DESCRIBE)', 'kai-vibe' ); ?>
					</label><br>
					<label>
						<input type="checkbox" name="db_write_enabled" value="1" <?php checked( $settings['db_write_enabled'] ); ?>>
						<?php esc_html_e( 'Allow write statements (INSERT, UPDATE, DELETE)', 'kai-vibe' ); ?>
					</label>
					<p class="description"><?php esc_html_e( 'Raw writes skip the hooks WordPress uses to keep caches and derived data correct, so plugin data can end up inconsistent. Leave writes off unless a specific job needs them. DROP, TRUNCATE and GRANT are refused either way, as are writes to the user tables.', 'kai-vibe' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="kaiv-rows"><?php esc_html_e( 'Row cap', 'kai-vibe' ); ?></label></th>
				<td>
					<input type="number" name="db_max_rows" id="kaiv-rows" value="<?php echo esc_attr( $settings['db_max_rows'] ); ?>" min="1" class="small-text">
					<p class="description"><?php esc_html_e( 'Maximum rows returned from a single query.', 'kai-vibe' ); ?></p>
				</td>
			</tr>
		</table>

		<h2><?php esc_html_e( 'Logging', 'kai-vibe' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'Audit log', 'kai-vibe' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="audit_payloads" value="1" <?php checked( $settings['audit_payloads'] ); ?>>
						<?php esc_html_e( 'Record full tool arguments', 'kai-vibe' ); ?>
					</label>
					<p class="description"><?php esc_html_e( 'Without this you get the what and when but not the detail. Credential-looking values are redacted either way.', 'kai-vibe' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="kaiv-audit-days"><?php esc_html_e( 'Keep audit log for', 'kai-vibe' ); ?></label></th>
				<td>
					<input type="number" name="audit_retention_days" id="kaiv-audit-days" value="<?php echo esc_attr( $settings['audit_retention_days'] ); ?>" min="0" class="small-text">
					<?php esc_html_e( 'days (0 = forever)', 'kai-vibe' ); ?>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="kaiv-journal-days"><?php esc_html_e( 'Keep change journal for', 'kai-vibe' ); ?></label></th>
				<td>
					<input type="number" name="journal_retention_days" id="kaiv-journal-days" value="<?php echo esc_attr( $settings['journal_retention_days'] ); ?>" min="0" class="small-text">
					<?php esc_html_e( 'days (0 = forever)', 'kai-vibe' ); ?>
					<p class="description"><?php esc_html_e( 'The journal stores the previous contents of everything an agent overwrote, so it is the larger of the two tables. Longer retention means more undo history and more disk.', 'kai-vibe' ); ?></p>
				</td>
			</tr>
		</table>

		<?php submit_button(); ?>
	</form>
</div>
