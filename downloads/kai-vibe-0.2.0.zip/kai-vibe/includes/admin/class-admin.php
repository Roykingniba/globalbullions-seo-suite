<?php
/**
 * The wp-admin side: connect, tokens, approvals, activity and changes.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Admin;

use KaiVibe\Auth\Scopes;
use KaiVibe\Auth\TokenManager;
use KaiVibe\Mcp\RestController;
use KaiVibe\Security\Approval;
use KaiVibe\Settings;

defined( 'ABSPATH' ) || exit;

class Admin {

	const CAPABILITY = 'manage_options';
	const SLUG       = 'kai-vibe';

	/** @var Admin|null */
	private static $instance = null;

	/** @var array|null Token shown once, immediately after creation. */
	private $fresh_token = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function hooks() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_init', array( $this, 'handle_actions' ) );
		add_action( 'admin_notices', array( $this, 'pending_approval_notice' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( KAIV_FILE ), array( $this, 'action_links' ) );
	}

	public function menu() {
		$pending = count( Approval::pending() );
		$badge   = $pending ? sprintf( ' <span class="update-plugins count-%1$d"><span class="update-count">%1$d</span></span>', $pending ) : '';

		add_menu_page(
			__( 'KAI Vibe', 'kai-vibe' ),
			__( 'KAI Vibe', 'kai-vibe' ) . $badge,
			self::CAPABILITY,
			self::SLUG,
			array( $this, 'render_connect' ),
			self::menu_icon(),
			72
		);

		$pages = array(
			self::SLUG                => __( 'Connect', 'kai-vibe' ),
			self::SLUG . '-tokens'    => __( 'Tokens', 'kai-vibe' ),
			self::SLUG . '-approvals' => __( 'Approvals', 'kai-vibe' ) . $badge,
			self::SLUG . '-activity'  => __( 'Activity', 'kai-vibe' ),
			self::SLUG . '-changes'   => __( 'Changes', 'kai-vibe' ),
			self::SLUG . '-settings'  => __( 'Settings', 'kai-vibe' ),
		);

		$callbacks = array(
			self::SLUG                => 'render_connect',
			self::SLUG . '-tokens'    => 'render_tokens',
			self::SLUG . '-approvals' => 'render_approvals',
			self::SLUG . '-activity'  => 'render_activity',
			self::SLUG . '-changes'   => 'render_changes',
			self::SLUG . '-settings'  => 'render_settings',
		);

		foreach ( $pages as $slug => $title ) {
			add_submenu_page(
				self::SLUG,
				wp_strip_all_tags( $title ),
				$title,
				self::CAPABILITY,
				$slug,
				array( $this, $callbacks[ $slug ] )
			);
		}
	}

	/**
	 * The mark as a data URI, for the admin menu.
	 *
	 * This mirrors assets/menu-icon.svg but is inlined, because it is needed on
	 * every admin page load and reading it from disk each time would be waste.
	 * WordPress tints menu icons by opacity rather than fill, so it ships in the
	 * default menu grey instead of trying to inherit a colour.
	 *
	 * @return string
	 */
	private static function menu_icon() {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256">'
			. '<g fill="none" stroke="#a7aaad" stroke-width="26" stroke-linecap="round" stroke-linejoin="round">'
			. '<path d="M76 46V210"/><path d="M76 128L178 52"/><path d="M76 128L178 204"/>'
			. '</g>'
			. '<circle cx="178" cy="52" r="18" fill="#a7aaad"/>'
			. '<circle cx="178" cy="204" r="18" fill="#a7aaad"/>'
			. '</svg>';

		// Not obfuscation: add_menu_page() only accepts an icon as a URL, and a
		// data URI is the documented way to pass an inline SVG.
		return 'data:image/svg+xml;base64,' . base64_encode( $svg ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	/**
	 * @param string $hook Current admin page.
	 */
	public function assets( $hook ) {
		if ( false === strpos( $hook, self::SLUG ) ) {
			return;
		}

		wp_enqueue_style( 'kaiv-admin', KAIV_URL . 'assets/admin.css', array(), KAIV_VERSION );
		wp_enqueue_script( 'kaiv-admin', KAIV_URL . 'assets/admin.js', array(), KAIV_VERSION, true );
	}

	/**
	 * @param array $links Plugin row links.
	 * @return array
	 */
	public function action_links( $links ) {
		array_unshift(
			$links,
			sprintf( '<a href="%s">%s</a>', esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ), esc_html__( 'Connect', 'kai-vibe' ) )
		);

		return $links;
	}

	/**
	 * A pending approval is useless if nobody notices it.
	 */
	public function pending_approval_notice() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}

		$screen = get_current_screen();

		if ( $screen && false !== strpos( $screen->id, self::SLUG . '-approvals' ) ) {
			return;
		}

		$pending = Approval::pending();

		if ( ! $pending ) {
			return;
		}

		printf(
			'<div class="notice notice-warning"><p>%s <a href="%s" class="button button-small">%s</a></p></div>',
			esc_html(
				sprintf(
					/* translators: %d: number of requests. */
					_n(
						'An AI agent is waiting on %d approval.',
						'An AI agent is waiting on %d approvals.',
						count( $pending ),
						'kai-vibe'
					),
					count( $pending )
				)
			),
			esc_url( Approval::url() ),
			esc_html__( 'Review', 'kai-vibe' )
		);
	}

	/**
	 * Every form on every page routes through here.
	 */
	public function handle_actions() {
		if ( empty( $_POST['kaiv_action'] ) || ! current_user_can( self::CAPABILITY ) ) {
			return;
		}

		$action = sanitize_key( wp_unslash( $_POST['kaiv_action'] ) );

		check_admin_referer( 'kaiv_' . $action );

		switch ( $action ) {
			case 'create_token':
				$this->create_token();
				break;

			case 'revoke_token':
				TokenManager::revoke( sanitize_text_field( wp_unslash( $_POST['token_id'] ?? '' ) ) );
				$this->redirect( self::SLUG . '-tokens', 'revoked' );
				break;

			case 'delete_token':
				TokenManager::delete( sanitize_text_field( wp_unslash( $_POST['token_id'] ?? '' ) ) );
				$this->redirect( self::SLUG . '-tokens', 'deleted' );
				break;

			case 'approve':
				Approval::mark( sanitize_text_field( wp_unslash( $_POST['approval_id'] ?? '' ) ), Approval::APPROVED );
				$this->redirect( self::SLUG . '-approvals', 'approved' );
				break;

			case 'deny':
				Approval::mark( sanitize_text_field( wp_unslash( $_POST['approval_id'] ?? '' ) ), Approval::DENIED );
				$this->redirect( self::SLUG . '-approvals', 'denied' );
				break;

			case 'undo':
				$undone = \KaiVibe\Security\Journal::undo( isset( $_POST['change_id'] ) ? absint( wp_unslash( $_POST['change_id'] ) ) : 0 );

				// Journal::undo() reports every failure as a WP_Error. Ignoring
				// it told the owner a rollback happened when it had not.
				if ( is_wp_error( $undone ) ) {
					set_transient( 'kaiv_admin_error_' . get_current_user_id(), $undone->get_error_message(), 60 );
					$this->redirect( self::SLUG . '-changes', 'undo_failed' );
				}

				$this->redirect( self::SLUG . '-changes', 'undone' );
				break;

			case 'save_settings':
				$this->save_settings();
				break;
		}
	}

	private function create_token() {
		$result = TokenManager::create(
			array(
				'label'   => sanitize_text_field( wp_unslash( $_POST['label'] ?? '' ) ),
				'scopes'  => isset( $_POST['scopes'] )
					? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['scopes'] ) )
					: array(),
				'user_id' => isset( $_POST['user_id'] ) ? absint( wp_unslash( $_POST['user_id'] ) ) : get_current_user_id(),
				'expires' => ! empty( $_POST['expires_days'] )
					? time() + ( absint( wp_unslash( $_POST['expires_days'] ) ) * DAY_IN_SECONDS )
					: 0,
			)
		);

		if ( is_wp_error( $result ) ) {
			set_transient( 'kaiv_admin_error_' . get_current_user_id(), $result->get_error_message(), 60 );
			$this->redirect( self::SLUG . '-tokens' );
			return;
		}

		// Held for exactly one page load — the plaintext is never stored.
		set_transient( 'kaiv_fresh_token_' . get_current_user_id(), $result, 120 );

		$this->redirect( self::SLUG . '-tokens', 'created' );
	}

	private function save_settings() {
		$post = wp_unslash( $_POST );

		$values = array(
			'enabled'                => ! empty( $post['enabled'] ),
			'oauth_enabled'          => ! empty( $post['oauth_enabled'] ),
			'fs_allow_php'           => ! empty( $post['fs_allow_php'] ),
			'fs_max_bytes'           => max( 1024, (int) ( $post['fs_max_bytes'] ?? 0 ) * 1024 ),
			'fs_extra_roots'         => $this->lines( $post['fs_extra_roots'] ?? '' ),
			'cli_enabled'            => ! empty( $post['cli_enabled'] ),
			'cli_binary'             => sanitize_text_field( $post['cli_binary'] ?? 'wp' ),
			'cli_timeout'            => max( 5, (int) ( $post['cli_timeout'] ?? 120 ) ),
			'cli_denylist'           => $this->lines( $post['cli_denylist'] ?? '' ),
			'db_read_enabled'        => ! empty( $post['db_read_enabled'] ),
			'db_write_enabled'       => ! empty( $post['db_write_enabled'] ),
			'db_max_rows'            => max( 1, (int) ( $post['db_max_rows'] ?? 500 ) ),
			'approval_required'      => ! empty( $post['approval_required'] ),
			'approval_ttl'           => max( 60, (int) ( $post['approval_ttl_minutes'] ?? 15 ) * MINUTE_IN_SECONDS ),
			'rate_limit'             => max( 0, (int) ( $post['rate_limit'] ?? 240 ) ),
			'rate_window'            => max( 1, (int) ( $post['rate_window'] ?? 60 ) ),
			'audit_retention_days'   => max( 0, (int) ( $post['audit_retention_days'] ?? 30 ) ),
			'audit_payloads'         => ! empty( $post['audit_payloads'] ),
			'journal_retention_days' => max( 0, (int) ( $post['journal_retention_days'] ?? 14 ) ),
			'ip_allowlist'           => $this->lines( $post['ip_allowlist'] ?? '' ),
		);

		Settings::update( $values );

		kaiv_audit( 'settings.saved', array( 'keys' => array_keys( $values ) ) );

		$this->redirect( self::SLUG . '-settings', 'saved' );
	}

	/**
	 * @param string $raw Textarea contents.
	 * @return string[]
	 */
	private function lines( $raw ) {
		$lines = preg_split( "/\r\n|\n|\r/", (string) $raw );
		$lines = array_map( 'sanitize_text_field', array_map( 'trim', (array) $lines ) );

		return array_values( array_filter( $lines, 'strlen' ) );
	}

	/**
	 * @param string $page   Page slug.
	 * @param string $notice Notice key.
	 */
	private function redirect( $page, $notice = '' ) {
		$url = admin_url( 'admin.php?page=' . $page );

		if ( $notice ) {
			$url = add_query_arg( 'kaiv_notice', $notice, $url );
		}

		wp_safe_redirect( $url );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Views
	 * ------------------------------------------------------------------ */

	public function render_connect() {
		$endpoint = rest_url( KAIV_REST_NS . RestController::ROUTE );
		$tokens   = TokenManager::all();

		require KAIV_DIR . 'includes/admin/views/connect.php';
	}

	public function render_tokens() {
		$fresh = get_transient( 'kaiv_fresh_token_' . get_current_user_id() );

		if ( $fresh ) {
			delete_transient( 'kaiv_fresh_token_' . get_current_user_id() );
		}

		$error = get_transient( 'kaiv_admin_error_' . get_current_user_id() );

		if ( $error ) {
			delete_transient( 'kaiv_admin_error_' . get_current_user_id() );
		}

		$tokens = TokenManager::all();
		$scopes = Scopes::all();

		require KAIV_DIR . 'includes/admin/views/tokens.php';
	}

	public function render_approvals() {
		$pending = Approval::pending();
		// Approval::all() is in insertion order, so slicing it unsorted showed
		// the twenty oldest decisions under a "Recently decided" heading.
		$history = array_filter(
			Approval::all(),
			static function ( $request ) {
				return Approval::PENDING !== $request['status'];
			}
		);

		usort(
			$history,
			static function ( $a, $b ) {
				$a_when = isset( $a['decided'] ) ? $a['decided'] : $a['created'];
				$b_when = isset( $b['decided'] ) ? $b['decided'] : $b['created'];

				return $b_when <=> $a_when;
			}
		);

		$history = array_slice( $history, 0, 20 );

		require KAIV_DIR . 'includes/admin/views/approvals.php';
	}

	public function render_activity() {
		$page   = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification
		$search = sanitize_text_field( wp_unslash( $_GET['s'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification

		$log = \KaiVibe\Security\AuditLog::query(
			array(
				'page'     => $page,
				'per_page' => 50,
				'search'   => $search,
			)
		);

		require KAIV_DIR . 'includes/admin/views/activity.php';
	}

	public function render_changes() {
		$page = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification

		$journal = \KaiVibe\Security\Journal::query(
			array(
				'page'           => $page,
				'per_page'       => 50,
				'include_undone' => true,
			)
		);

		require KAIV_DIR . 'includes/admin/views/changes.php';
	}

	public function render_settings() {
		$settings = Settings::all();

		require KAIV_DIR . 'includes/admin/views/settings.php';
	}

	/**
	 * Render the standard notice for a ?kaiv_notice= key.
	 */
	public static function notice() {
		// A deferred error message is set by whichever action failed. Render it
		// here so every screen shows it, not just Tokens.
		$detail = get_transient( 'kaiv_admin_error_' . get_current_user_id() );

		if ( $detail ) {
			delete_transient( 'kaiv_admin_error_' . get_current_user_id() );

			printf(
				'<div class="notice notice-error is-dismissible"><p>%s</p></div>',
				esc_html( $detail )
			);
		}

		$key = isset( $_GET['kaiv_notice'] ) ? sanitize_key( wp_unslash( $_GET['kaiv_notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

		if ( '' === $key ) {
			return;
		}

		$messages = array(
			'created'  => array( 'success', __( 'Token created. Copy it now — it is not shown again.', 'kai-vibe' ) ),
			'revoked'  => array( 'success', __( 'Token revoked. Any agent using it is now locked out.', 'kai-vibe' ) ),
			'deleted'  => array( 'success', __( 'Token deleted.', 'kai-vibe' ) ),
			'approved' => array( 'success', __( 'Approved. The agent can now complete that operation once.', 'kai-vibe' ) ),
			'denied'   => array( 'warning', __( 'Declined. The agent has been told not to retry.', 'kai-vibe' ) ),
			'undone'   => array( 'success', __( 'Change rolled back.', 'kai-vibe' ) ),
			'undo_failed' => array( 'error', __( 'That change could not be rolled back.', 'kai-vibe' ) ),
			'saved'    => array( 'success', __( 'Settings saved.', 'kai-vibe' ) ),
		);

		if ( ! isset( $messages[ $key ] ) ) {
			return;
		}

		printf(
			'<div class="notice notice-%s is-dismissible"><p>%s</p></div>',
			esc_attr( $messages[ $key ][0] ),
			esc_html( $messages[ $key ][1] )
		);
	}
}
