<?php
/**
 * Every tool call, auth attempt and token change lands here.
 *
 * The audit log is the thing that makes handing an agent the keys defensible:
 * the site owner can always answer "what did it do, and when".
 *
 * @package KaiVibe
 */

namespace KaiVibe\Security;

use KaiVibe\Auth\Authenticator;

defined( 'ABSPATH' ) || exit;

class AuditLog {

	/** @var bool|null Cached table-exists check. */
	private static $table_ready = null;

	/**
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'kaiv_audit_log';
	}

	/**
	 * @return bool
	 */
	private static function ready() {
		global $wpdb;

		if ( null === self::$table_ready ) {
			$table             = self::table();
			self::$table_ready = (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ); // phpcs:ignore WordPress.DB
		}

		return self::$table_ready;
	}

	/**
	 * @param string $action  Dotted action name, e.g. tool.create_post.
	 * @param array  $context Arbitrary detail. Sensitive keys are redacted.
	 */
	public static function record( $action, array $context = array() ) {
		global $wpdb;

		if ( ! self::ready() ) {
			return;
		}

		$auth = Authenticator::instance();

		$status   = isset( $context['status'] ) ? (string) $context['status'] : 'ok';
		$duration = isset( $context['duration_ms'] ) ? (int) $context['duration_ms'] : 0;

		unset( $context['status'], $context['duration_ms'] );

		if ( ! kaiv_setting( 'audit_payloads', true ) ) {
			$context = array_intersect_key( $context, array_flip( array( 'reason', 'label', 'token_id' ) ) );
		}

		$payload = wp_json_encode( self::redact( $context ) );

		// A single audit row must never be big enough to matter.
		if ( strlen( $payload ) > 64000 ) {
			$payload = wp_json_encode( array( 'truncated' => true, 'bytes' => strlen( $payload ) ) );
		}

		// Auth failures are logged from inside determine_current_user, where
		// asking for the current user would re-enter that filter.
		$user_id = $auth->is_resolving() ? 0 : get_current_user_id();

		$wpdb->insert( // phpcs:ignore WordPress.DB
			self::table(),
			array(
				'created_at'  => current_time( 'mysql', true ),
				'token_id'    => $auth->token_id(),
				'user_id'     => $user_id,
				'action'      => substr( (string) $action, 0, 120 ),
				'status'      => substr( $status, 0, 20 ),
				'duration_ms' => $duration,
				'ip'          => Authenticator::client_ip(),
				'context'     => $payload,
			),
			array( '%s', '%s', '%d', '%s', '%s', '%d', '%s', '%s' )
		);
	}

	/**
	 * Strip anything that looks like a credential before it reaches the log.
	 *
	 * @param mixed $data Context.
	 * @return mixed
	 */
	public static function redact( $data ) {
		if ( ! is_array( $data ) ) {
			return $data;
		}

		$sensitive = '/(pass(word)?|secret|token|api[_-]?key|salt|nonce|auth|private[_-]?key)/i';

		foreach ( $data as $key => $value ) {
			if ( is_string( $key ) && preg_match( $sensitive, $key ) ) {
				$data[ $key ] = '[redacted]';
			} elseif ( is_array( $value ) ) {
				$data[ $key ] = self::redact( $value );
			} elseif ( is_string( $value ) && strlen( $value ) > 4000 ) {
				$data[ $key ] = substr( $value, 0, 4000 ) . sprintf( '… [%d bytes truncated]', strlen( $value ) - 4000 );
			}
		}

		return $data;
	}

	/**
	 * @param array $args {
	 *     @type int    $per_page Rows per page.
	 *     @type int    $page     1-based page.
	 *     @type string $action   Action prefix filter.
	 *     @type string $token_id Token filter.
	 *     @type string $status   Status filter.
	 *     @type string $search   Free text against action and context.
	 * }
	 * @return array { items, total, pages }
	 */
	public static function query( array $args = array() ) {
		global $wpdb;

		if ( ! self::ready() ) {
			return array( 'items' => array(), 'total' => 0, 'pages' => 0 );
		}

		$args = wp_parse_args(
			$args,
			array(
				'per_page' => 50,
				'page'     => 1,
				'action'   => '',
				'token_id' => '',
				'status'   => '',
				'search'   => '',
			)
		);

		$per_page = max( 1, min( 500, (int) $args['per_page'] ) );
		$offset   = max( 0, ( (int) $args['page'] - 1 ) * $per_page );

		$where  = array( '1=1' );
		$params = array();

		if ( '' !== $args['action'] ) {
			$where[]  = 'action LIKE %s';
			$params[] = $wpdb->esc_like( $args['action'] ) . '%';
		}
		if ( '' !== $args['token_id'] ) {
			$where[]  = 'token_id = %s';
			$params[] = $args['token_id'];
		}
		if ( '' !== $args['status'] ) {
			$where[]  = 'status = %s';
			$params[] = $args['status'];
		}
		if ( '' !== $args['search'] ) {
			$like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$where[]  = '(action LIKE %s OR context LIKE %s)';
			$params[] = $like;
			$params[] = $like;
		}

		$clause = implode( ' AND ', $where );
		$table  = self::table();

		$total_sql = "SELECT COUNT(*) FROM {$table} WHERE {$clause}";
		$total     = (int) ( $params
			? $wpdb->get_var( $wpdb->prepare( $total_sql, $params ) ) // phpcs:ignore WordPress.DB
			: $wpdb->get_var( $total_sql ) ); // phpcs:ignore WordPress.DB

		$rows_sql    = "SELECT * FROM {$table} WHERE {$clause} ORDER BY id DESC LIMIT %d OFFSET %d";
		$rows_params = array_merge( $params, array( $per_page, $offset ) );
		$rows        = $wpdb->get_results( $wpdb->prepare( $rows_sql, $rows_params ), ARRAY_A ); // phpcs:ignore WordPress.DB

		foreach ( $rows as &$row ) {
			$row['context'] = json_decode( (string) $row['context'], true );
		}
		unset( $row );

		return array(
			'items' => $rows ? $rows : array(),
			'total' => $total,
			'pages' => (int) ceil( $total / $per_page ),
		);
	}

	/**
	 * Daily retention sweep for both the audit log and the change journal.
	 */
	public static function prune() {
		global $wpdb;

		if ( ! self::ready() ) {
			return;
		}

		$days = (int) kaiv_setting( 'audit_retention_days', 30 );
		if ( $days > 0 ) {
			$table  = self::table();
			$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %s", $cutoff ) ); // phpcs:ignore WordPress.DB
		}

		Journal::prune();
		Approval::prune();
	}
}
