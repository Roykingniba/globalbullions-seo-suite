<?php
/**
 * Keeps the filesystem tools inside a fenced yard.
 *
 * Every path an agent supplies is resolved with realpath() and then checked
 * against the allowed roots, so "../../" and symlinks that point outside cannot
 * escape. Paths are relative to wp-content unless an extra root is configured.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Security;

defined( 'ABSPATH' ) || exit;

class PathGuard {

	/** Files that are never readable or writable, whatever the scopes say. */
	const NEVER = array( 'wp-config.php', 'wp-config-sample.php', '.htpasswd' );

	/**
	 * Absolute, normalised, trailing-slashed allowed roots.
	 *
	 * @return string[]
	 */
	public static function roots() {
		$roots = array( WP_CONTENT_DIR );

		foreach ( (array) kaiv_setting( 'fs_extra_roots', array() ) as $extra ) {
			$extra = trim( (string) $extra );
			if ( '' !== $extra ) {
				$roots[] = $extra;
			}
		}

		/**
		 * Filter the directories the filesystem tools may touch.
		 *
		 * @param string[] $roots Absolute paths.
		 */
		$roots = apply_filters( 'kaiv_fs_roots', $roots );

		$normalised = array();

		foreach ( $roots as $root ) {
			$real = realpath( $root );
			if ( $real ) {
				$normalised[] = trailingslashit( wp_normalize_path( $real ) );
			}
		}

		return array_values( array_unique( $normalised ) );
	}

	/**
	 * Resolve a path for reading. The file must exist.
	 *
	 * @param string $path Relative (to wp-content) or absolute path.
	 * @return string|\WP_Error Absolute path.
	 */
	public static function resolve( $path ) {
		$candidate = self::candidate( $path );

		if ( is_wp_error( $candidate ) ) {
			return $candidate;
		}

		$real = realpath( $candidate );

		if ( false === $real ) {
			return new \WP_Error(
				'kaiv_not_found',
				sprintf(
					/* translators: %s: file path. */
					__( 'No such file: %s', 'kai-vibe' ),
					$path
				)
			);
		}

		return self::confirm_inside( $real, $path );
	}

	/**
	 * Resolve a path for writing. The file need not exist, but its parent must.
	 *
	 * @param string $path Relative or absolute path.
	 * @return string|\WP_Error Absolute path.
	 */
	public static function resolve_for_write( $path ) {
		$candidate = self::candidate( $path );

		if ( is_wp_error( $candidate ) ) {
			return $candidate;
		}

		$existing = realpath( $candidate );

		if ( false !== $existing ) {
			$confirmed = self::confirm_inside( $existing, $path );
			return is_wp_error( $confirmed ) ? $confirmed : self::check_extension( $confirmed );
		}

		$parent      = dirname( $candidate );
		$real_parent = realpath( $parent );

		if ( false === $real_parent ) {
			return new \WP_Error(
				'kaiv_no_parent',
				sprintf(
					/* translators: %s: directory path. */
					__( 'The directory %s does not exist. Create it first with create_directory.', 'kai-vibe' ),
					dirname( $path )
				)
			);
		}

		$confirmed = self::confirm_inside( $real_parent, $path );

		if ( is_wp_error( $confirmed ) ) {
			return $confirmed;
		}

		$resolved = trailingslashit( wp_normalize_path( $real_parent ) ) . basename( $candidate );

		return self::check_extension( $resolved );
	}

	/**
	 * Turn a user-supplied path into an absolute candidate, without touching disk.
	 *
	 * @param string $path Input path.
	 * @return string|\WP_Error
	 */
	private static function candidate( $path ) {
		$path = (string) $path;

		if ( '' === trim( $path ) ) {
			return new \WP_Error( 'kaiv_empty_path', __( 'No path given.', 'kai-vibe' ) );
		}

		if ( false !== strpos( $path, "\0" ) ) {
			return new \WP_Error( 'kaiv_bad_path', __( 'That path contains a null byte.', 'kai-vibe' ) );
		}

		if ( preg_match( '#^[a-z][a-z0-9+.\-]*://#i', $path ) ) {
			return new \WP_Error( 'kaiv_bad_path', __( 'Stream wrappers and URLs are not accepted here.', 'kai-vibe' ) );
		}

		$path = wp_normalize_path( $path );

		if ( in_array( strtolower( basename( $path ) ), array_map( 'strtolower', self::NEVER ), true ) ) {
			return new \WP_Error(
				'kaiv_forbidden_file',
				sprintf(
					/* translators: %s: file name. */
					__( '%s is off limits.', 'kai-vibe' ),
					basename( $path )
				)
			);
		}

		$is_absolute = ( 0 === strpos( $path, '/' ) ) || preg_match( '#^[A-Za-z]:/#', $path );

		if ( ! $is_absolute ) {
			$path = trailingslashit( wp_normalize_path( WP_CONTENT_DIR ) ) . ltrim( $path, '/' );
		}

		return $path;
	}

	/**
	 * @param string $real     Real absolute path.
	 * @param string $original Original input, for the error message.
	 * @return string|\WP_Error
	 */
	private static function confirm_inside( $real, $original ) {
		$real       = wp_normalize_path( $real );
		$comparable = is_dir( $real ) ? trailingslashit( $real ) : $real;

		foreach ( self::roots() as $root ) {
			if ( 0 === strpos( $comparable, $root ) ) {
				return $real;
			}
		}

		return new \WP_Error(
			'kaiv_outside_root',
			sprintf(
				/* translators: 1: attempted path, 2: allowed roots. */
				__( '%1$s is outside the allowed roots (%2$s).', 'kai-vibe' ),
				$original,
				implode( ', ', self::relative_roots() )
			)
		);
	}

	/**
	 * @param string $resolved Absolute path.
	 * @return string|\WP_Error
	 */
	private static function check_extension( $resolved ) {
		$extension = strtolower( pathinfo( $resolved, PATHINFO_EXTENSION ) );

		if ( in_array( $extension, array( 'php', 'phtml', 'php5', 'php7', 'phar' ), true ) && ! kaiv_setting( 'fs_allow_php', true ) ) {
			return new \WP_Error(
				'kaiv_php_writes_disabled',
				__( 'Writing PHP files is switched off for this site. Enable it under KAI Vibe → Settings if you meant to allow it.', 'kai-vibe' )
			);
		}

		return $resolved;
	}

	/**
	 * Present an absolute path back to the model in its relative form.
	 *
	 * @param string $absolute Absolute path.
	 * @return string
	 */
	public static function relative( $absolute ) {
		$absolute = wp_normalize_path( $absolute );
		$content  = trailingslashit( wp_normalize_path( WP_CONTENT_DIR ) );

		if ( 0 === strpos( $absolute, $content ) ) {
			return substr( $absolute, strlen( $content ) );
		}

		return $absolute;
	}

	/**
	 * Roots in the shortened form used in messages.
	 *
	 * @return string[]
	 */
	public static function relative_roots() {
		$abspath = trailingslashit( wp_normalize_path( ABSPATH ) );
		$labels  = array();

		foreach ( self::roots() as $root ) {
			$labels[] = 0 === strpos( $root, $abspath ) ? untrailingslashit( substr( $root, strlen( $abspath ) ) ) : untrailingslashit( $root );
		}

		return $labels;
	}

	/**
	 * @param string $path Absolute path.
	 * @return bool
	 */
	public static function is_text( $path ) {
		$binary = array( 'png', 'jpg', 'jpeg', 'gif', 'webp', 'avif', 'ico', 'pdf', 'zip', 'gz', 'woff', 'woff2', 'ttf', 'eot', 'mp4', 'mp3', 'mov', 'psd' );

		return ! in_array( strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ), $binary, true );
	}
}
