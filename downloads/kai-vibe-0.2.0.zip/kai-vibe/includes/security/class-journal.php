<?php
/**
 * The change journal: before-state for everything the agent overwrites.
 *
 * WordPress revisions cover post_content and little else. They do not cover
 * post meta, options, terms, or theme files — which is exactly where an agent
 * does its most consequential work. The journal fills that gap and gives the
 * undo_change tool something real to restore from.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Security;

use KaiVibe\Auth\Authenticator;

defined( 'ABSPATH' ) || exit;

class Journal {

	const KIND_POST   = 'post';
	const KIND_META   = 'meta';
	const KIND_OPTION = 'option';
	const KIND_FILE   = 'file';
	const KIND_TERM   = 'term';

	/** @var bool|null */
	private static $table_ready = null;

	/**
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'kaiv_journal';
	}

	/**
	 * @return bool
	 */
	private static function ready() {
		global $wpdb;

		if ( null === self::$table_ready ) {
			$table             = self::table();
			self::$table_ready = (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ); // phpcs:ignore WordPress.DB
		}

		return self::$table_ready;
	}

	/**
	 * Record the previous state of something before it is changed.
	 *
	 * @param string $kind    One of the KIND_* constants.
	 * @param string $target  Identifier: post id, option name, relative file path.
	 * @param string $label   Human summary shown in wp-admin and to the model.
	 * @param array  $payload Must contain a "before" key with enough to restore.
	 * @return int Journal entry id, 0 on failure.
	 */
	public static function record( $kind, $target, $label, array $payload ) {
		global $wpdb;

		if ( ! self::ready() ) {
			return 0;
		}

		$encoded = wp_json_encode( $payload );

		// Very large bodies would bloat the table; keep a marker instead.
		if ( strlen( $encoded ) > 4 * MB_IN_BYTES ) {
			$encoded = wp_json_encode(
				array(
					'oversized' => true,
					'bytes'     => strlen( $encoded ),
					'note'      => 'Original content was too large to journal. This change cannot be undone automatically.',
				)
			);
		}

		$wpdb->insert( // phpcs:ignore WordPress.DB
			self::table(),
			array(
				'created_at' => current_time( 'mysql', true ),
				'token_id'   => Authenticator::instance()->token_id(),
				'kind'       => $kind,
				'target'     => substr( (string) $target, 0, 255 ),
				'label'      => substr( (string) $label, 0, 255 ),
				'undone'     => 0,
				'payload'    => $encoded,
			),
			array( '%s', '%s', '%s', '%s', '%s', '%d', '%s' )
		);

		return (int) $wpdb->insert_id;
	}

	/**
	 * @param int $id Journal id.
	 * @return array|null
	 */
	public static function get( $id ) {
		global $wpdb;

		if ( ! self::ready() ) {
			return null;
		}

		$table = self::table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ), ARRAY_A ); // phpcs:ignore WordPress.DB

		if ( ! $row ) {
			return null;
		}

		$row['payload'] = json_decode( (string) $row['payload'], true );

		return $row;
	}

	/**
	 * @param array $args { per_page, page, kind, target, include_undone }
	 * @return array
	 */
	public static function query( array $args = array() ) {
		global $wpdb;

		if ( ! self::ready() ) {
			return array( 'items' => array(), 'total' => 0 );
		}

		$args = wp_parse_args(
			$args,
			array(
				'per_page'       => 25,
				'page'           => 1,
				'kind'           => '',
				'target'         => '',
				'include_undone' => true,
			)
		);

		$per_page = max( 1, min( 200, (int) $args['per_page'] ) );
		$offset   = max( 0, ( (int) $args['page'] - 1 ) * $per_page );

		$where  = array( '1=1' );
		$params = array();

		if ( '' !== $args['kind'] ) {
			$where[]  = 'kind = %s';
			$params[] = $args['kind'];
		}
		if ( '' !== $args['target'] ) {
			$where[]  = 'target = %s';
			$params[] = $args['target'];
		}
		if ( ! $args['include_undone'] ) {
			$where[] = 'undone = 0';
		}

		$clause = implode( ' AND ', $where );
		$table  = self::table();

		$total_sql = "SELECT COUNT(*) FROM {$table} WHERE {$clause}";
		$total     = (int) ( $params
			? $wpdb->get_var( $wpdb->prepare( $total_sql, $params ) ) // phpcs:ignore WordPress.DB
			: $wpdb->get_var( $total_sql ) ); // phpcs:ignore WordPress.DB

		// The payload can be megabytes; the listing never needs it.
		$rows_sql = "SELECT id, created_at, token_id, kind, target, label, undone FROM {$table} WHERE {$clause} ORDER BY id DESC LIMIT %d OFFSET %d";
		$rows     = $wpdb->get_results( $wpdb->prepare( $rows_sql, array_merge( $params, array( $per_page, $offset ) ) ), ARRAY_A ); // phpcs:ignore WordPress.DB

		return array(
			'items' => $rows ? $rows : array(),
			'total' => $total,
		);
	}

	/**
	 * Restore a journalled change.
	 *
	 * @param int $id Journal id.
	 * @return array|\WP_Error Summary of what was restored.
	 */
	public static function undo( $id ) {
		global $wpdb;

		$entry = self::get( $id );

		if ( ! $entry ) {
			return new \WP_Error( 'kaiv_no_entry', __( 'No journal entry with that id.', 'kai-vibe' ) );
		}

		if ( ! empty( $entry['undone'] ) ) {
			return new \WP_Error( 'kaiv_already_undone', __( 'That change has already been undone.', 'kai-vibe' ) );
		}

		$payload = is_array( $entry['payload'] ) ? $entry['payload'] : array();

		if ( ! empty( $payload['oversized'] ) ) {
			return new \WP_Error( 'kaiv_oversized', __( 'The original state was too large to journal, so this change cannot be undone automatically.', 'kai-vibe' ) );
		}

		$before = isset( $payload['before'] ) ? $payload['before'] : null;

		switch ( $entry['kind'] ) {
			case self::KIND_POST:
				$result = self::undo_post( (int) $entry['target'], $before );
				break;

			case self::KIND_META:
				$result = self::undo_meta( $payload );
				break;

			case self::KIND_OPTION:
				$result = self::undo_option( $entry['target'], $payload );
				break;

			case self::KIND_FILE:
				$result = self::undo_file( $entry['target'], $payload );
				break;

			case self::KIND_TERM:
				$result = self::undo_term( (int) $entry['target'], $before );
				break;

			default:
				/**
				 * Undo a journal entry of a custom kind.
				 *
				 * @param mixed $result Return an array or WP_Error to handle it.
				 * @param array $entry  Journal entry.
				 */
				$result = apply_filters( 'kaiv_undo_change', new \WP_Error( 'kaiv_unknown_kind', __( 'Unrecognised change type.', 'kai-vibe' ) ), $entry );
		}

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$wpdb->update( self::table(), array( 'undone' => 1 ), array( 'id' => (int) $id ), array( '%d' ), array( '%d' ) ); // phpcs:ignore WordPress.DB

		kaiv_audit( 'journal.undo', array( 'entry' => (int) $id, 'kind' => $entry['kind'], 'target' => $entry['target'] ) );

		return array(
			'undone'  => true,
			'entry'   => (int) $id,
			'kind'    => $entry['kind'],
			'target'  => $entry['target'],
			'label'   => $entry['label'],
			'details' => $result,
		);
	}

	/**
	 * @param int   $post_id Post id.
	 * @param mixed $before  Previous post array.
	 * @return array|\WP_Error
	 */
	private static function undo_post( $post_id, $before ) {
		if ( ! is_array( $before ) ) {
			return new \WP_Error( 'kaiv_bad_payload', __( 'The journal entry has no restorable post state.', 'kai-vibe' ) );
		}

		// The post was created by the agent, so undoing means removing it.
		if ( empty( $before ) || ! empty( $before['__created'] ) ) {
			if ( ! current_user_can( 'delete_post', $post_id ) ) {
				return new \WP_Error( 'kaiv_forbidden', __( 'You cannot delete that post.', 'kai-vibe' ) );
			}
			wp_trash_post( $post_id );
			return array( 'action' => 'trashed', 'post_id' => $post_id );
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new \WP_Error( 'kaiv_forbidden', __( 'You cannot edit that post.', 'kai-vibe' ) );
		}

		$before['ID'] = $post_id;

		$updated = wp_update_post( wp_slash( $before ), true );

		if ( is_wp_error( $updated ) ) {
			return $updated;
		}

		return array( 'action' => 'restored', 'post_id' => $post_id );
	}

	/**
	 * @param array $payload Journal payload.
	 * @return array|\WP_Error
	 */
	private static function undo_meta( array $payload ) {
		$post_id = isset( $payload['post_id'] ) ? (int) $payload['post_id'] : 0;
		$key     = isset( $payload['meta_key'] ) ? (string) $payload['meta_key'] : '';

		if ( ! $post_id || '' === $key ) {
			return new \WP_Error( 'kaiv_bad_payload', __( 'The journal entry is missing its meta target.', 'kai-vibe' ) );
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new \WP_Error( 'kaiv_forbidden', __( 'You cannot edit that post.', 'kai-vibe' ) );
		}

		if ( array_key_exists( 'before', $payload ) && null !== $payload['before'] ) {
			update_post_meta( $post_id, $key, wp_slash( $payload['before'] ) );
			$action = 'restored';
		} else {
			delete_post_meta( $post_id, $key );
			$action = 'deleted';
		}

		// Builder layouts cache aggressively; a restore is worthless if stale CSS wins.
		\KaiVibe\Support\Builders::flush( $post_id );

		return array( 'action' => $action, 'post_id' => $post_id, 'meta_key' => $key );
	}

	/**
	 * @param string $option  Option name.
	 * @param array  $payload Journal payload.
	 * @return array|\WP_Error
	 */
	private static function undo_option( $option, array $payload ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error( 'kaiv_forbidden', __( 'You cannot manage options.', 'kai-vibe' ) );
		}

		if ( array_key_exists( 'before', $payload ) && null !== $payload['before'] ) {
			update_option( $option, $payload['before'] );
			$action = 'restored';
		} else {
			delete_option( $option );
			$action = 'deleted';
		}

		return array( 'action' => $action, 'option' => $option );
	}

	/**
	 * @param string $relative Relative file path.
	 * @param array  $payload  Journal payload.
	 * @return array|\WP_Error
	 */
	private static function undo_file( $relative, array $payload ) {
		if ( ! current_user_can( 'edit_themes' ) ) {
			return new \WP_Error( 'kaiv_forbidden', __( 'You cannot edit files on this site.', 'kai-vibe' ) );
		}

		$resolved = PathGuard::resolve_for_write( $relative );

		if ( is_wp_error( $resolved ) ) {
			return $resolved;
		}

		// A null "before" means one of two things: the file genuinely did not
		// exist (write_file), or it was binary and its contents were never
		// journalled (delete_file). Only the first is undoable by deleting.
		if ( ! array_key_exists( 'before', $payload ) || null === $payload['before'] ) {
			if ( ! file_exists( $resolved ) ) {
				return new \WP_Error(
					'kaiv_nothing_to_restore',
					__( 'No previous contents were journalled for this file, so it cannot be restored.', 'kai-vibe' )
				);
			}

			wp_delete_file( $resolved );

			return array( 'action' => 'deleted', 'path' => $relative );
		}

		$written = file_put_contents( $resolved, $payload['before'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		if ( false === $written ) {
			return new \WP_Error( 'kaiv_write_failed', __( 'Could not write the file back.', 'kai-vibe' ) );
		}

		return array( 'action' => 'restored', 'path' => $relative, 'bytes' => $written );
	}

	/**
	 * @param int   $term_id Term id.
	 * @param mixed $before  Previous term fields.
	 * @return array|\WP_Error
	 */
	private static function undo_term( $term_id, $before ) {
		if ( ! is_array( $before ) ) {
			return new \WP_Error( 'kaiv_bad_payload', __( 'The journal entry has no restorable term state.', 'kai-vibe' ) );
		}

		$term = get_term( $term_id );
		if ( ! $term || is_wp_error( $term ) ) {
			return new \WP_Error( 'kaiv_no_term', __( 'That term no longer exists.', 'kai-vibe' ) );
		}

		// wp_update_term() performs no capability check of its own.
		if ( ! current_user_can( 'edit_term', $term_id ) ) {
			return new \WP_Error( 'kaiv_forbidden', __( 'You cannot edit that term.', 'kai-vibe' ) );
		}

		$updated = wp_update_term( $term_id, $term->taxonomy, $before );

		if ( is_wp_error( $updated ) ) {
			return $updated;
		}

		return array( 'action' => 'restored', 'term_id' => $term_id );
	}

	/**
	 * Retention sweep.
	 */
	public static function prune() {
		global $wpdb;

		if ( ! self::ready() ) {
			return;
		}

		$days = (int) kaiv_setting( 'journal_retention_days', 14 );

		if ( $days > 0 ) {
			$table  = self::table();
			$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %s", $cutoff ) ); // phpcs:ignore WordPress.DB
		}
	}
}
