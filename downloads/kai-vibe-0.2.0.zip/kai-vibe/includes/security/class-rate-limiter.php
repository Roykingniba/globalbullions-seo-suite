<?php
/**
 * Per-token call ceiling. A runaway loop should cost the site a 429, not its
 * database connections.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Security;

use KaiVibe\Auth\Authenticator;

defined( 'ABSPATH' ) || exit;

class RateLimiter {

	/**
	 * Count this call and decide whether it may proceed.
	 *
	 * @return true|\WP_Error
	 */
	public static function check() {
		$limit  = (int) kaiv_setting( 'rate_limit', 240 );
		$window = max( 1, (int) kaiv_setting( 'rate_window', MINUTE_IN_SECONDS ) );

		if ( $limit <= 0 ) {
			return true;
		}

		$token_id = Authenticator::instance()->token_id();
		if ( '' === $token_id ) {
			return true;
		}

		$key   = 'kaiv_rate_' . $token_id;
		$state = get_transient( $key );

		if ( ! is_array( $state ) || ! isset( $state['reset'] ) || $state['reset'] < time() ) {
			$state = array( 'count' => 0, 'reset' => time() + $window );
		}

		$state['count']++;

		set_transient( $key, $state, $window + 5 );

		if ( $state['count'] > $limit ) {
			$retry = max( 1, $state['reset'] - time() );

			kaiv_audit( 'rate.limited', array( 'token_id' => $token_id, 'count' => $state['count'] ) );

			return new \WP_Error(
				'kaiv_rate_limited',
				sprintf(
					/* translators: 1: call limit, 2: window in seconds, 3: seconds to wait. */
					__( 'Rate limit reached: %1$d calls per %2$d seconds. Wait about %3$d seconds before trying again, and consider batching your work into fewer calls.', 'kai-vibe' ),
					$limit,
					$window,
					$retry
				),
				array( 'retry_after' => $retry, 'limit' => $limit )
			);
		}

		return true;
	}

	/**
	 * Calls used and remaining in the current window.
	 *
	 * @return array
	 */
	public static function status() {
		$token_id = Authenticator::instance()->token_id();
		$limit    = (int) kaiv_setting( 'rate_limit', 240 );
		$state    = $token_id ? get_transient( 'kaiv_rate_' . $token_id ) : false;

		$used = is_array( $state ) && isset( $state['count'] ) ? (int) $state['count'] : 0;

		return array(
			'limit'     => $limit,
			'used'      => $used,
			'remaining' => max( 0, $limit - $used ),
			'resets_in' => is_array( $state ) && isset( $state['reset'] ) ? max( 0, $state['reset'] - time() ) : 0,
		);
	}
}
