<?php
/**
 * Human-in-the-loop gate for the operations you would not want an agent doing
 * unsupervised: SQL writes, plugin deletion, user changes, WP-CLI.
 *
 * The flow, from the model's point of view:
 *
 *   1. Call the tool. Instead of a result you get an approval id and a URL.
 *   2. Tell the human to open that URL and approve it.
 *   3. Call check_approval until it reports approved, then call the tool again
 *      with the same arguments — the gate lets it through exactly once.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Security;

use KaiVibe\Auth\Authenticator;
use KaiVibe\Mcp\Tool;
use KaiVibe\Mcp\ToolResult;

defined( 'ABSPATH' ) || exit;

class Approval {

	const OPTION = 'kaiv_pending_approvals';

	const PENDING  = 'pending';
	const APPROVED = 'approved';
	const DENIED   = 'denied';
	const USED     = 'used';

	/**
	 * @return array<string,array>
	 */
	public static function all() {
		$pending = get_option( self::OPTION, array() );
		return is_array( $pending ) ? $pending : array();
	}

	/**
	 * @param string $id Approval id.
	 * @return array|null
	 */
	public static function get( $id ) {
		$all = self::all();
		return isset( $all[ $id ] ) ? $all[ $id ] : null;
	}

	/**
	 * Decide whether a gated tool call may proceed.
	 *
	 * @param Tool  $tool Tool being called.
	 * @param array $args Validated arguments.
	 * @return ToolResult|null Null means proceed.
	 */
	public static function gate( Tool $tool, array $args ) {
		return self::decide( $tool, $args );
	}

	/**
	 * Gate a call from inside a tool callback, when only some paths through the
	 * tool are destructive — permanent deletion, a role change, a SQL write.
	 *
	 * @param string $tool_name Registered tool name.
	 * @param array  $args      Arguments identifying this specific operation.
	 * @return ToolResult|null Null means proceed.
	 */
	public static function require_for( $tool_name, array $args ) {
		$tool = kaiv()->tools()->get( $tool_name );

		// Fail closed. Returning null here would mean "proceed", so a renamed
		// or filtered-out tool would silently disable its own approval gate.
		if ( ! $tool ) {
			return ToolResult::error(
				__( 'This operation requires approval, but its approval gate could not be resolved. Refusing.', 'kai-vibe' ),
				array( 'tool' => $tool_name )
			);
		}

		return self::decide( $tool, $args );
	}

	/**
	 * @param Tool  $tool Tool being called.
	 * @param array $args Validated arguments.
	 * @return ToolResult|null
	 */
	private static function decide( Tool $tool, array $args ) {
		if ( ! kaiv_setting( 'approval_required', true ) ) {
			return null;
		}

		/**
		 * Short-circuit the approval gate for a specific call.
		 *
		 * @param bool|null $decision True to allow, null to run the normal gate.
		 * @param Tool      $tool     Tool.
		 * @param array     $args     Arguments.
		 */
		if ( true === apply_filters( 'kaiv_pre_approval', null, $tool, $args ) ) {
			return null;
		}

		$fingerprint = self::fingerprint( $tool->name, $args );
		$existing    = self::find( $tool->name, $fingerprint );

		if ( $existing ) {
			switch ( $existing['status'] ) {
				case self::APPROVED:
					self::mark( $existing['id'], self::USED );
					kaiv_audit( 'approval.consumed', array( 'approval_id' => $existing['id'], 'tool' => $tool->name ) );
					return null;

				case self::DENIED:
					self::forget( $existing['id'] );
					return ToolResult::error(
						__( 'The site owner declined this operation. Do not retry it. Ask them what they would prefer instead.', 'kai-vibe' ),
						array( 'approval_id' => $existing['id'], 'status' => self::DENIED )
					);

				case self::PENDING:
					return self::waiting_result( $existing );
			}
		}

		$request = self::create( $tool, $args, $fingerprint );

		return self::waiting_result( $request, true );
	}

	/**
	 * @param Tool   $tool        Tool.
	 * @param array  $args        Arguments.
	 * @param string $fingerprint Argument fingerprint.
	 * @return array
	 */
	private static function create( Tool $tool, array $args, $fingerprint ) {
		$id  = 'apr_' . bin2hex( random_bytes( 6 ) );
		$ttl = (int) kaiv_setting( 'approval_ttl', 15 * MINUTE_IN_SECONDS );

		$request = array(
			'id'          => $id,
			'tool'        => $tool->name,
			'title'       => $tool->title ? $tool->title : $tool->name,
			'summary'     => self::summarise( $tool, $args ),
			'fingerprint' => $fingerprint,
			'arguments'   => AuditLog::redact( $args ),
			'token_id'    => Authenticator::instance()->token_id(),
			'user_id'     => get_current_user_id(),
			'status'      => self::PENDING,
			'created'     => time(),
			'expires'     => time() + $ttl,
		);

		$all         = self::all();
		$all[ $id ]  = $request;
		update_option( self::OPTION, self::compact( $all ), false );

		kaiv_audit( 'approval.requested', array( 'approval_id' => $id, 'tool' => $tool->name, 'summary' => $request['summary'] ) );

		/**
		 * Fires when an agent requests approval. Hook this to send yourself
		 * a notification rather than waiting for someone to refresh wp-admin.
		 *
		 * @param array $request Approval request.
		 */
		do_action( 'kaiv_approval_requested', $request );

		return $request;
	}

	/**
	 * @param array $request Approval request.
	 * @param bool  $is_new  Whether it was just created.
	 * @return ToolResult
	 */
	private static function waiting_result( array $request, $is_new = false ) {
		$remaining = max( 0, (int) $request['expires'] - time() );

		$message = $is_new
			? __( 'This operation needs the site owner to approve it first.', 'kai-vibe' )
			: __( 'This operation is still waiting on the site owner.', 'kai-vibe' );

		$message .= "\n\n" . sprintf(
			/* translators: %s: what the operation will do. */
			__( 'Requested: %s', 'kai-vibe' ),
			$request['summary']
		);

		$message .= "\n\n" . sprintf(
			/* translators: 1: approval URL, 2: minutes remaining. */
			__( 'Ask them to approve it at %1$s — the request expires in about %2$d minutes. Then call check_approval with this id, and once it reports "approved", call the tool again with the same arguments.', 'kai-vibe' ),
			self::url(),
			(int) ceil( $remaining / MINUTE_IN_SECONDS )
		);

		return ToolResult::error(
			$message,
			array(
				'approval_id'  => $request['id'],
				'status'       => self::PENDING,
				'approval_url' => self::url(),
				'expires_in'   => $remaining,
			)
		);
	}

	/**
	 * @return string
	 */
	public static function url() {
		return admin_url( 'admin.php?page=kai-vibe-approvals' );
	}

	/**
	 * Readable one-liner for the admin screen. Tools can supply their own.
	 *
	 * @param Tool  $tool Tool.
	 * @param array $args Arguments.
	 * @return string
	 */
	private static function summarise( Tool $tool, array $args ) {
		$summary = '';

		foreach ( array( 'sql', 'command', 'path', 'slug', 'option', 'post_id', 'user_id' ) as $key ) {
			if ( isset( $args[ $key ] ) && is_scalar( $args[ $key ] ) ) {
				$summary = sprintf( '%s: %s', $key, (string) $args[ $key ] );
				break;
			}
		}

		if ( '' === $summary ) {
			$summary = wp_json_encode( AuditLog::redact( $args ) );
		}

		$summary = sprintf( '%s — %s', $tool->name, $summary );

		if ( strlen( $summary ) > 300 ) {
			$summary = substr( $summary, 0, 297 ) . '…';
		}

		/**
		 * Filter the human-readable summary shown on the approval screen.
		 *
		 * @param string $summary Summary.
		 * @param Tool   $tool    Tool.
		 * @param array  $args    Arguments.
		 */
		return apply_filters( 'kaiv_approval_summary', $summary, $tool, $args );
	}

	/**
	 * @param string $tool        Tool name.
	 * @param array  $args        Arguments.
	 * @return string
	 */
	public static function fingerprint( $tool, array $args ) {
		ksort( $args );
		return hash( 'sha256', $tool . '|' . wp_json_encode( $args ) );
	}

	/**
	 * Find a live request for the same tool and arguments.
	 *
	 * @param string $tool        Tool name.
	 * @param string $fingerprint Fingerprint.
	 * @return array|null
	 */
	private static function find( $tool, $fingerprint ) {
		$now = time();

		foreach ( self::all() as $request ) {
			if ( $request['tool'] !== $tool || $request['fingerprint'] !== $fingerprint ) {
				continue;
			}
			if ( self::USED === $request['status'] ) {
				continue;
			}
			if ( $request['expires'] < $now ) {
				continue;
			}

			return $request;
		}

		return null;
	}

	/**
	 * @param string $id     Approval id.
	 * @param string $status New status.
	 * @return bool
	 */
	public static function mark( $id, $status ) {
		$all = self::all();

		if ( ! isset( $all[ $id ] ) ) {
			return false;
		}

		$all[ $id ]['status']    = $status;
		$all[ $id ]['decided']   = time();
		$all[ $id ]['decidedBy'] = get_current_user_id();

		// An approval is valid for a while after it is granted, not just until
		// the original request would have expired.
		if ( self::APPROVED === $status ) {
			$all[ $id ]['expires'] = time() + (int) kaiv_setting( 'approval_ttl', 15 * MINUTE_IN_SECONDS );
		}

		update_option( self::OPTION, self::compact( $all ), false );

		kaiv_audit( 'approval.' . $status, array( 'approval_id' => $id, 'tool' => $all[ $id ]['tool'] ) );

		return true;
	}

	/**
	 * @param string $id Approval id.
	 * @return bool
	 */
	public static function forget( $id ) {
		$all = self::all();

		if ( ! isset( $all[ $id ] ) ) {
			return false;
		}

		unset( $all[ $id ] );
		update_option( self::OPTION, $all, false );

		return true;
	}

	/**
	 * Drop used and long-expired requests so the option stays small.
	 *
	 * @param array $all All requests.
	 * @return array
	 */
	private static function compact( array $all ) {
		$cutoff = time() - DAY_IN_SECONDS;

		foreach ( $all as $id => $request ) {
			$stale = ( $request['expires'] < $cutoff );
			$done  = ( self::USED === $request['status'] && $request['expires'] < time() );

			if ( $stale || $done ) {
				unset( $all[ $id ] );
			}
		}

		// Hard cap, newest first, so a runaway agent cannot balloon the option.
		if ( count( $all ) > 100 ) {
			uasort(
				$all,
				static function ( $a, $b ) {
					return $b['created'] <=> $a['created'];
				}
			);
			$all = array_slice( $all, 0, 100, true );
		}

		return $all;
	}

	/**
	 * Scheduled cleanup.
	 */
	public static function prune() {
		update_option( self::OPTION, self::compact( self::all() ), false );
	}

	/**
	 * Requests still awaiting a decision, newest first.
	 *
	 * @return array[]
	 */
	public static function pending() {
		$pending = array();
		$now     = time();

		foreach ( self::all() as $request ) {
			if ( self::PENDING === $request['status'] && $request['expires'] >= $now ) {
				$pending[] = $request;
			}
		}

		usort(
			$pending,
			static function ( $a, $b ) {
				return $b['created'] <=> $a['created'];
			}
		);

		return $pending;
	}
}
