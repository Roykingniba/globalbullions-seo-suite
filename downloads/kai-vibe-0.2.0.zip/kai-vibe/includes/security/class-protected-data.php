<?php
/**
 * Options, meta keys and tables an agent must not read or rewrite.
 *
 * Two lists, because they answer different questions: "would leaking this hand
 * someone the site?" and "would changing this lock the owner out?".
 *
 * @package KaiVibe
 */

namespace KaiVibe\Security;

defined( 'ABSPATH' ) || exit;

class ProtectedData {

	/**
	 * Options never returned to the model, in full or in part.
	 *
	 * @return string[]
	 */
	public static function secret_options() {
		$options = array(
			'kaiv_tokens',
			'auth_key',
			'secure_auth_key',
			'logged_in_key',
			'nonce_key',
			'auth_salt',
			'secure_auth_salt',
			'logged_in_salt',
			'nonce_salt',
			'recovery_keys',
			'https_detection_errors',
			'mailserver_pass',
			'mailserver_login',
		);

		/**
		 * Filter options that are never exposed over MCP.
		 *
		 * @param string[] $options Option names.
		 */
		return apply_filters( 'kaiv_secret_options', $options );
	}

	/**
	 * Options that may be read but never written by an agent — changing them is
	 * how you lock yourself out of your own site.
	 *
	 * @return string[]
	 */
	public static function locked_options() {
		$options = array(
			'siteurl',
			'home',
			'admin_email',
			'users_can_register',
			'default_role',
			'active_plugins',
			'kaiv_settings',
			'kaiv_tokens',
		);

		/**
		 * Filter options an agent may not write.
		 *
		 * @param string[] $options Option names.
		 */
		return apply_filters( 'kaiv_locked_options', $options );
	}

	/**
	 * Patterns matched against option names for secrecy.
	 *
	 * @return string
	 */
	public static function secret_pattern() {
		// "pass$" matters as much as "password": core's own mailserver_pass and
		// plenty of plugin options (…_smtp_pass) hold cleartext passwords.
		return apply_filters( 'kaiv_secret_option_pattern', '/(_secret$|_api_key$|_apikey$|_private_key$|_access_token$|_refresh_token$|pass(word)?$|password|_salt$|_nonce_key$)/i' );
	}

	/**
	 * @param string $option Option name.
	 * @return bool
	 */
	public static function is_protected_option( $option ) {
		$option = (string) $option;

		if ( in_array( $option, self::secret_options(), true ) ) {
			return true;
		}

		return (bool) preg_match( self::secret_pattern(), $option );
	}

	/**
	 * @param string $option Option name.
	 * @return bool
	 */
	public static function is_locked_option( $option ) {
		return self::is_protected_option( $option ) || in_array( (string) $option, self::locked_options(), true );
	}

	/**
	 * Meta keys never returned to the model.
	 *
	 * @param string $key Meta key.
	 * @return bool
	 */
	public static function is_protected_meta( $key ) {
		$keys = apply_filters(
			'kaiv_protected_meta_keys',
			array( 'session_tokens', 'wp_user-settings', '_wp_persisted_preferences' )
		);

		if ( in_array( (string) $key, $keys, true ) ) {
			return true;
		}

		return (bool) preg_match( '/(password|_secret$|_token$|_api_key$)/i', (string) $key );
	}

	/**
	 * Columns stripped from any user row before it leaves the site.
	 *
	 * @return string[]
	 */
	public static function user_secret_fields() {
		return array( 'user_pass', 'user_activation_key', 'session_tokens' );
	}

	/**
	 * Tables a db_query result must never expose, even with db:read granted.
	 *
	 * @return string[] Unprefixed table names.
	 */
	public static function guarded_tables() {
		/**
		 * Filter tables the raw SQL tool refuses to touch.
		 *
		 * @param string[] $tables Unprefixed names.
		 */
		return apply_filters( 'kaiv_guarded_tables', array( 'users', 'usermeta' ) );
	}

	/**
	 * Redact secret columns out of an arbitrary result row.
	 *
	 * @param array $row Result row.
	 * @return array
	 */
	public static function redact_row( array $row ) {
		foreach ( $row as $column => $value ) {
			if ( in_array( $column, self::user_secret_fields(), true ) ) {
				$row[ $column ] = '[redacted]';
			} elseif ( 'option_name' === $column && self::is_protected_option( $value ) && isset( $row['option_value'] ) ) {
				$row['option_value'] = '[redacted]';
			}
		}

		return $row;
	}
}
