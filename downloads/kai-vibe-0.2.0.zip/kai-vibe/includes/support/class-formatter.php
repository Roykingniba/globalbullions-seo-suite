<?php
/**
 * Turns WordPress objects into the compact shapes tools return.
 *
 * Consistency matters more than completeness here: the model should be able to
 * predict the shape of a post whether it came from find_content, get_post or a
 * resource read.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Support;

use KaiVibe\Security\ProtectedData;

defined( 'ABSPATH' ) || exit;

class Formatter {

	/**
	 * @param \WP_Post $post Post object.
	 * @param bool     $full Include content, meta and taxonomy terms.
	 * @return array
	 */
	public static function post( \WP_Post $post, $full = false ) {
		$data = array(
			'id'        => $post->ID,
			'type'      => $post->post_type,
			'status'    => $post->post_status,
			'title'     => $post->post_title,
			'slug'      => $post->post_name,
			'url'       => get_permalink( $post ),
			'edit_url'  => get_edit_post_link( $post->ID, 'raw' ),
			'author'    => (int) $post->post_author,
			'parent'    => (int) $post->post_parent,
			'menu_order'=> (int) $post->menu_order,
			'date'      => $post->post_date_gmt && '0000-00-00 00:00:00' !== $post->post_date_gmt
				? get_gmt_from_date( $post->post_date, 'c' )
				: null,
			'modified'  => get_gmt_from_date( $post->post_modified, 'c' ),
			'excerpt'   => $post->post_excerpt,
		);

		$builder = Builders::detect_for_post( $post->ID );
		if ( $builder ) {
			$data['builder'] = $builder;
			$data['note']    = sprintf(
				'This page is built with %s. Its layout lives in post meta — use builder_get and builder_set, not post_content.',
				Builders::label( $builder )
			);
		}

		if ( ! $full ) {
			return $data;
		}

		$data['content']   = $post->post_content;
		$data['is_blocks'] = has_blocks( $post );
		$data['template']  = get_page_template_slug( $post ) ?: null;
		$data['thumbnail'] = get_post_thumbnail_id( $post ) ? (int) get_post_thumbnail_id( $post ) : null;
		$data['terms']     = self::post_terms( $post );
		$data['meta']      = self::post_meta( $post->ID );

		return $data;
	}

	/**
	 * @param \WP_Post $post Post.
	 * @return array taxonomy => [ { id, name, slug } ]
	 */
	public static function post_terms( \WP_Post $post ) {
		$out = array();

		foreach ( get_object_taxonomies( $post->post_type ) as $taxonomy ) {
			$terms = get_the_terms( $post, $taxonomy );

			if ( ! $terms || is_wp_error( $terms ) ) {
				continue;
			}

			$out[ $taxonomy ] = array_map(
				static function ( $term ) {
					return array( 'id' => $term->term_id, 'name' => $term->name, 'slug' => $term->slug );
				},
				$terms
			);
		}

		return $out;
	}

	/**
	 * Post meta with the noisy and the sensitive filtered out.
	 *
	 * @param int  $post_id     Post id.
	 * @param bool $include_big Include values over 2 KB verbatim.
	 * @return array
	 */
	public static function post_meta( $post_id, $include_big = false ) {
		$raw  = get_post_meta( $post_id );
		$meta = array();

		foreach ( (array) $raw as $key => $values ) {
			if ( ProtectedData::is_protected_meta( $key ) ) {
				continue;
			}

			$value = is_array( $values ) && 1 === count( $values ) ? $values[0] : $values;

			if ( is_string( $value ) ) {
				$unserialised = maybe_unserialize( $value );

				if ( ! $include_big && is_string( $unserialised ) && strlen( $unserialised ) > 2048 ) {
					$meta[ $key ] = sprintf( '[%d bytes — read it with get_post_meta]', strlen( $unserialised ) );
					continue;
				}

				$value = $unserialised;
			}

			$meta[ $key ] = $value;
		}

		return $meta;
	}

	/**
	 * @param \WP_User $user User.
	 * @return array
	 */
	public static function user( \WP_User $user ) {
		return array(
			'id'           => $user->ID,
			'login'        => $user->user_login,
			'email'        => $user->user_email,
			'display_name' => $user->display_name,
			'first_name'   => $user->first_name,
			'last_name'    => $user->last_name,
			'roles'        => array_values( $user->roles ),
			'registered'   => gmdate( 'c', strtotime( $user->user_registered . ' UTC' ) ),
			'url'          => $user->user_url,
			'posts'        => (int) count_user_posts( $user->ID ),
		);
	}

	/**
	 * @param \WP_Term $term Term.
	 * @return array
	 */
	public static function term( \WP_Term $term ) {
		return array(
			'id'          => $term->term_id,
			'taxonomy'    => $term->taxonomy,
			'name'        => $term->name,
			'slug'        => $term->slug,
			'parent'      => (int) $term->parent,
			'count'       => (int) $term->count,
			'description' => $term->description,
			'url'         => get_term_link( $term ) instanceof \WP_Error ? null : get_term_link( $term ),
		);
	}

	/**
	 * @param \WP_Post $attachment Attachment post.
	 * @return array
	 */
	public static function attachment( \WP_Post $attachment ) {
		$meta = wp_get_attachment_metadata( $attachment->ID );
		$file = get_attached_file( $attachment->ID );

		return array(
			'id'        => $attachment->ID,
			'title'     => $attachment->post_title,
			'url'       => wp_get_attachment_url( $attachment->ID ),
			'mime_type' => $attachment->post_mime_type,
			'alt'       => (string) get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true ),
			'caption'   => $attachment->post_excerpt,
			'width'     => isset( $meta['width'] ) ? (int) $meta['width'] : null,
			'height'    => isset( $meta['height'] ) ? (int) $meta['height'] : null,
			'filesize'  => $file && file_exists( $file ) ? filesize( $file ) : null,
			'date'      => get_gmt_from_date( $attachment->post_date, 'c' ),
			'sizes'     => isset( $meta['sizes'] ) ? array_keys( (array) $meta['sizes'] ) : array(),
		);
	}

	/**
	 * @param \WP_Comment $comment Comment.
	 * @return array
	 */
	public static function comment( \WP_Comment $comment ) {
		return array(
			'id'       => (int) $comment->comment_ID,
			'post_id'  => (int) $comment->comment_post_ID,
			'author'   => $comment->comment_author,
			'email'    => $comment->comment_author_email,
			'content'  => $comment->comment_content,
			'status'   => wp_get_comment_status( $comment ),
			'date'     => get_gmt_from_date( $comment->comment_date, 'c' ),
			'parent'   => (int) $comment->comment_parent,
			'user_id'  => (int) $comment->user_id,
			'post_title' => get_the_title( $comment->comment_post_ID ),
		);
	}

	/**
	 * Human byte size.
	 *
	 * @param int $bytes Bytes.
	 * @return string
	 */
	public static function bytes( $bytes ) {
		return size_format( (int) $bytes, 1 );
	}
}
