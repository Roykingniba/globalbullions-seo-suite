<?php
/**
 * Page builder awareness.
 *
 * The single most common way an agent breaks a WordPress site is editing
 * post_content on a page whose layout actually lives in post meta. This class
 * knows where each builder keeps its data, how to write it back, and what has
 * to be flushed afterwards so the front end shows the change.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Support;

defined( 'ABSPATH' ) || exit;

class Builders {

	/**
	 * Builder definitions.
	 *
	 * meta      — where the layout is stored
	 * format    — json | shortcode | raw
	 * active    — callable returning whether the builder is installed
	 * enabled   — callable( $post_id ) returning whether it owns this post
	 *
	 * @return array
	 */
	public static function all() {
		$builders = array(
			'elementor'  => array(
				'label'  => 'Elementor',
				'meta'   => '_elementor_data',
				'format' => 'json',
				'active' => static function () {
					return defined( 'ELEMENTOR_VERSION' );
				},
			),
			'divi'       => array(
				'label'  => 'Divi',
				'meta'   => '',
				'format' => 'shortcode',
				'active' => static function () {
					return function_exists( 'et_setup_theme' ) || defined( 'ET_BUILDER_VERSION' );
				},
			),
			'beaver'     => array(
				'label'  => 'Beaver Builder',
				'meta'   => '_fl_builder_data',
				'format' => 'serialized',
				'active' => static function () {
					return class_exists( 'FLBuilder' );
				},
			),
			'bricks'     => array(
				'label'  => 'Bricks',
				'meta'   => '_bricks_page_content_2',
				'format' => 'serialized',
				'active' => static function () {
					return defined( 'BRICKS_VERSION' );
				},
			),
			'breakdance' => array(
				'label'  => 'Breakdance',
				'meta'   => '_breakdance_data',
				'format' => 'json',
				'active' => static function () {
					// get_tree is a namespaced function, not a class.
					return defined( '__BREAKDANCE_VERSION' )
						|| defined( 'BREAKDANCE_VERSION' )
						|| function_exists( '\Breakdance\Data\get_tree' );
				},
			),
			'oxygen'     => array(
				'label'  => 'Oxygen',
				'meta'   => 'ct_builder_shortcodes',
				'format' => 'shortcode',
				'active' => static function () {
					return defined( 'CT_VERSION' );
				},
			),
			'wpbakery'   => array(
				'label'  => 'WPBakery',
				'meta'   => '',
				'format' => 'shortcode',
				'active' => static function () {
					return defined( 'WPB_VC_VERSION' );
				},
			),
		);

		/**
		 * Register another page builder.
		 *
		 * @param array $builders Builder definitions.
		 */
		return apply_filters( 'kaiv_builders', $builders );
	}

	/**
	 * Builders installed and active on this site.
	 *
	 * @return string[] Builder keys.
	 */
	public static function active() {
		$active = array();

		foreach ( self::all() as $key => $builder ) {
			if ( is_callable( $builder['active'] ) && call_user_func( $builder['active'] ) ) {
				$active[] = $key;
			}
		}

		return $active;
	}

	/**
	 * @param string $key Builder key.
	 * @return string
	 */
	public static function label( $key ) {
		$all = self::all();
		return isset( $all[ $key ]['label'] ) ? $all[ $key ]['label'] : $key;
	}

	/**
	 * Which builder, if any, owns a given post.
	 *
	 * @param int $post_id Post id.
	 * @return string Builder key, or empty string for plain WordPress content.
	 */
	public static function detect_for_post( $post_id ) {
		$post_id = (int) $post_id;

		if ( defined( 'ELEMENTOR_VERSION' ) && 'builder' === get_post_meta( $post_id, '_elementor_edit_mode', true ) ) {
			return 'elementor';
		}

		if ( defined( 'CT_VERSION' ) && get_post_meta( $post_id, 'ct_builder_shortcodes', true ) ) {
			return 'oxygen';
		}

		if ( class_exists( 'FLBuilder' ) && get_post_meta( $post_id, '_fl_builder_enabled', true ) ) {
			return 'beaver';
		}

		if ( defined( 'BRICKS_VERSION' ) && get_post_meta( $post_id, '_bricks_page_content_2', true ) ) {
			return 'bricks';
		}

		if ( ( defined( '__BREAKDANCE_VERSION' ) || defined( 'BREAKDANCE_VERSION' ) ) && get_post_meta( $post_id, '_breakdance_data', true ) ) {
			return 'breakdance';
		}

		$content = get_post_field( 'post_content', $post_id );

		if ( is_string( $content ) && '' !== $content ) {
			if ( false !== strpos( $content, '[et_pb_section' ) ) {
				return 'divi';
			}
			if ( false !== strpos( $content, '[vc_row' ) ) {
				return 'wpbakery';
			}
		}

		/**
		 * Filter the detected builder for a post.
		 *
		 * @param string $builder Builder key or empty string.
		 * @param int    $post_id Post id.
		 */
		return apply_filters( 'kaiv_detect_builder', '', $post_id );
	}

	/**
	 * Read a post's builder layout in a form the model can reason about.
	 *
	 * @param int $post_id Post id.
	 * @return array|\WP_Error
	 */
	public static function read( $post_id ) {
		$post_id = (int) $post_id;
		$builder = self::detect_for_post( $post_id );

		if ( ! $builder ) {
			return array(
				'builder' => null,
				'format'  => 'post_content',
				'note'    => 'No page builder owns this post. Edit post_content with update_post as normal.',
				'content' => get_post_field( 'post_content', $post_id ),
			);
		}

		$definition = self::all()[ $builder ];

		// Shortcode builders keep the layout in post_content itself.
		if ( 'shortcode' === $definition['format'] && empty( $definition['meta'] ) ) {
			return array(
				'builder' => $builder,
				'label'   => $definition['label'],
				'format'  => 'shortcode',
				'storage' => 'post_content',
				'content' => get_post_field( 'post_content', $post_id ),
				'note'    => sprintf( '%s stores its layout as shortcodes in post_content. Preserve the shortcode structure exactly; the attributes carry the styling.', $definition['label'] ),
			);
		}

		$raw = get_post_meta( $post_id, $definition['meta'], true );

		$value = $raw;
		if ( 'json' === $definition['format'] && is_string( $raw ) && '' !== $raw ) {
			$decoded = json_decode( $raw, true );
			$value   = ( JSON_ERROR_NONE === json_last_error() ) ? $decoded : $raw;
		}

		return array(
			'builder'  => $builder,
			'label'    => $definition['label'],
			'format'   => $definition['format'],
			'storage'  => $definition['meta'],
			'content'  => $value,
			'note'     => sprintf(
				'%s stores its layout in the %s meta key. Write it back with builder_set, which re-encodes it correctly and clears the builder cache.',
				$definition['label'],
				$definition['meta']
			),
		);
	}

	/**
	 * Write a builder layout back, encoding and cache-flushing as that builder needs.
	 *
	 * @param int   $post_id Post id.
	 * @param mixed $content Layout in the same shape read() returned.
	 * @param string $builder Optional explicit builder key.
	 * @return array|\WP_Error
	 */
	public static function write( $post_id, $content, $builder = '' ) {
		$post_id = (int) $post_id;
		$builder = $builder ? $builder : self::detect_for_post( $post_id );

		if ( ! $builder ) {
			return new \WP_Error(
				'kaiv_no_builder',
				__( 'No page builder owns this post. Use update_post to change post_content instead.', 'kai-vibe' )
			);
		}

		$all = self::all();

		if ( ! isset( $all[ $builder ] ) ) {
			return new \WP_Error( 'kaiv_unknown_builder', __( 'Unrecognised page builder.', 'kai-vibe' ) );
		}

		$definition = $all[ $builder ];

		// Shortcode builders: the layout is post_content.
		if ( 'shortcode' === $definition['format'] && empty( $definition['meta'] ) ) {
			if ( ! is_string( $content ) ) {
				return new \WP_Error( 'kaiv_bad_content', __( 'This builder expects a shortcode string.', 'kai-vibe' ) );
			}

			$result = wp_update_post( array( 'ID' => $post_id, 'post_content' => wp_slash( $content ) ), true );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			self::flush( $post_id );

			return array( 'builder' => $builder, 'storage' => 'post_content', 'bytes' => strlen( $content ) );
		}

		$encoded = $content;

		if ( 'json' === $definition['format'] && ! is_string( $content ) ) {
			$encoded = wp_json_encode( $content, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		}

		// Elementor stores slashed JSON; update_post_meta will slash it again,
		// so hand it the raw string and let WordPress do exactly one pass.
		update_post_meta( $post_id, $definition['meta'], is_string( $encoded ) ? wp_slash( $encoded ) : $encoded );

		self::after_write( $builder, $post_id );
		self::flush( $post_id );

		return array(
			'builder' => $builder,
			'storage' => $definition['meta'],
			'bytes'   => is_string( $encoded ) ? strlen( $encoded ) : null,
		);
	}

	/**
	 * Builder-specific bookkeeping that has to happen alongside a layout write.
	 *
	 * @param string $builder Builder key.
	 * @param int    $post_id Post id.
	 */
	private static function after_write( $builder, $post_id ) {
		if ( 'elementor' === $builder ) {
			// Without these two, Elementor renders the post as classic content.
			update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );

			if ( defined( 'ELEMENTOR_VERSION' ) && ! get_post_meta( $post_id, '_elementor_version', true ) ) {
				update_post_meta( $post_id, '_elementor_version', ELEMENTOR_VERSION );
			}
		}

		if ( 'beaver' === $builder ) {
			update_post_meta( $post_id, '_fl_builder_enabled', true );
		}
	}

	/**
	 * Clear whatever the active builders have cached for a post.
	 *
	 * @param int $post_id Post id. 0 clears everything.
	 */
	public static function flush( $post_id = 0 ) {
		$post_id = (int) $post_id;

		// Elementor: regenerate the per-post CSS file.
		if ( class_exists( '\Elementor\Plugin' ) ) {
			try {
				$elementor = \Elementor\Plugin::$instance;

				if ( isset( $elementor->files_manager ) ) {
					$elementor->files_manager->clear_cache();
				}
			} catch ( \Throwable $e ) {
				// A cache flush failing must never fail the write itself.
			}
		}

		// Divi: drop the static CSS bundle.
		if ( function_exists( 'et_core_clear_transients' ) ) {
			et_core_clear_transients();
		}
		if ( class_exists( 'ET_Core_PageResource' ) && method_exists( 'ET_Core_PageResource', 'remove_static_resources' ) ) {
			\ET_Core_PageResource::remove_static_resources( 'all', 'all' );
		}

		// Beaver Builder.
		if ( class_exists( 'FLBuilderModel' ) && $post_id && method_exists( 'FLBuilderModel', 'delete_asset_cache_for_post' ) ) {
			\FLBuilderModel::delete_asset_cache_for_post( $post_id );
		}

		// Bricks.
		if ( class_exists( '\Bricks\Helpers' ) && method_exists( '\Bricks\Helpers', 'delete_post_css_file' ) && $post_id ) {
			\Bricks\Helpers::delete_post_css_file( $post_id );
		}

		if ( $post_id ) {
			clean_post_cache( $post_id );
		}

		/**
		 * Flush any other cache a layout change should invalidate.
		 *
		 * @param int $post_id Post id, or 0 for a site-wide flush.
		 */
		do_action( 'kaiv_flush_builder_cache', $post_id );
	}
}
