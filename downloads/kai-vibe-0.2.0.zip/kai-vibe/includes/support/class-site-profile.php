<?php
/**
 * What an agent needs to know before it starts touching a site.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Support;

defined( 'ABSPATH' ) || exit;

class SiteProfile {

	/**
	 * @return array
	 */
	public static function overview() {
		global $wp_version, $wpdb;

		$theme = wp_get_theme();

		$overview = array(
			'name'          => get_bloginfo( 'name' ),
			'description'   => get_bloginfo( 'description' ),
			'url'           => home_url(),
			'admin_url'     => admin_url(),
			'rest_url'      => rest_url(),
			'language'      => get_locale(),
			'timezone'      => wp_timezone_string(),
			'environment'   => wp_get_environment_type(),
			'is_multisite'  => is_multisite(),
			'is_public'     => (bool) get_option( 'blog_public' ),
			'permalinks'    => get_option( 'permalink_structure' ) ? get_option( 'permalink_structure' ) : 'plain (no pretty permalinks)',
			'versions'      => array(
				'wordpress' => $wp_version,
				'php'       => PHP_VERSION,
				'mysql'     => $wpdb->db_version(),
				'plugin'    => KAIV_VERSION,
			),
			'theme'         => array(
				'name'       => $theme->get( 'Name' ),
				'version'    => $theme->get( 'Version' ),
				'stylesheet' => get_stylesheet(),
				'template'   => get_template(),
				'is_child'   => is_child_theme(),
				'is_block'   => wp_is_block_theme(),
				'directory'  => str_replace( wp_normalize_path( WP_CONTENT_DIR ) . '/', '', wp_normalize_path( $theme->get_stylesheet_directory() ) ),
			),
			'builders'      => array_map( array( Builders::class, 'label' ), Builders::active() ),
			'editor'        => wp_is_block_theme() ? 'block (full site editing)' : 'classic',
			'commerce'      => self::commerce(),
			'capabilities'  => self::capabilities(),
			'counts'        => self::counts(),
		);

		/**
		 * Filter the site overview handed to the model.
		 *
		 * @param array $overview Overview.
		 */
		return apply_filters( 'kaiv_site_overview', $overview );
	}

	/**
	 * What this installation will and will not let the agent do — worth stating
	 * up front so the model does not waste calls discovering it.
	 *
	 * @return array
	 */
	public static function capabilities() {
		return array(
			'filesystem_writable' => wp_is_writable( WP_CONTENT_DIR ),
			'filesystem_roots'    => \KaiVibe\Security\PathGuard::relative_roots(),
			// Whether an agent may actually call it, and separately whether the
			// server could run it at all — reporting only the latter is
			// misleading, because run_wp_cli stays hidden until it is enabled.
			'wp_cli'              => \KaiVibe\Tools\CliTools::is_enabled(),
			'wp_cli_installed'    => \KaiVibe\Tools\CliTools::is_available(),
			'db_read'             => (bool) kaiv_setting( 'db_read_enabled', true ),
			'db_write'            => (bool) kaiv_setting( 'db_write_enabled', false ),
			'approval_gate'       => (bool) kaiv_setting( 'approval_required', true ),
			'object_cache'        => (bool) wp_using_ext_object_cache(),
			'cron_disabled'       => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON,
			'file_edit_disabled'  => defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT,
			'debug'               => defined( 'WP_DEBUG' ) && WP_DEBUG,
			'memory_limit'        => WP_MEMORY_LIMIT,
			'max_upload_size'     => size_format( wp_max_upload_size() ),
		);
	}

	/**
	 * @return array|null
	 */
	public static function commerce() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return null;
		}

		$counts = array();

		foreach ( array( 'product', 'shop_order' ) as $type ) {
			$count           = wp_count_posts( $type );
			$counts[ $type ] = $count ? array_sum( (array) $count ) : 0;
		}

		return array(
			'platform'   => 'WooCommerce',
			'version'    => defined( 'WC_VERSION' ) ? WC_VERSION : null,
			'currency'   => function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : null,
			'hpos'       => class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' )
				&& \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled(),
			'counts'     => $counts,
		);
	}

	/**
	 * @return array
	 */
	public static function counts() {
		$counts = array();

		foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $type ) {
			$count = wp_count_posts( $type->name );

			if ( ! $count ) {
				continue;
			}

			$counts[ $type->name ] = array(
				'publish' => isset( $count->publish ) ? (int) $count->publish : 0,
				'draft'   => isset( $count->draft ) ? (int) $count->draft : 0,
				'pending' => isset( $count->pending ) ? (int) $count->pending : 0,
				'private' => isset( $count->private ) ? (int) $count->private : 0,
			);
		}

		$counts['users']    = (int) count_users()['total_users'];
		$counts['comments'] = (int) wp_count_comments()->total_comments;

		return $counts;
	}

	/**
	 * @return array
	 */
	public static function post_types() {
		$types = array();

		foreach ( get_post_types( array(), 'objects' ) as $type ) {
			// Internal plumbing the model never needs to see.
			if ( in_array( $type->name, array( 'revision', 'nav_menu_item', 'custom_css', 'customize_changeset', 'oembed_cache', 'user_request', 'wp_block', 'wp_template_part' ), true ) ) {
				continue;
			}

			$types[ $type->name ] = array(
				'label'        => $type->labels->name,
				'public'       => (bool) $type->public,
				'hierarchical' => (bool) $type->hierarchical,
				'supports'     => array_keys( get_all_post_type_supports( $type->name ) ),
				'taxonomies'   => get_object_taxonomies( $type->name ),
				'rest_base'    => $type->show_in_rest ? ( $type->rest_base ? $type->rest_base : $type->name ) : null,
				'capability'   => $type->cap->edit_posts,
			);
		}

		return $types;
	}

	/**
	 * @return array
	 */
	public static function taxonomies() {
		$taxonomies = array();

		foreach ( get_taxonomies( array(), 'objects' ) as $taxonomy ) {
			if ( in_array( $taxonomy->name, array( 'nav_menu', 'link_category', 'post_format', 'wp_theme', 'wp_template_part_area' ), true ) ) {
				continue;
			}

			$taxonomies[ $taxonomy->name ] = array(
				'label'        => $taxonomy->labels->name,
				'public'       => (bool) $taxonomy->public,
				'hierarchical' => (bool) $taxonomy->hierarchical,
				'post_types'   => array_values( (array) $taxonomy->object_type ),
				'terms'        => (int) wp_count_terms( array( 'taxonomy' => $taxonomy->name, 'hide_empty' => false ) ),
			);
		}

		return $taxonomies;
	}

	/**
	 * @return array
	 */
	public static function extensions() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$updates = get_site_transient( 'update_plugins' );
		$plugins = array();

		foreach ( get_plugins() as $file => $data ) {
			$plugins[] = array(
				'file'      => $file,
				'slug'      => dirname( $file ),
				'name'      => $data['Name'],
				'version'   => $data['Version'],
				'active'    => is_plugin_active( $file ),
				'network'   => is_multisite() && is_plugin_active_for_network( $file ),
				'update'    => isset( $updates->response[ $file ] ) ? $updates->response[ $file ]->new_version : null,
				'author'    => wp_strip_all_tags( $data['Author'] ),
			);
		}

		$theme_updates = get_site_transient( 'update_themes' );
		$themes        = array();

		foreach ( wp_get_themes() as $stylesheet => $theme ) {
			$themes[] = array(
				'stylesheet' => $stylesheet,
				'name'       => $theme->get( 'Name' ),
				'version'    => $theme->get( 'Version' ),
				'active'     => get_stylesheet() === $stylesheet,
				'parent'     => $theme->parent() ? $theme->parent()->get_stylesheet() : null,
				'block'      => $theme->is_block_theme(),
				'update'     => isset( $theme_updates->response[ $stylesheet ] ) ? $theme_updates->response[ $stylesheet ]['new_version'] : null,
			);
		}

		return array( 'plugins' => $plugins, 'themes' => $themes );
	}
}
