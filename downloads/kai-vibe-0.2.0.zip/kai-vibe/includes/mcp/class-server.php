<?php
/**
 * JSON-RPC 2.0 dispatcher implementing the MCP server methods.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Mcp;

use KaiVibe\Auth\Authenticator;
use KaiVibe\Security\RateLimiter;

defined( 'ABSPATH' ) || exit;

class Server {

	/** Protocol revision this server implements. */
	const PROTOCOL_VERSION = '2025-06-18';

	/** Revisions we will happily speak if the client asks for them. */
	const SUPPORTED_VERSIONS = array( '2025-06-18', '2025-03-26', '2024-11-05' );

	const PARSE_ERROR      = -32700;
	const INVALID_REQUEST  = -32600;
	const METHOD_NOT_FOUND = -32601;
	const INVALID_PARAMS   = -32602;
	const INTERNAL_ERROR   = -32603;

	/** @var string Version negotiated during initialize. */
	private $protocol_version = self::PROTOCOL_VERSION;

	/**
	 * Handle a single JSON-RPC message.
	 *
	 * @param array $message Decoded message.
	 * @return array|null Response, or null for notifications.
	 */
	public function handle( array $message ) {
		$id     = isset( $message['id'] ) ? $message['id'] : null;
		$method = isset( $message['method'] ) ? (string) $message['method'] : '';
		$params = isset( $message['params'] ) && is_array( $message['params'] ) ? $message['params'] : array();

		$is_notification = ! array_key_exists( 'id', $message ) || null === $id;

		if ( '' === $method ) {
			return $is_notification ? null : $this->error( $id, self::INVALID_REQUEST, __( 'No method given.', 'kai-vibe' ) );
		}

		// Notifications get acknowledged with no body.
		if ( 0 === strpos( $method, 'notifications/' ) ) {
			return null;
		}

		try {
			switch ( $method ) {
				case 'initialize':
					$result = $this->initialize( $params );
					break;

				case 'ping':
					$result = (object) array();
					break;

				case 'tools/list':
					$result = $this->tools_list( $params );
					break;

				case 'tools/call':
					$result = $this->tools_call( $params );
					break;

				case 'resources/list':
					$result = Resources::instance()->list_resources();
					break;

				case 'resources/templates/list':
					$result = Resources::instance()->list_templates();
					break;

				case 'resources/read':
					$result = Resources::instance()->read( isset( $params['uri'] ) ? (string) $params['uri'] : '' );
					break;

				case 'prompts/list':
					$result = Prompts::instance()->list_prompts();
					break;

				case 'prompts/get':
					$result = Prompts::instance()->get(
						isset( $params['name'] ) ? (string) $params['name'] : '',
						isset( $params['arguments'] ) ? (array) $params['arguments'] : array()
					);
					break;

				case 'logging/setLevel':
					$result = (object) array();
					break;

				default:
					/**
					 * Handle a method this server does not implement natively.
					 *
					 * @param mixed  $result Return anything non-null to answer the call.
					 * @param string $method Method name.
					 * @param array  $params Params.
					 */
					$result = apply_filters( 'kaiv_handle_method', null, $method, $params );

					if ( null === $result ) {
						return $is_notification ? null : $this->error(
							$id,
							self::METHOD_NOT_FOUND,
							sprintf(
								/* translators: %s: JSON-RPC method name. */
								__( 'Unknown method "%s".', 'kai-vibe' ),
								$method
							)
						);
					}
			}
		} catch ( McpException $e ) {
			return $is_notification ? null : $this->error( $id, $e->getCode(), $e->getMessage(), $e->data() );
		} catch ( \Throwable $e ) {
			kaiv_audit( 'server.exception', array( 'method' => $method, 'message' => $e->getMessage() ) );
			return $is_notification ? null : $this->error( $id, self::INTERNAL_ERROR, $e->getMessage() );
		}

		if ( $is_notification ) {
			return null;
		}

		return array(
			'jsonrpc' => '2.0',
			'id'      => $id,
			'result'  => $result,
		);
	}

	/**
	 * @param array $params Initialize params.
	 * @return array
	 */
	private function initialize( array $params ) {
		$requested = isset( $params['protocolVersion'] ) ? (string) $params['protocolVersion'] : self::PROTOCOL_VERSION;

		$this->protocol_version = in_array( $requested, self::SUPPORTED_VERSIONS, true )
			? $requested
			: self::PROTOCOL_VERSION;

		$client = isset( $params['clientInfo'] ) ? (array) $params['clientInfo'] : array();

		kaiv_audit(
			'session.initialize',
			array(
				'client'   => isset( $client['name'] ) ? $client['name'] : 'unknown',
				'version'  => isset( $client['version'] ) ? $client['version'] : '',
				'protocol' => $this->protocol_version,
			)
		);

		return array(
			'protocolVersion' => $this->protocol_version,
			'capabilities'    => array(
				'tools'     => array( 'listChanged' => false ),
				'resources' => array( 'subscribe' => false, 'listChanged' => false ),
				'prompts'   => array( 'listChanged' => false ),
				'logging'   => (object) array(),
			),
			'serverInfo'      => array(
				'name'    => 'kai-vibe',
				'title'   => get_bloginfo( 'name' ) . ' — KAI Vibe',
				'version' => KAIV_VERSION,
			),
			'instructions'    => $this->instructions(),
		);
	}

	/**
	 * Guidance handed to the model at connection time. Worth its weight: it is
	 * the difference between an agent that reaches for raw SQL and one that
	 * reaches for the right tool.
	 *
	 * @return string
	 */
	private function instructions() {
		$auth   = Authenticator::instance();
		$scopes = $auth->scopes();
		$user   = wp_get_current_user();

		$lines = array(
			sprintf( 'You are connected to the WordPress site "%s" at %s via KAI Vibe.', get_bloginfo( 'name' ), home_url() ),
			sprintf( 'You are acting as the WordPress user "%s" (%s). Everything you do is attributed to that account and written to an audit log the site owner can read.', $user->user_login, implode( ', ', $user->roles ) ),
			'',
			'Working rules:',
			'1. Call site_info first on a new task. It reports the active theme, page builder, WooCommerce status and PHP/WP versions, which determines which tools will actually work.',
			'2. Prefer the most specific tool available. Reach for run_wp_cli or db_query only when nothing more specific exists — they bypass the hooks that keep caches and derived data correct.',
			'3. Page builder content is not stored in post_content. Use builder_get and builder_set for Elementor, Divi, Beaver Builder, Bricks and Breakdance, or the layout will render stale or broken.',
			'4. Before overwriting a file or a post body, read it first. Every write is journalled — list_changes and undo_change will get you out of a mistake.',
			'5. Destructive operations may return an approval request instead of a result. That is not a failure: tell the human to approve it in wp-admin, then call check_approval to continue.',
			'',
			sprintf( 'Scopes granted to this connection: %s', implode( ', ', $scopes ) ),
		);

		/**
		 * Filter the instructions sent to the model on connect.
		 *
		 * @param string[] $lines Instruction lines.
		 */
		$lines = apply_filters( 'kaiv_instructions', $lines );

		return implode( "\n", $lines );
	}

	/**
	 * @param array $params List params (cursor is accepted and ignored — the
	 *                      tool list is small enough to send in one page).
	 * @return array
	 */
	private function tools_list( array $params ) {
		$tools = array();

		foreach ( kaiv()->tools()->available() as $tool ) {
			$tools[] = $tool->to_array();
		}

		return array( 'tools' => $tools );
	}

	/**
	 * @param array $params Call params.
	 * @return array
	 * @throws McpException When the tool does not exist.
	 */
	private function tools_call( array $params ) {
		$name = isset( $params['name'] ) ? (string) $params['name'] : '';
		$args = isset( $params['arguments'] ) && is_array( $params['arguments'] ) ? $params['arguments'] : array();

		if ( '' === $name ) {
			throw new McpException( __( 'No tool name given.', 'kai-vibe' ), self::INVALID_PARAMS );
		}

		$tool = kaiv()->tools()->get( $name );

		if ( ! $tool ) {
			throw new McpException(
				sprintf(
					/* translators: %s: tool name. */
					__( 'There is no tool called "%s" on this site.', 'kai-vibe' ),
					$name
				),
				self::METHOD_NOT_FOUND
			);
		}

		$limited = RateLimiter::check();
		if ( is_wp_error( $limited ) ) {
			return ToolResult::error( $limited->get_error_message(), (array) $limited->get_error_data() )->to_array();
		}

		$started = microtime( true );
		$result  = $tool->execute( $args );
		$elapsed = (int) round( ( microtime( true ) - $started ) * 1000 );

		kaiv_audit(
			'tool.' . $name,
			array(
				'arguments'   => $args,
				'status'      => $result->is_error() ? 'error' : 'ok',
				'duration_ms' => $elapsed,
			)
		);

		return $result->to_array();
	}

	/**
	 * @param mixed  $id      Request id.
	 * @param int    $code    JSON-RPC error code.
	 * @param string $message Message.
	 * @param mixed  $data    Optional data.
	 * @return array
	 */
	public function error( $id, $code, $message, $data = null ) {
		$error = array(
			'code'    => (int) $code,
			'message' => (string) $message,
		);

		if ( null !== $data ) {
			$error['data'] = $data;
		}

		return array(
			'jsonrpc' => '2.0',
			'id'      => $id,
			'error'   => $error,
		);
	}
}
