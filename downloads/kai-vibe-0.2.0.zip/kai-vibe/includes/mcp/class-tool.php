<?php
/**
 * A single MCP tool: its schema, its gates, and its callback.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Mcp;

use KaiVibe\Auth\Authenticator;
use KaiVibe\Security\Approval;

defined( 'ABSPATH' ) || exit;

class Tool {

	/** @var string */
	public $name;

	/** @var string */
	public $title = '';

	/** @var string */
	public $description = '';

	/** @var array */
	public $input_schema;

	/** @var array|null */
	public $output_schema = null;

	/** @var string Required scope. */
	public $scope = '';

	/** @var string Required WordPress capability, checked against the acting user. */
	public $capability = '';

	/** @var callable|null */
	public $callback = null;

	/** @var array MCP tool annotations. */
	public $annotations = array();

	/** @var bool Route through the wp-admin approval gate when enabled. */
	public $needs_approval = false;

	/** @var callable|null Returns false to hide the tool from tools/list. */
	public $availability = null;

	/**
	 * @var callable|null Runs after validation but before the approval gate.
	 *                    Return a ToolResult or WP_Error to refuse the call.
	 */
	public $precheck = null;

	/**
	 * @param string $name Tool name as the model sees it.
	 * @return Tool
	 */
	public static function make( $name ) {
		$tool               = new self();
		$tool->name         = $name;
		$tool->input_schema = Schema::object();
		return $tool;
	}

	/**
	 * @param string $description What the tool does and when to reach for it.
	 * @param string $title       Optional short display title.
	 * @return Tool
	 */
	public function describe( $description, $title = '' ) {
		$this->description = $description;
		$this->title       = $title;
		return $this;
	}

	/**
	 * @param array $schema Input JSON Schema.
	 * @return Tool
	 */
	public function input( array $schema ) {
		$this->input_schema = $schema;
		return $this;
	}

	/**
	 * @param array $schema Output JSON Schema.
	 * @return Tool
	 */
	public function output( array $schema ) {
		$this->output_schema = $schema;
		return $this;
	}

	/**
	 * @param string $scope Scope required to call this tool.
	 * @return Tool
	 */
	public function scope( $scope ) {
		$this->scope = $scope;
		return $this;
	}

	/**
	 * @param string $capability WordPress capability the acting user must hold.
	 * @return Tool
	 */
	public function cap( $capability ) {
		$this->capability = $capability;
		return $this;
	}

	/**
	 * Marks the tool as non-mutating. Clients use this to decide what may run
	 * without asking the human first.
	 *
	 * @return Tool
	 */
	public function read_only() {
		$this->annotations['readOnlyHint'] = true;
		return $this;
	}

	/**
	 * @param bool $idempotent Calling twice has the same effect as once.
	 * @return Tool
	 */
	public function destructive( $idempotent = false ) {
		$this->annotations['readOnlyHint']    = false;
		$this->annotations['destructiveHint'] = true;
		$this->annotations['idempotentHint']  = (bool) $idempotent;
		return $this;
	}

	/**
	 * Require an explicit human approval in wp-admin before this runs.
	 *
	 * @return Tool
	 */
	public function gated() {
		$this->needs_approval = true;
		return $this;
	}

	/**
	 * @param callable $check Returns bool. Hides the tool when false.
	 * @return Tool
	 */
	public function available_when( callable $check ) {
		$this->availability = $check;
		return $this;
	}

	/**
	 * Refuse impossible calls before the approval gate sees them.
	 *
	 * Without this, a gated tool asks the site owner to approve an operation
	 * that its own callback would then reject anyway — writing a locked option,
	 * deleting a plugin that is still active, a path outside the jail. The owner
	 * gets a request that cannot succeed, and an agent can fill the queue with
	 * them. Whatever makes a call impossible belongs here, not in the callback.
	 *
	 * @param callable $check function( array $args, Tool $tool ): ToolResult|WP_Error|null
	 * @return Tool
	 */
	public function precheck( callable $check ) {
		$this->precheck = $check;
		return $this;
	}

	/**
	 * @param callable $callback function( array $args, Tool $tool ): mixed
	 * @return Tool
	 */
	public function run( callable $callback ) {
		$this->callback = $callback;
		return $this;
	}

	/**
	 * @return bool
	 */
	public function is_available() {
		if ( $this->availability && ! call_user_func( $this->availability, $this ) ) {
			return false;
		}

		// Hide tools the current token could never call anyway — a smaller,
		// honest tool list beats a long one full of permission errors.
		$auth = Authenticator::instance();
		if ( $auth->token() && ! $auth->has_scope( $this->scope ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Wire format for tools/list.
	 *
	 * @return array
	 */
	public function to_array() {
		$definition = array(
			'name'        => $this->name,
			'description' => $this->description,
			'inputSchema' => $this->input_schema,
		);

		if ( '' !== $this->title ) {
			$definition['title'] = $this->title;
		}

		if ( $this->output_schema ) {
			$definition['outputSchema'] = $this->output_schema;
		}

		$annotations = $this->annotations;

		// Surface our own metadata under _meta so it never collides with the spec.
		$meta = array_filter(
			array(
				'kaiv/scope'         => $this->scope,
				'kaiv/capability'    => $this->capability,
				'kaiv/needsApproval' => $this->needs_approval ? true : null,
			)
		);

		if ( $meta ) {
			$definition['_meta'] = $meta;
		}

		if ( $annotations ) {
			if ( '' !== $this->title ) {
				$annotations['title'] = $this->title;
			}
			$definition['annotations'] = $annotations;
		}

		return $definition;
	}

	/**
	 * Run every gate, then the callback.
	 *
	 * @param array $raw_args Arguments from tools/call.
	 * @return ToolResult
	 */
	public function execute( array $raw_args ) {
		$auth = Authenticator::instance();

		// is_available() gates tools/list, but a client may call a tool name it
		// saw earlier or guessed. Without this, a tool whose dependency is gone
		// (WooCommerce deactivated, a builder uninstalled) reaches its callback
		// and dies on an undefined function instead of refusing cleanly.
		if ( $this->availability && ! call_user_func( $this->availability, $this ) ) {
			return ToolResult::error(
				sprintf(
					/* translators: %s: tool name. */
					__( 'The tool "%s" is not available on this site — whatever it depends on is not installed or not active.', 'kai-vibe' ),
					$this->name
				),
				array( 'tool' => $this->name )
			);
		}

		if ( ! $auth->has_scope( $this->scope ) ) {
			return ToolResult::error(
				sprintf(
					/* translators: %s: scope name. */
					__( 'This connection is not authorised for "%s". Add the scope to the token in KAI Vibe → Tokens, then try again.', 'kai-vibe' ),
					$this->scope
				),
				array( 'required_scope' => $this->scope, 'granted_scopes' => $auth->scopes() )
			);
		}

		if ( $this->capability && ! current_user_can( $this->capability ) ) {
			return ToolResult::error(
				sprintf(
					/* translators: %s: capability name. */
					__( 'The WordPress user this token acts as lacks the "%s" capability.', 'kai-vibe' ),
					$this->capability
				),
				array( 'required_capability' => $this->capability )
			);
		}

		$args = Validator::apply( $this->input_schema, $raw_args );
		if ( is_wp_error( $args ) ) {
			return ToolResult::error( $args->get_error_message(), (array) $args->get_error_data() );
		}

		// Anything that makes the call impossible must be settled before the
		// approval gate, so the owner is never asked to approve a doomed call.
		if ( $this->precheck ) {
			$refusal = call_user_func( $this->precheck, $args, $this );

			if ( $refusal instanceof ToolResult ) {
				return $refusal;
			}

			if ( is_wp_error( $refusal ) ) {
				return self::normalise( $refusal );
			}
		}

		if ( $this->needs_approval ) {
			$gate = Approval::gate( $this, $args );
			if ( $gate instanceof ToolResult ) {
				return $gate;
			}
		}

		try {
			$value = call_user_func( $this->callback, $args, $this );
		} catch ( \Throwable $e ) {
			return ToolResult::error(
				sprintf(
					/* translators: 1: tool name, 2: error message. */
					__( '%1$s failed: %2$s', 'kai-vibe' ),
					$this->name,
					$e->getMessage()
				),
				array( 'exception' => get_class( $e ) )
			);
		}

		return self::normalise( $value );
	}

	/**
	 * Let callbacks return whatever is natural and turn it into a ToolResult.
	 *
	 * @param mixed $value Callback return value.
	 * @return ToolResult
	 */
	public static function normalise( $value ) {
		if ( $value instanceof ToolResult ) {
			return $value;
		}

		if ( is_wp_error( $value ) ) {
			$data = $value->get_error_data();
			return ToolResult::error( $value->get_error_message(), is_array( $data ) ? $data : array() );
		}

		if ( is_string( $value ) ) {
			return ToolResult::text( $value );
		}

		if ( null === $value || true === $value ) {
			return ToolResult::json( array( 'ok' => true ) );
		}

		return ToolResult::json( $value );
	}
}
