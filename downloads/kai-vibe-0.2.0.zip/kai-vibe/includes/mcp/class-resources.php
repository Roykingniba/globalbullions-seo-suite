<?php
/**
 * MCP resources: read-only context a client can pull in without a tool call.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Mcp;

use KaiVibe\Auth\Authenticator;
use KaiVibe\Security\PathGuard;

defined( 'ABSPATH' ) || exit;

class Resources {

	/** @var Resources|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * @return array
	 */
	public function definitions() {
		$definitions = array(
			'wp://site/overview'   => array(
				'name'        => 'Site overview',
				'description' => 'Name, URL, versions, active theme, detected page builder and commerce stack.',
				'mimeType'    => 'application/json',
				'scope'       => 'site:read',
			),
			'wp://site/post-types' => array(
				'name'        => 'Registered post types',
				'description' => 'Every public and private post type with its supports, taxonomies and REST base.',
				'mimeType'    => 'application/json',
				'scope'       => 'site:read',
			),
			'wp://site/taxonomies' => array(
				'name'        => 'Registered taxonomies',
				'description' => 'Every taxonomy, which post types it applies to, and whether it is hierarchical.',
				'mimeType'    => 'application/json',
				'scope'       => 'site:read',
			),
			'wp://site/extensions' => array(
				'name'        => 'Plugins and themes',
				'description' => 'Installed plugins and themes with version and activation state.',
				'mimeType'    => 'application/json',
				'scope'       => 'extensions:read',
			),
			'wp://site/tools'      => array(
				'name'        => 'Tool catalogue',
				'description' => 'Every tool this connection can call, grouped by scope.',
				'mimeType'    => 'application/json',
				'scope'       => '',
			),
		);

		/**
		 * Filter the registered MCP resources.
		 *
		 * @param array $definitions URI => definition.
		 */
		return apply_filters( 'kaiv_resources', $definitions );
	}

	/**
	 * @return array
	 */
	public function list_resources() {
		$auth      = Authenticator::instance();
		$resources = array();

		foreach ( $this->definitions() as $uri => $definition ) {
			if ( ! empty( $definition['scope'] ) && ! $auth->has_scope( $definition['scope'] ) ) {
				continue;
			}

			$resources[] = array(
				'uri'         => $uri,
				'name'        => $definition['name'],
				'description' => $definition['description'],
				'mimeType'    => $definition['mimeType'],
			);
		}

		return array( 'resources' => $resources );
	}

	/**
	 * @return array
	 */
	public function list_templates() {
		$templates = array(
			array(
				'uriTemplate' => 'wp://post/{id}',
				'name'        => 'Post by ID',
				'description' => 'Full record for a single post of any type, including meta.',
				'mimeType'    => 'application/json',
			),
			array(
				'uriTemplate' => 'wp://file/{path}',
				'name'        => 'File inside the allowed roots',
				'description' => 'Raw contents of a theme or plugin file, relative to wp-content.',
				'mimeType'    => 'text/plain',
			),
			array(
				'uriTemplate' => 'wp://option/{name}',
				'name'        => 'Option value',
				'description' => 'A single row from the options table, if it is not protected.',
				'mimeType'    => 'application/json',
			),
		);

		return array( 'resourceTemplates' => $templates );
	}

	/**
	 * @param string $uri Resource URI.
	 * @return array
	 * @throws McpException When the URI is unknown or not permitted.
	 */
	public function read( $uri ) {
		$auth = Authenticator::instance();

		$definitions = $this->definitions();
		if ( isset( $definitions[ $uri ] ) ) {
			$definition = $definitions[ $uri ];

			if ( ! empty( $definition['scope'] ) && ! $auth->has_scope( $definition['scope'] ) ) {
				throw new McpException( __( 'This connection is not authorised to read that resource.', 'kai-vibe' ), Server::INVALID_PARAMS );
			}

			return $this->wrap( $uri, 'application/json', $this->read_static( $uri ) );
		}

		// wp://post/123
		if ( preg_match( '#^wp://post/(\d+)$#', $uri, $m ) ) {
			if ( ! $auth->has_scope( 'content:read' ) ) {
				throw new McpException( __( 'The content:read scope is required.', 'kai-vibe' ), Server::INVALID_PARAMS );
			}

			$post = get_post( (int) $m[1] );
			if ( ! $post || ! current_user_can( 'read_post', $post->ID ) ) {
				throw new McpException( __( 'That post does not exist or is not readable.', 'kai-vibe' ), Server::INVALID_PARAMS );
			}

			return $this->wrap( $uri, 'application/json', \KaiVibe\Support\Formatter::post( $post, true ) );
		}

		// wp://option/foo
		if ( preg_match( '#^wp://option/([A-Za-z0-9_\-]+)$#', $uri, $m ) ) {
			if ( ! $auth->has_scope( 'options:read' ) ) {
				throw new McpException( __( 'The options:read scope is required.', 'kai-vibe' ), Server::INVALID_PARAMS );
			}
			if ( \KaiVibe\Security\ProtectedData::is_protected_option( $m[1] ) ) {
				throw new McpException( __( 'That option is protected.', 'kai-vibe' ), Server::INVALID_PARAMS );
			}

			return $this->wrap( $uri, 'application/json', array( 'option' => $m[1], 'value' => get_option( $m[1] ) ) );
		}

		// wp://file/themes/x/style.css
		if ( 0 === strpos( $uri, 'wp://file/' ) ) {
			if ( ! $auth->has_scope( 'fs:read' ) ) {
				throw new McpException( __( 'The fs:read scope is required.', 'kai-vibe' ), Server::INVALID_PARAMS );
			}

			$relative = substr( $uri, strlen( 'wp://file/' ) );
			$resolved = PathGuard::resolve( $relative );

			if ( is_wp_error( $resolved ) ) {
				throw new McpException( $resolved->get_error_message(), Server::INVALID_PARAMS );
			}

			// PathGuard::resolve() accepts directories, and file_get_contents()
			// on one emits a PHP warning into the response body. An unreadable
			// file returns false, which is not a valid "text" value either.
			if ( ! is_file( $resolved ) || ! is_readable( $resolved ) ) {
				throw new McpException(
					sprintf(
						/* translators: %s: resource URI. */
						__( '%s is not a readable file.', 'kai-vibe' ),
						$uri
					),
					Server::INVALID_PARAMS
				);
			}

			$contents = file_get_contents( $resolved ); // phpcs:ignore WordPress.WP.AlternativeFunctions

			if ( false === $contents ) {
				throw new McpException(
					sprintf(
						/* translators: %s: resource URI. */
						__( 'Could not read %s.', 'kai-vibe' ),
						$uri
					),
					Server::INTERNAL_ERROR
				);
			}

			return array(
				'contents' => array(
					array(
						'uri'      => $uri,
						'mimeType' => 'text/plain',
						'text'     => $contents,
					),
				),
			);
		}

		throw new McpException(
			sprintf(
				/* translators: %s: resource URI. */
				__( 'Unknown resource "%s".', 'kai-vibe' ),
				$uri
			),
			Server::INVALID_PARAMS
		);
	}

	/**
	 * @param string $uri Static resource URI.
	 * @return array
	 */
	private function read_static( $uri ) {
		switch ( $uri ) {
			case 'wp://site/overview':
				return \KaiVibe\Support\SiteProfile::overview();

			case 'wp://site/post-types':
				return \KaiVibe\Support\SiteProfile::post_types();

			case 'wp://site/taxonomies':
				return \KaiVibe\Support\SiteProfile::taxonomies();

			case 'wp://site/extensions':
				return \KaiVibe\Support\SiteProfile::extensions();

			case 'wp://site/tools':
				$catalogue = array();
				foreach ( kaiv()->tools()->available() as $tool ) {
					$scope                 = $tool->scope ? $tool->scope : 'open';
					$catalogue[ $scope ][] = array(
						'name'        => $tool->name,
						'description' => $tool->description,
					);
				}
				return $catalogue;
		}

		/**
		 * Provide the body for a custom resource.
		 *
		 * @param array  $body Body.
		 * @param string $uri  Resource URI.
		 */
		return apply_filters( 'kaiv_resource_body', array(), $uri );
	}

	/**
	 * @param string $uri       URI.
	 * @param string $mime_type MIME type.
	 * @param mixed  $data      Payload.
	 * @return array
	 */
	private function wrap( $uri, $mime_type, $data ) {
		return array(
			'contents' => array(
				array(
					'uri'      => $uri,
					'mimeType' => $mime_type,
					'text'     => wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
				),
			),
		);
	}
}
