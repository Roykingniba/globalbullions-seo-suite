<?php
/**
 * Holds every registered tool.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Mcp;

defined( 'ABSPATH' ) || exit;

class ToolRegistry {

	/** @var Tool[] Keyed by tool name. */
	private $tools = array();

	/**
	 * @param Tool $tool Tool to register. Later registrations win, which lets
	 *                   site code override a built-in tool by name.
	 * @return ToolRegistry
	 */
	public function add( Tool $tool ) {
		if ( ! $tool->callback ) {
			_doing_it_wrong( __METHOD__, esc_html( sprintf( 'Tool "%s" has no callback.', $tool->name ) ), '0.1.0' );
			return $this;
		}

		$this->tools[ $tool->name ] = $tool;
		return $this;
	}

	/**
	 * @param string $name Tool name.
	 * @return Tool|null
	 */
	public function get( $name ) {
		return isset( $this->tools[ $name ] ) ? $this->tools[ $name ] : null;
	}

	/**
	 * @param string $name Tool name.
	 * @return bool
	 */
	public function has( $name ) {
		return isset( $this->tools[ $name ] );
	}

	/**
	 * @param string $name Tool name.
	 * @return ToolRegistry
	 */
	public function remove( $name ) {
		unset( $this->tools[ $name ] );
		return $this;
	}

	/**
	 * Every registered tool, regardless of availability.
	 *
	 * @return Tool[]
	 */
	public function all() {
		return $this->tools;
	}

	/**
	 * Tools the current connection may actually see.
	 *
	 * @return Tool[]
	 */
	public function available() {
		$available = array();

		foreach ( $this->tools as $name => $tool ) {
			if ( $tool->is_available() ) {
				$available[ $name ] = $tool;
			}
		}

		ksort( $available );

		return $available;
	}

	/**
	 * @return int
	 */
	public function count() {
		return count( $this->tools );
	}
}
