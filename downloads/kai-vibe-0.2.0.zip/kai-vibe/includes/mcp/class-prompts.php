<?php
/**
 * MCP prompts: ready-made workflows the human can pick from the client UI.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Mcp;

defined( 'ABSPATH' ) || exit;

class Prompts {

	/** @var Prompts|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * @return array name => definition
	 */
	public function definitions() {
		$prompts = array(
			'site_health_review' => array(
				'title'       => 'Review this site',
				'description' => 'Survey the site and report what is broken, risky or out of date, without changing anything.',
				'arguments'   => array(),
				'template'    => "Review this WordPress site and report back. Do not change anything.\n\n"
					. "1. Call site_info and site_health.\n"
					. "2. Call list_plugins and list_themes; flag anything inactive, outdated or abandoned.\n"
					. "3. Call list_options for the handful that matter (blog_public, permalink_structure, default_role, users_can_register) and flag anything unsafe.\n"
					. "4. Call find_content with no filters to sample the content: count published vs draft, and note any post type that is empty.\n\n"
					. "Write the result as a short prioritised list: Critical, Worth fixing, Nice to have. For each item say what you would run to fix it, but do not run it.",
			),

			'write_post'         => array(
				'title'       => 'Draft a post',
				'description' => 'Research the site\'s existing voice, then draft a new post as a draft for review.',
				'arguments'   => array(
					array( 'name' => 'topic', 'description' => 'What the post should be about.', 'required' => true ),
					array( 'name' => 'length', 'description' => 'Rough word count. Defaults to 900.', 'required' => false ),
				),
				'template'    => "Draft a new post about: {topic}\n\n"
					. "First, call find_content with post_type=post and per_page=5 and read two or three recent posts with get_post so you can match the existing voice, heading style and formatting conventions. Note whether the site writes in blocks or classic HTML.\n\n"
					. "Then create the post with create_post, status=draft, target length around {length} words. Use proper block markup if the site is block-based. Set an excerpt and assign existing categories — call list_terms first, do not invent new ones.\n\n"
					. "Finish by telling me the edit URL and a one-line summary of the angle you took.",
			),

			'fix_page'           => array(
				'title'       => 'Fix a broken page',
				'description' => 'Diagnose a page that renders wrong, builder-aware, and repair it safely.',
				'arguments'   => array(
					array( 'name' => 'url', 'description' => 'URL of the page that is broken.', 'required' => true ),
				),
				'template'    => "The page at {url} is not rendering correctly.\n\n"
					. "1. Call site_info to find out which page builder is active.\n"
					. "2. Resolve the URL to a post with find_content, then call get_post.\n"
					. "3. If a builder is active, call builder_get — the layout lives in meta, not post_content, and reading post_content will mislead you.\n"
					. "4. Diagnose before you edit. Tell me what you found and what you intend to change.\n"
					. "5. Make the fix with builder_set or update_post. Both journal the previous state, so say so and remind me undo_change exists.\n"
					. "6. Flush caches with flush_cache and confirm the fix with fetch_rendered_page.",
			),

			'bulk_cleanup'       => array(
				'title'       => 'Content cleanup',
				'description' => 'Find and fix the dull content problems: missing excerpts, empty alt text, orphan drafts.',
				'arguments'   => array(
					array( 'name' => 'post_type', 'description' => 'Post type to clean up. Defaults to post.', 'required' => false ),
				),
				'template'    => "Do a content cleanup pass over the {post_type} post type.\n\n"
					. "Find, and list before fixing:\n"
					. "- published items with an empty excerpt\n"
					. "- attachments used in those items with empty alt text (search_media)\n"
					. "- drafts older than six months with no revisions since\n"
					. "- items with no category or only the default category\n\n"
					. "Show me the full list first with counts. Wait for me to confirm before writing anything. When I confirm, fix them in batches of ten and report progress as you go.",
			),
		);

		/**
		 * Filter the available MCP prompts.
		 *
		 * @param array $prompts Prompt definitions.
		 */
		return apply_filters( 'kaiv_prompts', $prompts );
	}

	/**
	 * @return array
	 */
	public function list_prompts() {
		$prompts = array();

		foreach ( $this->definitions() as $name => $definition ) {
			$prompts[] = array(
				'name'        => $name,
				'title'       => $definition['title'],
				'description' => $definition['description'],
				'arguments'   => $definition['arguments'],
			);
		}

		return array( 'prompts' => $prompts );
	}

	/**
	 * @param string $name      Prompt name.
	 * @param array  $arguments Supplied arguments.
	 * @return array
	 * @throws McpException When the prompt is unknown or an argument is missing.
	 */
	public function get( $name, array $arguments ) {
		$definitions = $this->definitions();

		if ( ! isset( $definitions[ $name ] ) ) {
			throw new McpException(
				sprintf(
					/* translators: %s: prompt name. */
					__( 'Unknown prompt "%s".', 'kai-vibe' ),
					$name
				),
				Server::INVALID_PARAMS
			);
		}

		$definition = $definitions[ $name ];
		$defaults   = array( 'length' => '900', 'post_type' => 'post' );
		$text       = $definition['template'];

		foreach ( $definition['arguments'] as $argument ) {
			$key = $argument['name'];

			if ( ! empty( $argument['required'] ) && empty( $arguments[ $key ] ) ) {
				throw new McpException(
					sprintf(
						/* translators: %s: argument name. */
						__( 'The "%s" argument is required for this prompt.', 'kai-vibe' ),
						$key
					),
					Server::INVALID_PARAMS
				);
			}

			$value = isset( $arguments[ $key ] ) && '' !== $arguments[ $key ]
				? $arguments[ $key ]
				: ( isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' );

			$text = str_replace( '{' . $key . '}', (string) $value, $text );
		}

		// Any placeholder with no declared argument falls back to its default.
		foreach ( $defaults as $key => $value ) {
			$text = str_replace( '{' . $key . '}', $value, $text );
		}

		return array(
			'description' => $definition['description'],
			'messages'    => array(
				array(
					'role'    => 'user',
					'content' => array( 'type' => 'text', 'text' => $text ),
				),
			),
		);
	}
}
