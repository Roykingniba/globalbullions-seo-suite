<?php
/**
 * Pragmatic JSON Schema validation for tool arguments.
 *
 * This is deliberately not a complete JSON Schema implementation. It covers the
 * keywords the tool definitions actually use, applies defaults, and coerces the
 * shapes models commonly get slightly wrong ("12" for an integer, a comma string
 * for an array) instead of failing the call over them.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Mcp;

defined( 'ABSPATH' ) || exit;

class Validator {

	/**
	 * Validate and coerce arguments against a schema.
	 *
	 * @param array $schema Input schema.
	 * @param array $args   Raw arguments.
	 * @return array|\WP_Error Cleaned arguments.
	 */
	public static function apply( array $schema, array $args ) {
		$properties = isset( $schema['properties'] ) ? (array) $schema['properties'] : array();
		$required   = isset( $schema['required'] ) ? (array) $schema['required'] : array();
		$clean      = array();
		$errors     = array();

		foreach ( $required as $key ) {
			$missing = ! array_key_exists( $key, $args )
				|| null === $args[ $key ]
				|| ( is_string( $args[ $key ] ) && '' === trim( $args[ $key ] ) );

			if ( $missing ) {
				$errors[] = sprintf( 'Missing required argument "%s".', $key );
			}
		}

		if ( $errors ) {
			return new \WP_Error(
				'kaiv_invalid_args',
				implode( ' ', $errors ),
				array( 'errors' => $errors, 'expected' => array_keys( $properties ) )
			);
		}

		foreach ( $properties as $key => $spec ) {
			$spec = (array) $spec;

			if ( ! array_key_exists( $key, $args ) || null === $args[ $key ] ) {
				if ( array_key_exists( 'default', $spec ) ) {
					$clean[ $key ] = $spec['default'];
				}
				continue;
			}

			$value = self::coerce( $args[ $key ], $spec );

			$problem = self::check( $key, $value, $spec );
			if ( $problem ) {
				$errors[] = $problem;
				continue;
			}

			$clean[ $key ] = $value;
		}

		// Unknown keys are dropped rather than rejected. Models sprinkle extras.
		if ( $errors ) {
			return new \WP_Error( 'kaiv_invalid_args', implode( ' ', $errors ), array( 'errors' => $errors ) );
		}

		return $clean;
	}

	/**
	 * Nudge a value toward the declared type.
	 *
	 * @param mixed $value Raw value.
	 * @param array $spec  Property schema.
	 * @return mixed
	 */
	private static function coerce( $value, array $spec ) {
		$type = isset( $spec['type'] ) ? $spec['type'] : null;

		switch ( $type ) {
			case 'integer':
				if ( is_numeric( $value ) ) {
					return (int) $value;
				}
				break;

			case 'number':
				if ( is_numeric( $value ) ) {
					return (float) $value;
				}
				break;

			case 'boolean':
				if ( is_string( $value ) || is_numeric( $value ) ) {
					return kaiv_bool( $value );
				}
				break;

			case 'array':
				if ( is_string( $value ) ) {
					$trimmed = trim( $value );
					if ( '' === $trimmed ) {
						return array();
					}
					// Accept a JSON array or a comma separated list.
					$decoded = json_decode( $trimmed, true );
					if ( is_array( $decoded ) ) {
						return $decoded;
					}
					return array_values( array_filter( array_map( 'trim', explode( ',', $trimmed ) ), 'strlen' ) );
				}
				if ( ! is_array( $value ) ) {
					return array( $value );
				}
				break;

			case 'object':
				if ( is_string( $value ) ) {
					$decoded = json_decode( $value, true );
					if ( is_array( $decoded ) ) {
						return $decoded;
					}
				}
				if ( is_object( $value ) ) {
					return (array) $value;
				}
				break;

			case 'string':
				if ( is_numeric( $value ) || is_bool( $value ) ) {
					return (string) $value;
				}
				break;
		}

		return $value;
	}

	/**
	 * @param string $key   Property name.
	 * @param mixed  $value Coerced value.
	 * @param array  $spec  Property schema.
	 * @return string Empty string when valid.
	 */
	private static function check( $key, $value, array $spec ) {
		$type = isset( $spec['type'] ) ? $spec['type'] : null;

		$type_ok = true;
		switch ( $type ) {
			case 'string':
				$type_ok = is_string( $value );
				break;
			case 'integer':
				$type_ok = is_int( $value );
				break;
			case 'number':
				$type_ok = is_int( $value ) || is_float( $value );
				break;
			case 'boolean':
				$type_ok = is_bool( $value );
				break;
			case 'array':
				$type_ok = is_array( $value ) && ( array() === $value || array_keys( $value ) === range( 0, count( $value ) - 1 ) );
				break;
			case 'object':
				$type_ok = is_array( $value ) || is_object( $value );
				break;
		}

		if ( ! $type_ok ) {
			return sprintf( 'Argument "%s" should be of type %s, got %s.', $key, $type, gettype( $value ) );
		}

		if ( isset( $spec['enum'] ) && ! in_array( $value, (array) $spec['enum'], true ) ) {
			return sprintf( 'Argument "%s" must be one of: %s.', $key, implode( ', ', (array) $spec['enum'] ) );
		}

		if ( isset( $spec['minimum'] ) && is_numeric( $value ) && $value < $spec['minimum'] ) {
			return sprintf( 'Argument "%s" must be at least %s.', $key, $spec['minimum'] );
		}

		if ( isset( $spec['maximum'] ) && is_numeric( $value ) && $value > $spec['maximum'] ) {
			return sprintf( 'Argument "%s" must be at most %s.', $key, $spec['maximum'] );
		}

		if ( isset( $spec['minLength'] ) && is_string( $value ) && strlen( $value ) < $spec['minLength'] ) {
			return sprintf( 'Argument "%s" is too short.', $key );
		}

		if ( isset( $spec['maxLength'] ) && is_string( $value ) && strlen( $value ) > $spec['maxLength'] ) {
			return sprintf( 'Argument "%s" is too long (max %d characters).', $key, $spec['maxLength'] );
		}

		if ( isset( $spec['pattern'] ) && is_string( $value ) && ! preg_match( '#' . $spec['pattern'] . '#', $value ) ) {
			return sprintf( 'Argument "%s" is not in the expected format.', $key );
		}

		return '';
	}
}
