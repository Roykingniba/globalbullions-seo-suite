<?php
/**
 * Normalises whatever a tool callback returns into MCP content blocks.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Mcp;

defined( 'ABSPATH' ) || exit;

class ToolResult {

	/** @var array[] */
	private $content = array();

	/** @var array|null */
	private $structured = null;

	/** @var bool */
	private $is_error = false;

	/**
	 * @param string $text Plain text block.
	 * @return ToolResult
	 */
	public static function text( $text ) {
		$result            = new self();
		$result->content[] = array( 'type' => 'text', 'text' => (string) $text );
		return $result;
	}

	/**
	 * Structured payload. Sent both as structuredContent and as pretty JSON text,
	 * because not every client reads structuredContent yet.
	 *
	 * @param mixed  $data    Serialisable data.
	 * @param string $summary Optional one-line summary placed above the JSON.
	 * @return ToolResult
	 */
	public static function json( $data, $summary = '' ) {
		$result = new self();

		$is_map = is_array( $data ) && $data && array_keys( $data ) !== range( 0, count( $data ) - 1 );

		// structuredContent is defined as an object. A PHP list (or an empty
		// array) encodes as a JSON array, which clients reject outright.
		$result->structured = $is_map ? $data : array( 'value' => $data );

		$encoded = wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		$text    = '' !== $summary ? $summary . "\n\n" . $encoded : $encoded;

		$result->content[] = array( 'type' => 'text', 'text' => $text );

		return $result;
	}

	/**
	 * A tool-level error. Reported through isError so the model can recover,
	 * rather than as a protocol error which would abort the call.
	 *
	 * @param string $message Message for the model.
	 * @param array  $detail  Extra context.
	 * @return ToolResult
	 */
	public static function error( $message, array $detail = array() ) {
		$result           = new self();
		$result->is_error = true;

		$text = (string) $message;
		if ( $detail ) {
			$text .= "\n\n" . wp_json_encode( $detail, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		}

		$result->content[] = array( 'type' => 'text', 'text' => $text );
		$result->structured = array_merge( array( 'error' => (string) $message ), $detail );

		return $result;
	}

	/**
	 * @param string $data      Base64 image data.
	 * @param string $mime_type MIME type.
	 * @return ToolResult
	 */
	public static function image( $data, $mime_type ) {
		$result            = new self();
		$result->content[] = array( 'type' => 'image', 'data' => $data, 'mimeType' => $mime_type );
		return $result;
	}

	/**
	 * @param string $text Additional text block.
	 * @return ToolResult
	 */
	public function add_text( $text ) {
		$this->content[] = array( 'type' => 'text', 'text' => (string) $text );
		return $this;
	}

	/**
	 * @return bool
	 */
	public function is_error() {
		return $this->is_error;
	}

	/**
	 * @return array Wire format for tools/call.
	 */
	public function to_array() {
		$payload = array(
			'content' => $this->content ? $this->content : array( array( 'type' => 'text', 'text' => '' ) ),
			'isError' => $this->is_error,
		);

		if ( null !== $this->structured ) {
			$payload['structuredContent'] = $this->structured;
		}

		return $payload;
	}
}
