<?php
/**
 * The HTTP surface: a Streamable-HTTP MCP endpoint served by WordPress itself.
 *
 *   POST   /wp-json/kai-vibe/v1/mcp   JSON-RPC messages
 *   DELETE /wp-json/kai-vibe/v1/mcp   end session
 *   GET    /wp-json/kai-vibe/v1/info  unauthenticated reachability check
 *
 * @package KaiVibe
 */

namespace KaiVibe\Mcp;

use KaiVibe\Auth\Authenticator;
use KaiVibe\Auth\OAuth;

defined( 'ABSPATH' ) || exit;

class RestController {

	const ROUTE = '/mcp';

	/** @var array|null Body we will emit ourselves, bypassing the REST serializer. */
	private static $payload = null;

	/** @var bool */
	private static $emit_empty = false;

	public function register_routes() {
		register_rest_route(
			KAIV_REST_NS,
			self::ROUTE,
			array(
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'handle_post' ),
					'permission_callback' => array( $this, 'authorise' ),
				),
				array(
					'methods'             => 'GET',
					'callback'            => array( $this, 'handle_get' ),
					'permission_callback' => array( $this, 'authorise' ),
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( $this, 'handle_delete' ),
					'permission_callback' => array( $this, 'authorise' ),
				),
			)
		);

		register_rest_route(
			KAIV_REST_NS,
			'/info',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'handle_info' ),
				'permission_callback' => '__return_true',
			)
		);

		add_filter( 'rest_pre_serve_request', array( $this, 'serve_raw' ), 10, 4 );

		// A bare 401 tells a client nothing. This is the signpost that turns
		// "paste the address and press Connect" into a working handshake: it
		// names the document describing how to get authorised here.
		add_filter( 'rest_post_dispatch', array( $this, 'add_auth_challenge' ), 10, 3 );
	}

	/**
	 * Attach the RFC 9728 challenge to an unauthenticated MCP response.
	 *
	 * @param \WP_REST_Response $response Response.
	 * @param \WP_REST_Server   $server   Server.
	 * @param \WP_REST_Request  $request  Request.
	 * @return \WP_REST_Response
	 */
	public function add_auth_challenge( $response, $server, $request ) {
		if ( ! $this->is_mcp_route( $request ) || ! $response instanceof \WP_REST_Response ) {
			return $response;
		}

		if ( 401 !== $response->get_status() || ! OAuth::enabled() ) {
			return $response;
		}

		$response->header(
			'WWW-Authenticate',
			sprintf(
				'Bearer resource_metadata="%s"',
				OAuth::resource_metadata_url()
			)
		);

		return $response;
	}

	/**
	 * @param \WP_REST_Request $request Request.
	 * @return bool
	 */
	private function is_mcp_route( $request ) {
		if ( ! $request instanceof \WP_REST_Request ) {
			return false;
		}

		return 0 === strpos(
			ltrim( (string) $request->get_route(), '/' ),
			trim( KAIV_REST_NS, '/' ) . self::ROUTE
		);
	}

	/**
	 * Gate every MCP request on a valid token.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return true|\WP_Error
	 */
	public function authorise( $request ) {
		if ( ! kaiv_setting( 'enabled', true ) ) {
			return new \WP_Error(
				'kaiv_disabled',
				__( 'The MCP endpoint is switched off for this site.', 'kai-vibe' ),
				array( 'status' => 503 )
			);
		}

		$auth = Authenticator::instance();

		if ( ! $auth->token() ) {
			return new \WP_Error(
				'kaiv_unauthorised',
				__( 'A KAI Vibe bearer token is required. Generate one under KAI Vibe → Tokens in wp-admin.', 'kai-vibe' ),
				array( 'status' => 401 )
			);
		}

		return true;
	}

	/**
	 * Main JSON-RPC entry point.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public function handle_post( $request ) {
		$body    = $request->get_body();
		$decoded = json_decode( $body, true );
		$server  = new Server();

		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) ) {
			return $this->respond(
				$server->error( null, Server::PARSE_ERROR, __( 'Request body is not valid JSON.', 'kai-vibe' ) ),
				400
			);
		}

		// A bare object is one message; a list is a batch.
		$is_batch = array_keys( $decoded ) === range( 0, count( $decoded ) - 1 ) && ! empty( $decoded );
		$messages = $is_batch ? $decoded : array( $decoded );

		$responses = array();

		foreach ( $messages as $message ) {
			if ( ! is_array( $message ) ) {
				$responses[] = $server->error( null, Server::INVALID_REQUEST, __( 'Malformed message in batch.', 'kai-vibe' ) );
				continue;
			}

			$response = $server->handle( $message );

			if ( null !== $response ) {
				$responses[] = $response;
			}
		}

		// Nothing but notifications: acknowledge with an empty 202.
		if ( empty( $responses ) ) {
			return $this->respond( null, 202 );
		}

		return $this->respond( $is_batch ? $responses : $responses[0], 200 );
	}

	/**
	 * We answer synchronously in JSON, so there is no server-initiated stream
	 * to open. Say so plainly rather than hanging an SSE connection open.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public function handle_get( $request ) {
		$response = new \WP_REST_Response( null, 405 );
		$response->header( 'Allow', 'POST, DELETE' );

		self::$payload    = null;
		self::$emit_empty = true;

		return $response;
	}

	/**
	 * Session teardown. This server is stateless, so there is nothing to drop.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public function handle_delete( $request ) {
		self::$payload    = null;
		self::$emit_empty = true;

		return new \WP_REST_Response( null, 204 );
	}

	/**
	 * Unauthenticated: confirms the plugin is installed and reachable, and
	 * hands back the endpoint URL. Deliberately reveals nothing else.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public function handle_info( $request ) {
		return new \WP_REST_Response(
			array(
				'name'            => 'kai-vibe',
				// The exact plugin version is only useful to somebody deciding
				// which exploit to try, so it is shown to administrators only.
				'version'         => current_user_can( 'manage_options' ) ? KAIV_VERSION : null,
				'protocolVersion' => Server::PROTOCOL_VERSION,
				'transport'       => 'streamable-http',
				'endpoint'        => rest_url( KAIV_REST_NS . self::ROUTE ),
				'authentication'  => OAuth::enabled() ? 'oauth2, bearer' : 'bearer',
				'enabled'         => (bool) kaiv_setting( 'enabled', true ),
			),
			200
		);
	}

	/**
	 * @param array|null $payload Body to send.
	 * @param int        $status  HTTP status.
	 * @return \WP_REST_Response
	 */
	private function respond( $payload, $status ) {
		self::$payload    = $payload;
		self::$emit_empty = ( null === $payload );

		$response = new \WP_REST_Response( $payload, $status );
		$response->header( 'Content-Type', 'application/json; charset=' . get_option( 'blog_charset' ) );
		$response->header( 'Cache-Control', 'no-store' );
		$response->header( 'MCP-Protocol-Version', Server::PROTOCOL_VERSION );

		return $response;
	}

	/**
	 * Emit the body ourselves so JSON-RPC responses go out verbatim and 202/204
	 * replies carry a genuinely empty body.
	 *
	 * @param bool              $served  Whether the request was already served.
	 * @param \WP_HTTP_Response $result  Response.
	 * @param \WP_REST_Request  $request Request.
	 * @param \WP_REST_Server   $server  REST server.
	 * @return bool
	 */
	public function serve_raw( $served, $result, $request, $server ) {
		if ( $served || ! $this->is_mcp_route( $request ) ) {
			return $served;
		}

		if ( self::$emit_empty && null === self::$payload ) {
			return true;
		}

		if ( null === self::$payload ) {
			return $served;
		}

		echo wp_json_encode( self::$payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ); // phpcs:ignore WordPress.Security.EscapeOutput

		return true;
	}
}
