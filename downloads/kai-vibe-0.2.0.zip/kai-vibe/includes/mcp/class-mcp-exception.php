<?php
/**
 * Exception carrying a JSON-RPC error code.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Mcp;

defined( 'ABSPATH' ) || exit;

class McpException extends \Exception {

	/** @var mixed */
	private $data;

	/**
	 * @param string $message Error message.
	 * @param int    $code    JSON-RPC error code.
	 * @param mixed  $data    Optional structured detail.
	 */
	public function __construct( $message, $code = Server::INTERNAL_ERROR, $data = null ) {
		parent::__construct( $message, $code );
		$this->data = $data;
	}

	/**
	 * @return mixed
	 */
	public function data() {
		return $this->data;
	}
}
