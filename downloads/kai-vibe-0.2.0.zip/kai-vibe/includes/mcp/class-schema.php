<?php
/**
 * Tiny JSON Schema builders so tool definitions stay readable.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Mcp;

defined( 'ABSPATH' ) || exit;

class Schema {

	/**
	 * @param array    $properties Property name => schema.
	 * @param string[] $required   Required property names.
	 * @return array
	 */
	public static function object( array $properties = array(), array $required = array() ) {
		$schema = array(
			'type'                 => 'object',
			'properties'           => (object) $properties,
			'additionalProperties' => false,
		);

		if ( $required ) {
			$schema['required'] = array_values( $required );
		}

		return $schema;
	}

	/**
	 * @param string $description Human description shown to the model.
	 * @param array  $extra       Extra JSON Schema keywords.
	 * @return array
	 */
	public static function string( $description, array $extra = array() ) {
		return array_merge( array( 'type' => 'string', 'description' => $description ), $extra );
	}

	public static function integer( $description, array $extra = array() ) {
		return array_merge( array( 'type' => 'integer', 'description' => $description ), $extra );
	}

	public static function number( $description, array $extra = array() ) {
		return array_merge( array( 'type' => 'number', 'description' => $description ), $extra );
	}

	public static function boolean( $description, array $extra = array() ) {
		return array_merge( array( 'type' => 'boolean', 'description' => $description ), $extra );
	}

	/**
	 * @param string $description Description.
	 * @param array  $items       Schema for each item.
	 * @param array  $extra       Extra keywords.
	 * @return array
	 */
	public static function arr( $description, array $items = array( 'type' => 'string' ), array $extra = array() ) {
		return array_merge( array( 'type' => 'array', 'description' => $description, 'items' => $items ), $extra );
	}

	/**
	 * @param string   $description Description.
	 * @param string[] $values      Allowed values.
	 * @param array    $extra       Extra keywords.
	 * @return array
	 */
	public static function enum( $description, array $values, array $extra = array() ) {
		return array_merge( array( 'type' => 'string', 'description' => $description, 'enum' => array_values( $values ) ), $extra );
	}

	/**
	 * A free-form object, e.g. a meta bag whose keys are not known up front.
	 *
	 * @param string $description Description.
	 * @return array
	 */
	public static function map( $description ) {
		return array(
			'type'                 => 'object',
			'description'          => $description,
			'additionalProperties' => true,
		);
	}
}
