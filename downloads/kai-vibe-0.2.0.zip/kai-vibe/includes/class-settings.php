<?php
/**
 * Typed access to the kaiv_settings option.
 *
 * @package KaiVibe
 */

namespace KaiVibe;

defined( 'ABSPATH' ) || exit;

class Settings {

	const OPTION = 'kaiv_settings';

	/** @var array|null */
	private static $cache = null;

	/**
	 * @return array
	 */
	public static function defaults() {
		return array(
			// Master switch. When false the MCP endpoint 503s.
			'enabled'              => true,

			// One-click connection. When false, assistants can still connect
			// with a token created by hand, but the OAuth handshake is refused.
			'oauth_enabled'        => true,

			// Extra roots the filesystem tools may touch, beyond wp-content.
			'fs_extra_roots'       => array(),
			'fs_max_bytes'         => 2 * MB_IN_BYTES,
			'fs_allow_php'         => true,

			// WP-CLI.
			'cli_enabled'          => false,
			'cli_binary'           => 'wp',
			'cli_timeout'          => 120,
			'cli_denylist'         => array( 'db drop', 'db reset', 'site empty', 'core download', 'eval-file', 'server', 'shell' ),

			// Database.
			'db_read_enabled'      => true,
			'db_write_enabled'     => false,
			'db_max_rows'          => 500,

			// Approval gate for destructive operations.
			'approval_required'    => true,
			'approval_ttl'         => 15 * MINUTE_IN_SECONDS,

			// Rate limiting, per token.
			'rate_limit'           => 240,
			'rate_window'          => MINUTE_IN_SECONDS,

			// Audit log retention in days. 0 keeps forever.
			'audit_retention_days' => 30,
			'audit_payloads'       => true,

			// Change journal retention in days.
			'journal_retention_days' => 14,

			// Optional IP allowlist (CIDR or plain). Empty = any.
			'ip_allowlist'         => array(),
		);
	}

	/**
	 * @return array
	 */
	public static function all() {
		if ( null === self::$cache ) {
			$stored      = get_option( self::OPTION, array() );
			self::$cache = wp_parse_args( is_array( $stored ) ? $stored : array(), self::defaults() );
		}
		return self::$cache;
	}

	/**
	 * @param string $key     Setting key.
	 * @param mixed  $default Fallback.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$all = self::all();

		$value = array_key_exists( $key, $all ) ? $all[ $key ] : $default;

		/**
		 * Filter an individual setting. Lets wp-config.php style overrides win.
		 *
		 * @param mixed  $value Setting value.
		 * @param string $key   Setting key.
		 */
		return apply_filters( "kaiv_setting_{$key}", $value, $key );
	}

	/**
	 * @param array $values Partial settings to merge in.
	 */
	public static function update( array $values ) {
		// Merge into what is stored, not into defaults + stored. Otherwise the
		// first save bakes every current default into the database and later
		// changes to defaults() never reach sites that have saved settings.
		$stored = get_option( self::OPTION, array() );
		$stored = is_array( $stored ) ? $stored : array();

		update_option( self::OPTION, array_merge( $stored, $values ) );
		self::$cache = null;
	}
}
