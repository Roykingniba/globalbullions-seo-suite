<?php
/**
 * Activation, table creation and defaults.
 *
 * @package KaiVibe
 */

namespace KaiVibe;

defined( 'ABSPATH' ) || exit;

class Installer {

	public static function activate() {
		self::install_tables();

		if ( false === get_option( 'kaiv_settings' ) ) {
			add_option( 'kaiv_settings', Settings::defaults() );
		}
		if ( false === get_option( 'kaiv_install_time' ) ) {
			add_option( 'kaiv_install_time', time() );
		}

		update_option( 'kaiv_db_version', KAIV_VERSION );

		if ( ! wp_next_scheduled( 'kaiv_cleanup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'kaiv_cleanup' );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'kaiv_cleanup' );
	}

	/**
	 * Audit log + change journal tables.
	 *
	 * The journal stores the previous state of anything the agent overwrites,
	 * which is what makes the undo_change tool possible.
	 */
	public static function install_tables() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$audit   = $wpdb->prefix . 'kaiv_audit_log';
		$journal = $wpdb->prefix . 'kaiv_journal';

		dbDelta(
			"CREATE TABLE {$audit} (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				created_at DATETIME NOT NULL,
				token_id VARCHAR(32) NOT NULL DEFAULT '',
				user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
				action VARCHAR(120) NOT NULL DEFAULT '',
				status VARCHAR(20) NOT NULL DEFAULT 'ok',
				duration_ms INT(10) UNSIGNED NOT NULL DEFAULT 0,
				ip VARCHAR(100) NOT NULL DEFAULT '',
				context LONGTEXT NULL,
				PRIMARY KEY (id),
				KEY created_at (created_at),
				KEY action (action),
				KEY token_id (token_id)
			) {$charset};"
		);

		dbDelta(
			"CREATE TABLE {$journal} (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				created_at DATETIME NOT NULL,
				token_id VARCHAR(32) NOT NULL DEFAULT '',
				kind VARCHAR(32) NOT NULL DEFAULT '',
				target VARCHAR(255) NOT NULL DEFAULT '',
				label VARCHAR(255) NOT NULL DEFAULT '',
				undone TINYINT(1) NOT NULL DEFAULT 0,
				payload LONGTEXT NULL,
				PRIMARY KEY (id),
				KEY created_at (created_at),
				KEY kind_target (kind, target(150))
			) {$charset};"
		);
	}
}
