<?php
/**
 * The options table.
 *
 * Two rules run through this file: secrets are never read, and the handful of
 * options that would lock the owner out of their own site are never written.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Schema;
use KaiVibe\Mcp\ToolRegistry;
use KaiVibe\Security\Journal;
use KaiVibe\Security\ProtectedData;

defined( 'ABSPATH' ) || exit;

class OptionTools extends ToolPack {

	public function register( ToolRegistry $registry ) {

		$registry->add(
			$this->tool( 'get_option' )
				->describe( 'Read a single site option. Options whose names look like credentials are refused.', 'Get option' )
				->scope( 'options:read' )
				->cap( 'manage_options' )
				->read_only()
				->input(
					Schema::object(
						array(
							'option' => Schema::string( 'Option name, e.g. blogname, permalink_structure, posts_per_page.' ),
						),
						array( 'option' )
					)
				)
				->run( array( $this, 'get_option' ) )
		);

		$registry->add(
			$this->tool( 'list_options' )
				->describe( 'Browse the options table by name prefix, with sizes. Useful for finding where a plugin keeps its settings — search for the plugin slug. Values over 2 KB are summarised; read those individually with get_option.', 'List options' )
				->scope( 'options:read' )
				->cap( 'manage_options' )
				->read_only()
				->input(
					Schema::object(
						array(
							'search'      => Schema::string( 'Match option names containing this text.' ),
							'autoload'    => Schema::enum( 'Filter by autoload flag.', array( 'any', 'yes', 'no' ), array( 'default' => 'any' ) ),
							'with_values' => Schema::boolean( 'Include values as well as names and sizes.', array( 'default' => false ) ),
							'per_page'    => Schema::integer( 'Results per page.', array( 'default' => 50, 'minimum' => 1, 'maximum' => 200 ) ),
							'page'        => Schema::integer( 'Page number.', array( 'default' => 1, 'minimum' => 1 ) ),
						)
					)
				)
				->run( array( $this, 'list_options' ) )
		);

		$registry->add(
			$this->tool( 'set_option' )
				->describe(
					'Write a site option. The previous value is journalled so undo_change can restore it. A small set of options is locked — site URL, admin email, registration settings and the active plugin list — because getting those wrong locks the owner out. Change those from wp-admin.',
					'Set option'
				)
				->scope( 'options:write' )
				->cap( 'manage_options' )
				->gated()
				->precheck( array( $this, 'check_writable' ) )
				->input(
					Schema::object(
						array(
							'option' => Schema::string( 'Option name.' ),
							'value'  => Schema::string( 'New value. JSON objects and arrays are decoded before saving.' ),
						),
						array( 'option', 'value' )
					)
				)
				->run( array( $this, 'set_option' ) )
		);

		$registry->add(
			$this->tool( 'delete_option' )
				->describe( 'Delete a site option. Journalled, and subject to the same locked list as set_option.', 'Delete option' )
				->scope( 'options:write' )
				->cap( 'manage_options' )
				->destructive( true )
				->gated()
				->precheck( array( $this, 'check_writable' ) )
				->input(
					Schema::object(
						array(
							'option' => Schema::string( 'Option name.' ),
						),
						array( 'option' )
					)
				)
				->run( array( $this, 'delete_option' ) )
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function get_option( array $args ) {
		$option = $args['option'];

		if ( ProtectedData::is_protected_option( $option ) ) {
			return $this->fail(
				__( 'That option holds credentials and is never exposed over MCP.', 'kai-vibe' ),
				array( 'option' => $option )
			);
		}

		$exists = null !== get_option( $option, null );
		$value  = get_option( $option );

		return array(
			'option'   => $option,
			'exists'   => $exists,
			'value'    => $value,
			'type'     => gettype( $value ),
			'autoload' => $this->autoload_flag( $option ),
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function list_options( array $args ) {
		global $wpdb;

		$per_page = isset( $args['per_page'] ) ? (int) $args['per_page'] : 50;
		$page     = isset( $args['page'] ) ? (int) $args['page'] : 1;
		$offset   = ( $page - 1 ) * $per_page;

		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['search'] ) ) {
			$where[]  = 'option_name LIKE %s';
			$params[] = '%' . $wpdb->esc_like( $args['search'] ) . '%';
		}

		if ( ! empty( $args['autoload'] ) && 'any' !== $args['autoload'] ) {
			// WordPress 6.6 replaced yes/no with on/off/auto/auto-on/auto-off,
			// and older rows keep the legacy values, so match both vocabularies.
			$values = 'yes' === $args['autoload']
				? array( 'yes', 'on', 'auto', 'auto-on' )
				: array( 'no', 'off', 'auto-off' );

			$where[]  = 'autoload IN (' . implode( ', ', array_fill( 0, count( $values ), '%s' ) ) . ')';
			$params   = array_merge( $params, $values );
		}

		$clause = implode( ' AND ', $where );

		$total_sql = "SELECT COUNT(*) FROM {$wpdb->options} WHERE {$clause}";
		$total     = (int) ( $params
			? $wpdb->get_var( $wpdb->prepare( $total_sql, $params ) ) // phpcs:ignore WordPress.DB
			: $wpdb->get_var( $total_sql ) ); // phpcs:ignore WordPress.DB

		$rows_sql = "SELECT option_name, autoload, LENGTH(option_value) AS bytes FROM {$wpdb->options} WHERE {$clause} ORDER BY LENGTH(option_value) DESC LIMIT %d OFFSET %d";
		$rows     = $wpdb->get_results( $wpdb->prepare( $rows_sql, array_merge( $params, array( $per_page, $offset ) ) ), ARRAY_A ); // phpcs:ignore WordPress.DB

		$items = array();

		foreach ( (array) $rows as $row ) {
			$item = array(
				'option'   => $row['option_name'],
				'bytes'    => (int) $row['bytes'],
				'autoload' => $row['autoload'],
			);

			if ( ProtectedData::is_protected_option( $row['option_name'] ) ) {
				$item['value'] = '[protected]';
			} elseif ( ! empty( $args['with_values'] ) ) {
				$item['value'] = (int) $row['bytes'] > 2048
					? sprintf( '[%s — read with get_option]', size_format( (int) $row['bytes'] ) )
					: get_option( $row['option_name'] );
			}

			$items[] = $item;
		}

		return $this->paged(
			$items,
			$total,
			$page,
			$per_page,
			array( 'note' => 'Sorted by size, largest first — a bloated autoloaded option is a common cause of a slow site.' )
		);
	}

	/**
	 * Locked options can never be written, so refuse before the approval gate
	 * rather than asking the owner to approve something that would fail anyway.
	 *
	 * @param array $args Arguments.
	 * @return \KaiVibe\Mcp\ToolResult|null
	 */
	public function check_writable( array $args ) {
		$option = isset( $args['option'] ) ? $args['option'] : '';

		if ( ! ProtectedData::is_locked_option( $option ) ) {
			return null;
		}

		return $this->fail(
			sprintf(
				/* translators: %s: option name. */
				__( '"%s" is locked. Changing it through an agent risks locking the owner out of the site, so it has to be done in wp-admin. Do not ask for approval — this cannot be granted.', 'kai-vibe' ),
				$option
			),
			array( 'option' => $option, 'locked' => true )
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function set_option( array $args ) {
		$option = $args['option'];

		$locked = $this->check_writable( $args );

		if ( $locked ) {
			return $locked;
		}

		$before = get_option( $option, null );

		Journal::record(
			Journal::KIND_OPTION,
			$option,
			sprintf( 'Set option %s', $option ),
			array( 'before' => $before )
		);

		$value = $args['value'];

		if ( is_string( $value ) ) {
			$trimmed = trim( $value );

			if ( '' !== $trimmed && ( '{' === $trimmed[0] || '[' === $trimmed[0] ) ) {
				$decoded = json_decode( $trimmed, true );

				if ( JSON_ERROR_NONE === json_last_error() ) {
					$value = $decoded;
				}
			}
		}

		update_option( $option, $value );

		return array(
			'updated'  => true,
			'option'   => $option,
			'existed'  => null !== $before,
			'note'     => 'Previous value journalled; undo_change can restore it.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function delete_option( array $args ) {
		$option = $args['option'];

		$locked = $this->check_writable( $args );

		if ( $locked ) {
			return $locked;
		}

		$before = get_option( $option, null );

		if ( null === $before ) {
			return $this->fail( __( 'That option does not exist.', 'kai-vibe' ) );
		}

		Journal::record(
			Journal::KIND_OPTION,
			$option,
			sprintf( 'Deleted option %s', $option ),
			array( 'before' => $before )
		);

		delete_option( $option );

		return array( 'deleted' => true, 'option' => $option );
	}

	/**
	 * @param string $option Option name.
	 * @return string
	 */
	private function autoload_flag( $option ) {
		global $wpdb;

		$flag = $wpdb->get_var( $wpdb->prepare( "SELECT autoload FROM {$wpdb->options} WHERE option_name = %s", $option ) ); // phpcs:ignore WordPress.DB

		return $flag ? $flag : 'unknown';
	}
}
