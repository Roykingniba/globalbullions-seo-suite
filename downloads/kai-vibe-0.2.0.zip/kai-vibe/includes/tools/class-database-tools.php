<?php
/**
 * Raw SQL, as a last resort.
 *
 * Reads are capped and redacted. Writes are off by default, gated when on, and
 * refused entirely against the user tables. The tool description tells the model
 * to exhaust the specific tools first, because SQL skips every hook WordPress
 * relies on to keep caches and derived data correct.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Schema;
use KaiVibe\Mcp\ToolRegistry;
use KaiVibe\Security\ProtectedData;

defined( 'ABSPATH' ) || exit;

class DatabaseTools extends ToolPack {

	/** Statements treated as reads. */
	const READ_VERBS = array( 'select', 'show', 'describe', 'desc', 'explain' );

	/** Statements that are never allowed, whatever the scopes say. */
	const FORBIDDEN_VERBS = array( 'drop', 'truncate', 'grant', 'revoke', 'shutdown', 'load', 'lock', 'unlock' );

	public function register( ToolRegistry $registry ) {

		$registry->add(
			$this->tool( 'db_tables' )
				->describe( 'List database tables with row counts and sizes. Use this to find where a plugin keeps its data before reaching for a query.', 'Database tables' )
				->scope( 'db:read' )
				->cap( 'manage_options' )
				->read_only()
				->available_when( array( $this, 'read_enabled' ) )
				->input(
					Schema::object(
						array(
							'search' => Schema::string( 'Only tables whose name contains this text.' ),
						)
					)
				)
				->run( array( $this, 'db_tables' ) )
		);

		$registry->add(
			$this->tool( 'db_describe' )
				->describe( 'Show a table\'s columns, types, keys and indexes. Always do this before writing a query against an unfamiliar table.', 'Describe table' )
				->scope( 'db:read' )
				->cap( 'manage_options' )
				->read_only()
				->available_when( array( $this, 'read_enabled' ) )
				->input(
					Schema::object(
						array(
							'table' => Schema::string( 'Table name, with or without the site prefix.' ),
						),
						array( 'table' )
					)
				)
				->run( array( $this, 'db_describe' ) )
		);

		$registry->add(
			$this->tool( 'db_query' )
				->describe(
					'Run a SQL query. Use this only when no specific tool reaches the data — raw SQL bypasses the hooks that invalidate caches and update derived values, so a plugin\'s own data can end up inconsistent. Reads are row-capped and have credential columns redacted. Writes must be enabled by the site owner and are always gated behind an approval.',
					'SQL query'
				)
				->scope( 'db:read' )
				->cap( 'manage_options' )
				->available_when( array( $this, 'read_enabled' ) )
				->input(
					Schema::object(
						array(
							'sql'   => Schema::string( 'A single SQL statement. Use {prefix} where the table prefix belongs, e.g. SELECT * FROM {prefix}posts LIMIT 5.' ),
							'limit' => Schema::integer( 'Row cap for SELECT results.', array( 'default' => 100, 'minimum' => 1, 'maximum' => 1000 ) ),
						),
						array( 'sql' )
					)
				)
				->run( array( $this, 'db_query' ) )
		);
	}

	/**
	 * @return bool
	 */
	public function read_enabled() {
		return (bool) kaiv_setting( 'db_read_enabled', true );
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function db_tables( array $args ) {
		global $wpdb;

		$rows = $wpdb->get_results( 'SHOW TABLE STATUS', ARRAY_A ); // phpcs:ignore WordPress.DB

		$search = isset( $args['search'] ) ? strtolower( $args['search'] ) : '';
		$tables = array();

		foreach ( (array) $rows as $row ) {
			$name = $row['Name'];

			if ( '' !== $search && false === strpos( strtolower( $name ), $search ) ) {
				continue;
			}

			$tables[] = array(
				'table'   => $name,
				'rows'    => isset( $row['Rows'] ) ? (int) $row['Rows'] : null,
				'size'    => size_format( (int) $row['Data_length'] + (int) $row['Index_length'] ),
				'engine'  => isset( $row['Engine'] ) ? $row['Engine'] : null,
				'is_core' => in_array( $name, $wpdb->tables( 'all' ), true ),
			);
		}

		return array(
			'prefix' => $wpdb->prefix,
			'tables' => $tables,
			'note'   => 'Use {prefix} in db_query rather than hard-coding the prefix.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function db_describe( array $args ) {
		global $wpdb;

		$table = $this->normalise_table( $args['table'] );

		if ( ! $this->table_exists( $table ) ) {
			return $this->fail(
				sprintf(
					/* translators: %s: table name. */
					__( 'There is no table called "%s". Call db_tables to see what exists.', 'kai-vibe' ),
					$table
				)
			);
		}

		$columns = $wpdb->get_results( "DESCRIBE `{$table}`", ARRAY_A ); // phpcs:ignore WordPress.DB
		$indexes = $wpdb->get_results( "SHOW INDEX FROM `{$table}`", ARRAY_A ); // phpcs:ignore WordPress.DB

		$keys = array();

		foreach ( (array) $indexes as $index ) {
			$keys[ $index['Key_name'] ]['columns'][] = $index['Column_name'];
			$keys[ $index['Key_name'] ]['unique']    = ! (int) $index['Non_unique'];
		}

		return array(
			'table'   => $table,
			'columns' => $columns,
			'indexes' => $keys,
			'rows'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}`" ), // phpcs:ignore WordPress.DB
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function db_query( array $args ) {
		global $wpdb;

		$sql = trim( (string) $args['sql'] );
		$sql = str_replace( '{prefix}', $wpdb->prefix, $sql );

		$verb = $this->verb( $sql );

		if ( '' === $verb ) {
			return $this->fail( __( 'Could not work out what that statement does. Send one plain SQL statement.', 'kai-vibe' ) );
		}

		if ( in_array( $verb, self::FORBIDDEN_VERBS, true ) ) {
			return $this->fail(
				sprintf(
					/* translators: %s: SQL keyword. */
					__( '%s statements are never allowed through this tool.', 'kai-vibe' ),
					strtoupper( $verb )
				)
			);
		}

		if ( $this->has_multiple_statements( $sql ) ) {
			return $this->fail( __( 'Send one statement at a time. Stacked statements are refused.', 'kai-vibe' ) );
		}

		// MySQL treats a comment as whitespace, so both checks below have to run
		// against a normalised copy. Against raw SQL, "into/*x*/outfile" and
		// "WITH a AS (...) /*x*/ INSERT" both slip past.
		$probe = $this->normalise_for_checks( $sql );

		// SELECT ... INTO OUTFILE leads with a read verb but writes a file to
		// disk as the MySQL user, skipping every write gate below.
		if ( preg_match( '/\binto\s+(outfile|dumpfile)\b/i', $probe ) ) {
			return $this->fail( __( 'INTO OUTFILE and INTO DUMPFILE write files on the server and are never allowed through this tool.', 'kai-vibe' ) );
		}

		$is_read = in_array( $verb, self::READ_VERBS, true );

		// A CTE is only a read when nothing inside it writes. Anything
		// ambiguous takes the write path, which is where the gates are.
		if ( 'with' === $verb ) {
			$is_read = ! preg_match( '/\b(insert|update|delete|replace|create|alter|drop|rename)\b/i', $probe );
		}

		if ( $is_read ) {
			return $this->run_read( $sql, isset( $args['limit'] ) ? (int) $args['limit'] : 100 );
		}

		return $this->run_write( $sql, $verb );
	}

	/**
	 * @param string $sql   Statement.
	 * @param int    $limit Row cap.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	private function run_read( $sql, $limit ) {
		global $wpdb;

		$max = min( $limit, (int) kaiv_setting( 'db_max_rows', 500 ) );

		// Add a LIMIT when the query does not already constrain itself.
		if ( 'select' === $this->verb( $sql ) && ! preg_match( '/\blimit\s+\d+/i', $sql ) ) {
			$sql = rtrim( $sql, "; \t\n\r" ) . ' LIMIT ' . ( $max + 1 );
		}

		$wpdb->suppress_errors( true );
		$rows = $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB
		$error = $wpdb->last_error;
		$wpdb->suppress_errors( false );

		if ( $error ) {
			return $this->fail(
				sprintf(
					/* translators: %s: database error. */
					__( 'The database rejected that query: %s', 'kai-vibe' ),
					$error
				)
			);
		}

		$rows = (array) $rows;

		$truncated = count( $rows ) > $max;

		if ( $truncated ) {
			$rows = array_slice( $rows, 0, $max );
		}

		foreach ( $rows as $index => $row ) {
			$rows[ $index ] = ProtectedData::redact_row( (array) $row );
		}

		return array(
			'rows'      => $rows,
			'count'     => count( $rows ),
			'truncated' => $truncated,
			'note'      => $truncated
				? sprintf( 'Capped at %d rows. Add your own LIMIT and OFFSET to page through.', $max )
				: '',
		);
	}

	/**
	 * @param string $sql  Statement.
	 * @param string $verb Leading keyword.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	private function run_write( $sql, $verb ) {
		global $wpdb;

		if ( ! kaiv_setting( 'db_write_enabled', false ) ) {
			return $this->fail(
				__( 'Database writes are switched off for this site. Use the dedicated tools instead — they do the same job through WordPress and keep caches correct. If raw writes really are needed, the site owner can enable them under KAI Vibe → Settings.', 'kai-vibe' ),
				array( 'statement' => strtoupper( $verb ) )
			);
		}

		if ( ! \KaiVibe\Auth\Authenticator::instance()->has_scope( 'db:write' ) ) {
			return $this->fail( __( 'This connection does not hold the db:write scope.', 'kai-vibe' ) );
		}

		// The user tables are where a silent write becomes a backdoor.
		foreach ( ProtectedData::guarded_tables() as $guarded ) {
			if ( preg_match( '/\b' . preg_quote( $wpdb->prefix . $guarded, '/' ) . '\b/i', $sql ) ) {
				return $this->fail(
					sprintf(
						/* translators: %s: table name. */
						__( 'Writes to %s are refused. Use the user tools, which enforce role and capability checks.', 'kai-vibe' ),
						$wpdb->prefix . $guarded
					)
				);
			}
		}

		$gate = \KaiVibe\Security\Approval::require_for( 'db_query', array( 'sql' => $sql ) );

		if ( $gate ) {
			return $gate;
		}

		$wpdb->suppress_errors( true );
		$result = $wpdb->query( $sql ); // phpcs:ignore WordPress.DB
		$error  = $wpdb->last_error;
		$wpdb->suppress_errors( false );

		if ( false === $result ) {
			return $this->fail(
				sprintf(
					/* translators: %s: database error. */
					__( 'The database rejected that statement: %s', 'kai-vibe' ),
					$error
				)
			);
		}

		// A raw write leaves WordPress holding stale copies of what it changed.
		wp_cache_flush();

		kaiv_audit( 'db.write', array( 'verb' => $verb, 'rows' => $result ) );

		return array(
			'executed'      => true,
			'statement'     => strtoupper( $verb ),
			'rows_affected' => (int) $result,
			'insert_id'     => 'insert' === $verb ? (int) $wpdb->insert_id : null,
			'note'          => 'The object cache was flushed, because a raw write bypasses the hooks that normally do it. Persistent caches such as a page cache or CDN may still be stale.',
		);
	}

	/**
	 * Leading keyword, with comments stripped so they cannot disguise it.
	 *
	 * @param string $sql Statement.
	 * @return string
	 */
	/**
	 * Blank out string literals and strip comments, so a keyword check cannot
	 * be fooled by either. Strings are blanked first: a "--" inside a quoted
	 * value is data, not the start of a comment.
	 *
	 * @param string $sql Statement.
	 * @return string
	 */
	private function normalise_for_checks( $sql ) {
		$out = preg_replace( '/\'(?:\\\\.|[^\'\\\\])*\'|"(?:\\\\.|[^"\\\\])*"/', "''", (string) $sql );
		$out = preg_replace( '#/\*.*?\*/#s', ' ', (string) $out );
		$out = preg_replace( '/(--|\#)[^\n]*/', ' ', (string) $out );

		return (string) $out;
	}

	/**
	 * @param string $sql Statement.
	 * @return string
	 */
	private function verb( $sql ) {
		$stripped = preg_replace( '#/\*.*?\*/#s', ' ', $sql );
		$stripped = preg_replace( '/^\s*(--|#).*$/m', ' ', (string) $stripped );
		$stripped = ltrim( (string) $stripped, "( \t\n\r" );

		if ( preg_match( '/^([a-z_]+)/i', $stripped, $m ) ) {
			return strtolower( $m[1] );
		}

		return '';
	}

	/**
	 * Detect stacked statements, ignoring semicolons inside string literals.
	 *
	 * @param string $sql Statement.
	 * @return bool
	 */
	private function has_multiple_statements( $sql ) {
		$without_strings = preg_replace( '/\'(?:\\\\.|[^\'\\\\])*\'|"(?:\\\\.|[^"\\\\])*"/', "''", $sql );
		$trimmed         = rtrim( (string) $without_strings, "; \t\n\r" );

		return false !== strpos( $trimmed, ';' );
	}

	/**
	 * @param string $table Raw table name.
	 * @return string
	 */
	private function normalise_table( $table ) {
		global $wpdb;

		$table = preg_replace( '/[^A-Za-z0-9_]/', '', (string) $table );

		if ( 0 !== strpos( $table, $wpdb->prefix ) && ! $this->table_exists( $table ) ) {
			return $wpdb->prefix . $table;
		}

		return $table;
	}

	/**
	 * @param string $table Table name.
	 * @return bool
	 */
	private function table_exists( $table ) {
		global $wpdb;

		// prepare() quotes the value but leaves LIKE wildcards alone, and every
		// WordPress table name contains an underscore.
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ); // phpcs:ignore WordPress.DB
	}
}
