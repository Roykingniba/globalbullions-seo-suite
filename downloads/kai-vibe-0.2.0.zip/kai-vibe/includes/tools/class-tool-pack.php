<?php
/**
 * Base for a group of related tools.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Tool;
use KaiVibe\Mcp\ToolRegistry;
use KaiVibe\Mcp\ToolResult;

defined( 'ABSPATH' ) || exit;

abstract class ToolPack {

	/**
	 * Register this pack's tools.
	 *
	 * @param ToolRegistry $registry Registry.
	 */
	abstract public function register( ToolRegistry $registry );

	/**
	 * Shorthand for Tool::make().
	 *
	 * @param string $name Tool name.
	 * @return Tool
	 */
	protected function tool( $name ) {
		return Tool::make( $name );
	}

	/**
	 * A paged list result with a consistent shape.
	 *
	 * @param array $items    Items.
	 * @param int   $total    Total matching items.
	 * @param int   $page     Current page.
	 * @param int   $per_page Page size.
	 * @param array $extra    Extra top-level keys.
	 * @return array
	 */
	protected function paged( array $items, $total, $page, $per_page, array $extra = array() ) {
		$pages = $per_page > 0 ? (int) ceil( $total / $per_page ) : 1;

		$payload = array(
			'items'    => $items,
			'total'    => (int) $total,
			'page'     => (int) $page,
			'per_page' => (int) $per_page,
			'pages'    => $pages,
		);

		if ( $pages > $page ) {
			$payload['next_page'] = $page + 1;
		}

		return array_merge( $payload, $extra );
	}

	/**
	 * @param string $message Message.
	 * @param array  $detail  Detail.
	 * @return ToolResult
	 */
	protected function fail( $message, array $detail = array() ) {
		return ToolResult::error( $message, $detail );
	}

	/**
	 * Fetch a post, or a friendly error explaining what went wrong.
	 *
	 * @param int    $post_id    Post id.
	 * @param string $capability Capability to require, e.g. edit_post.
	 * @return \WP_Post|ToolResult
	 */
	protected function require_post( $post_id, $capability = 'read_post' ) {
		$post = get_post( (int) $post_id );

		if ( ! $post ) {
			return $this->fail(
				sprintf(
					/* translators: %d: post id. */
					__( 'There is no post with ID %d. Use find_content to locate the right one.', 'kai-vibe' ),
					(int) $post_id
				)
			);
		}

		if ( $capability && ! current_user_can( $capability, $post->ID ) ) {
			return $this->fail(
				sprintf(
					/* translators: 1: capability, 2: post id. */
					__( 'The connected user cannot %1$s post %2$d.', 'kai-vibe' ),
					$capability,
					$post->ID
				)
			);
		}

		return $post;
	}
}
