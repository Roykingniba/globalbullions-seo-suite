<?php
/**
 * Page builder layouts.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Schema;
use KaiVibe\Mcp\ToolRegistry;
use KaiVibe\Security\Journal;
use KaiVibe\Support\Builders;

defined( 'ABSPATH' ) || exit;

class BuilderTools extends ToolPack {

	public function register( ToolRegistry $registry ) {

		$registry->add(
			$this->tool( 'builder_detect' )
				->describe( 'Report which page builders are installed on this site, and which one owns a given post. Call this before editing any page whose layout looks more complex than plain content.', 'Detect builder' )
				->scope( 'content:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'post_id' => Schema::integer( 'Optionally check one specific post.' ),
						)
					)
				)
				->run( array( $this, 'detect' ) )
		);

		$registry->add(
			$this->tool( 'builder_get' )
				->describe(
					'Read a post\'s page builder layout. Elementor and Breakdance return decoded JSON you can navigate; Divi, Oxygen and WPBakery return their shortcode markup. This is the only correct way to read a builder page — post_content is either empty or a stale rendering.',
					'Read builder layout'
				)
				->scope( 'content:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'post_id' => Schema::integer( 'Post ID.' ),
						),
						array( 'post_id' )
					)
				)
				->run( array( $this, 'get' ) )
		);

		$registry->add(
			$this->tool( 'builder_set' )
				->describe(
					'Write a post\'s page builder layout back, in the same shape builder_get returned. The value is encoded the way that builder expects, the flags it needs are set, and its CSS cache is regenerated — all three of which are needed for the change to actually appear on the front end. The previous layout is journalled.',
					'Write builder layout'
				)
				->scope( 'builder:write' )
				->cap( 'edit_posts' )
				->input(
					Schema::object(
						array(
							'post_id' => Schema::integer( 'Post ID.' ),
							'content' => Schema::string( 'The layout. JSON for Elementor and Breakdance, shortcode markup for Divi, Oxygen and WPBakery.' ),
							'builder' => Schema::string( 'Force a specific builder instead of auto-detecting. Rarely needed.' ),
						),
						array( 'post_id', 'content' )
					)
				)
				->run( array( $this, 'set' ) )
		);

		$registry->add(
			$this->tool( 'builder_flush' )
				->describe( 'Regenerate page builder CSS and clear their caches. Run this if a layout change is saved but the front end still shows the old version.', 'Flush builder cache' )
				->scope( 'maintenance' )
				->input(
					Schema::object(
						array(
							'post_id' => Schema::integer( 'Flush one post. Omit to flush everything.' ),
						)
					)
				)
				->run(
					function ( array $args ) {
						$post_id = isset( $args['post_id'] ) ? (int) $args['post_id'] : 0;

						Builders::flush( $post_id );

						return array(
							'flushed' => true,
							'scope'   => $post_id ? 'post ' . $post_id : 'site-wide',
						);
					}
				)
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function detect( array $args ) {
		$active = Builders::active();

		$payload = array(
			'installed' => array_map( array( Builders::class, 'label' ), $active ),
			'keys'      => $active,
		);

		if ( ! empty( $args['post_id'] ) ) {
			$post_id = (int) $args['post_id'];
			$builder = Builders::detect_for_post( $post_id );

			$payload['post_id'] = $post_id;
			$payload['builder'] = $builder ? $builder : null;
			$payload['note']    = $builder
				? sprintf( 'This post is built with %s. Use builder_get and builder_set.', Builders::label( $builder ) )
				: 'No builder owns this post. Edit post_content with update_post.';
		}

		if ( empty( $active ) ) {
			$payload['note'] = 'No page builders are installed. All content is plain WordPress blocks or HTML.';
		}

		return $payload;
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function get( array $args ) {
		$post = $this->require_post( $args['post_id'], 'edit_post' );

		if ( ! $post instanceof \WP_Post ) {
			return $post;
		}

		return Builders::read( $post->ID );
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function set( array $args ) {
		$post = $this->require_post( $args['post_id'], 'edit_post' );

		if ( ! $post instanceof \WP_Post ) {
			return $post;
		}

		$builder = ! empty( $args['builder'] ) ? $args['builder'] : Builders::detect_for_post( $post->ID );

		if ( ! $builder ) {
			return $this->fail(
				__( 'No page builder owns this post, so there is no layout to write. Use update_post to change post_content instead.', 'kai-vibe' )
			);
		}

		$definition = Builders::all();
		$definition = isset( $definition[ $builder ] ) ? $definition[ $builder ] : null;

		if ( ! $definition ) {
			return $this->fail( __( 'Unrecognised builder key.', 'kai-vibe' ) );
		}

		$content = $args['content'];

		// JSON and serialized builders both need a PHP value, not a string.
		// Beaver Builder and Bricks store arrays; writing the raw JSON string
		// into their meta key renders the page empty.
		if ( in_array( $definition['format'], array( 'json', 'serialized' ), true ) ) {
			$decoded = json_decode( $content, true );

			if ( JSON_ERROR_NONE !== json_last_error() ) {
				return $this->fail(
					sprintf(
						/* translators: %s: JSON parser message. */
						__( 'That is not valid JSON, so it was not written: %s. Read the current layout with builder_get and keep its structure.', 'kai-vibe' ),
						json_last_error_msg()
					)
				);
			}

			$content = $decoded;
		}

		// Journal the previous layout before it goes.
		$before = 'shortcode' === $definition['format'] && empty( $definition['meta'] )
			? $post->post_content
			: get_post_meta( $post->ID, $definition['meta'], true );

		$target = 'shortcode' === $definition['format'] && empty( $definition['meta'] )
			? (string) $post->ID
			: $post->ID . ':' . $definition['meta'];

		$kind = 'shortcode' === $definition['format'] && empty( $definition['meta'] )
			? Journal::KIND_POST
			: Journal::KIND_META;

		$payload = Journal::KIND_POST === $kind
			? array( 'before' => array( 'post_content' => $before ) )
			: array( 'before' => $before, 'post_id' => $post->ID, 'meta_key' => $definition['meta'] );

		Journal::record(
			$kind,
			$target,
			sprintf( 'Rewrote %s layout on "%s"', Builders::label( $builder ), $post->post_title ),
			$payload
		);

		$result = Builders::write( $post->ID, $content, $builder );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return array_merge(
			array( 'written' => true, 'post_id' => $post->ID, 'url' => get_permalink( $post ) ),
			$result,
			array( 'note' => 'Builder cache flushed. If the front end still looks stale, a page cache or CDN is holding the old version — try flush_cache.' )
		);
	}
}
