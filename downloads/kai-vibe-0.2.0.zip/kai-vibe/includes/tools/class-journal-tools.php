<?php
/**
 * The undo stack.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Schema;
use KaiVibe\Mcp\ToolRegistry;
use KaiVibe\Security\Journal;

defined( 'ABSPATH' ) || exit;

class JournalTools extends ToolPack {

	public function register( ToolRegistry $registry ) {

		$registry->add(
			$this->tool( 'list_changes' )
				->describe(
					'List the changes made through this plugin, newest first, each with the id undo_change needs. Every post edit, meta write, option change, term edit and file write is recorded here along with its previous state. Start here when something you did turns out to be wrong.',
					'List changes'
				)
				->scope( '' )
				->read_only()
				->input(
					Schema::object(
						array(
							'kind'     => Schema::enum( 'Filter by what was changed.', array( 'post', 'meta', 'option', 'file', 'term' ) ),
							'target'   => Schema::string( 'Filter by target: a post ID, option name or file path.' ),
							'pending'  => Schema::boolean( 'Only changes that have not been undone.', array( 'default' => true ) ),
							'per_page' => Schema::integer( 'Results per page.', array( 'default' => 25, 'minimum' => 1, 'maximum' => 200 ) ),
							'page'     => Schema::integer( 'Page number.', array( 'default' => 1, 'minimum' => 1 ) ),
						)
					)
				)
				->run( array( $this, 'list_changes' ) )
		);

		$registry->add(
			$this->tool( 'get_change' )
				->describe( 'Read one journal entry in full, including the previous value. Use this to see exactly what a change replaced before deciding whether to undo it.', 'Get change' )
				->scope( '' )
				->read_only()
				->input(
					Schema::object(
						array(
							'change_id' => Schema::integer( 'Journal entry id from list_changes.' ),
						),
						array( 'change_id' )
					)
				)
				->run( array( $this, 'get_change' ) )
		);

		$registry->add(
			$this->tool( 'undo_change' )
				->describe(
					'Roll a journalled change back to its previous state. Works for post bodies, meta values, options, terms and files — including things WordPress revisions do not cover. Undoing a creation trashes what was created.',
					'Undo change'
				)
				->scope( '' )
				->destructive( true )
				->input(
					Schema::object(
						array(
							'change_id' => Schema::integer( 'Journal entry id from list_changes.' ),
						),
						array( 'change_id' )
					)
				)
				->run( array( $this, 'undo_change' ) )
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function list_changes( array $args ) {
		$per_page = isset( $args['per_page'] ) ? (int) $args['per_page'] : 25;
		$page     = isset( $args['page'] ) ? (int) $args['page'] : 1;

		$result = Journal::query(
			array(
				'per_page'       => $per_page,
				'page'           => $page,
				'kind'           => isset( $args['kind'] ) ? $args['kind'] : '',
				'target'         => isset( $args['target'] ) ? (string) $args['target'] : '',
				'include_undone' => ! ( ! isset( $args['pending'] ) || $args['pending'] ),
			)
		);

		return $this->paged(
			$result['items'],
			$result['total'],
			$page,
			$per_page,
			array( 'note' => $result['items'] ? 'Pass a change id to get_change to see the previous value, or to undo_change to roll it back.' : 'Nothing journalled yet.' )
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function get_change( array $args ) {
		$entry = Journal::get( (int) $args['change_id'] );

		if ( ! $entry ) {
			return $this->fail( __( 'No journal entry with that id.', 'kai-vibe' ) );
		}

		return $entry;
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function undo_change( array $args ) {
		$entry = Journal::get( (int) $args['change_id'] );

		if ( ! $entry ) {
			return $this->fail( __( 'No journal entry with that id.', 'kai-vibe' ) );
		}

		$gate = $this->gate_for_kind( isset( $entry['kind'] ) ? (string) $entry['kind'] : '' );

		if ( $gate ) {
			return $gate;
		}

		$result = Journal::undo( (int) $args['change_id'] );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return $result;
	}

	/**
	 * Undoing a change must require what making it required. Without this, a
	 * read-only token could roll back a file write it was never allowed to
	 * make in the first place.
	 *
	 * @param string $kind Journal entry kind.
	 * @return \KaiVibe\Mcp\ToolResult|null Failure to return to the caller, or null to proceed.
	 */
	private function gate_for_kind( $kind ) {
		$needs = array(
			Journal::KIND_FILE   => array( 'fs:write', 'edit_themes' ),
			Journal::KIND_OPTION => array( 'options:write', 'manage_options' ),
			Journal::KIND_TERM   => array( 'taxonomy:write', 'manage_categories' ),
			Journal::KIND_POST   => array( 'content:write', 'edit_posts' ),
			Journal::KIND_META   => array( 'content:write', 'edit_posts' ),
		);

		if ( ! isset( $needs[ $kind ] ) ) {
			return $this->fail( __( 'That journal entry has an unrecognised kind and will not be undone.', 'kai-vibe' ) );
		}

		list( $scope, $capability ) = $needs[ $kind ];

		if ( ! \KaiVibe\Auth\Authenticator::instance()->has_scope( $scope ) || ! current_user_can( $capability ) ) {
			return $this->fail(
				sprintf(
					/* translators: 1: journal entry kind, 2: scope name, 3: capability name. */
					__( 'Undoing a %1$s change needs the %2$s scope and the %3$s capability.', 'kai-vibe' ),
					$kind,
					$scope,
					$capability
				)
			);
		}

		return null;
	}
}
