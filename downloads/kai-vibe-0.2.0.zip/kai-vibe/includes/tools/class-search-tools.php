<?php
/**
 * Cross-cutting search, and looking at the site the way a visitor does.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Schema;
use KaiVibe\Mcp\ToolRegistry;
use KaiVibe\Security\Journal;
use KaiVibe\Support\Formatter;

defined( 'ABSPATH' ) || exit;

class SearchTools extends ToolPack {

	public function register( ToolRegistry $registry ) {

		$registry->add(
			$this->tool( 'search_content' )
				->describe( 'Search across every post type at once and get results grouped by type. Use this when you know roughly what you are looking for but not where it lives.', 'Search everything' )
				->scope( 'content:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'query'    => Schema::string( 'What to search for.' ),
							'limit'    => Schema::integer( 'Maximum results per post type.', array( 'default' => 10, 'minimum' => 1, 'maximum' => 50 ) ),
						),
						array( 'query' )
					)
				)
				->run( array( $this, 'search_content' ) )
		);

		$registry->add(
			$this->tool( 'grep_content' )
				->describe(
					'Search inside post bodies and meta for an exact string or pattern — the content equivalent of grep. This is how you find every page that still references an old phone number, a dead URL or a retired shortcode.',
					'Search post bodies'
				)
				->scope( 'content:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'query'     => Schema::string( 'Text to find.' ),
							'post_type' => Schema::string( 'Restrict to one post type, or "any".', array( 'default' => 'any' ) ),
							'in_meta'   => Schema::boolean( 'Also search post meta, which is where builder layouts live.', array( 'default' => false ) ),
							'limit'     => Schema::integer( 'Maximum matches.', array( 'default' => 50, 'minimum' => 1, 'maximum' => 500 ) ),
						),
						array( 'query' )
					)
				)
				->run( array( $this, 'grep_content' ) )
		);

		$registry->add(
			$this->tool( 'replace_in_content' )
				->describe(
					'Find and replace an exact string across post bodies. Run grep_content first and read the list — this touches many posts at once. Every changed post is journalled individually, so undo_change can revert them one by one. Gated.',
					'Find and replace'
				)
				->scope( 'content:write' )
				->cap( 'edit_others_posts' )
				->destructive()
				->gated()
				->input(
					Schema::object(
						array(
							'find'      => Schema::string( 'Exact text to find.' ),
							'replace'   => Schema::string( 'Replacement text.' ),
							'post_type' => Schema::string( 'Restrict to one post type, or "any".', array( 'default' => 'any' ) ),
							'dry_run'   => Schema::boolean( 'Report what would change without changing it. Do this first.', array( 'default' => true ) ),
							'limit'     => Schema::integer( 'Maximum posts to change in one call.', array( 'default' => 50, 'minimum' => 1, 'maximum' => 500 ) ),
						),
						array( 'find', 'replace' )
					)
				)
				->run( array( $this, 'replace_in_content' ) )
		);

		$registry->add(
			$this->tool( 'fetch_rendered_page' )
				->describe(
					'Fetch a URL on this site as a visitor would and return the rendered output. This is how you verify a change actually appears on the front end, catch a PHP warning leaking into the page, or check what a cache is serving.',
					'Fetch rendered page'
				)
				->scope( 'site:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'url'       => Schema::string( 'URL on this site. A path such as /about also works.' ),
							'as_text'   => Schema::boolean( 'Strip HTML and return readable text.', array( 'default' => true ) ),
							'max_bytes' => Schema::integer( 'Cap on returned characters.', array( 'default' => 20000, 'minimum' => 500, 'maximum' => 200000 ) ),
						),
						array( 'url' )
					)
				)
				->run( array( $this, 'fetch_rendered_page' ) )
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function search_content( array $args ) {
		$limit  = isset( $args['limit'] ) ? (int) $args['limit'] : 10;
		$groups = array();
		$total  = 0;

		foreach ( get_post_types( array( 'public' => true ), 'names' ) as $type ) {
			if ( 'attachment' === $type ) {
				continue;
			}

			$query = new \WP_Query(
				array(
					'post_type'      => $type,
					's'              => $args['query'],
					'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
					'posts_per_page' => $limit,
					'no_found_rows'  => false,
				)
			);

			if ( ! $query->posts ) {
				continue;
			}

			$groups[ $type ] = array(
				'found'   => (int) $query->found_posts,
				'results' => array_map(
					static function ( $post ) {
						return Formatter::post( $post );
					},
					$query->posts
				),
			);

			$total += (int) $query->found_posts;
		}

		return array(
			'query'  => $args['query'],
			'total'  => $total,
			'groups' => $groups,
			'note'   => $total ? '' : 'Nothing matched. WordPress search only looks at titles and content — try grep_content, which can also search meta.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function grep_content( array $args ) {
		global $wpdb;

		$query = $args['query'];
		$limit = isset( $args['limit'] ) ? (int) $args['limit'] : 50;
		$like  = '%' . $wpdb->esc_like( $query ) . '%';

		$type_clause = '';
		$params      = array( $like );

		if ( ! empty( $args['post_type'] ) && 'any' !== $args['post_type'] ) {
			$type_clause = 'AND post_type = %s';
			$params[]    = $args['post_type'];
		}

		$params[] = $limit;

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT ID, post_title, post_type, post_status FROM {$wpdb->posts}
				 WHERE post_content LIKE %s {$type_clause}
				 AND post_status NOT IN ('auto-draft', 'inherit')
				 ORDER BY post_modified DESC LIMIT %d",
				$params
			),
			ARRAY_A
		);

		$matches = array();

		foreach ( (array) $rows as $row ) {
			$content = get_post_field( 'post_content', $row['ID'] );
			$offset  = stripos( $content, $query );

			$matches[] = array(
				'post_id' => (int) $row['ID'],
				'title'   => $row['post_title'],
				'type'    => $row['post_type'],
				'status'  => $row['post_status'],
				'where'   => 'post_content',
				'count'   => substr_count( strtolower( $content ), strtolower( $query ) ),
				'context' => false !== $offset
					? '…' . trim( substr( $content, max( 0, $offset - 60 ), 180 ) ) . '…'
					: '',
				'edit_url'=> get_edit_post_link( $row['ID'], 'raw' ),
			);
		}

		$meta_matches = array();

		if ( ! empty( $args['in_meta'] ) ) {
			$meta_rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
				$wpdb->prepare(
					"SELECT post_id, meta_key FROM {$wpdb->postmeta} WHERE meta_value LIKE %s LIMIT %d",
					$like,
					$limit
				),
				ARRAY_A
			);

			foreach ( (array) $meta_rows as $row ) {
				if ( \KaiVibe\Security\ProtectedData::is_protected_meta( $row['meta_key'] ) ) {
					continue;
				}

				$meta_matches[] = array(
					'post_id'  => (int) $row['post_id'],
					'title'    => get_the_title( $row['post_id'] ),
					'where'    => 'meta:' . $row['meta_key'],
					'edit_url' => get_edit_post_link( $row['post_id'], 'raw' ),
				);
			}
		}

		return array(
			'query'        => $query,
			'matches'      => $matches,
			'meta_matches' => $meta_matches,
			'note'         => ( $matches || $meta_matches )
				? 'Use replace_in_content with dry_run=true to preview a bulk fix.'
				: 'No matches in post bodies. Try in_meta=true — page builder layouts are stored in meta.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function replace_in_content( array $args ) {
		global $wpdb;

		$find    = (string) $args['find'];
		$replace = (string) $args['replace'];
		$limit   = isset( $args['limit'] ) ? (int) $args['limit'] : 50;
		$dry_run = ! isset( $args['dry_run'] ) || $args['dry_run'];

		if ( '' === $find ) {
			return $this->fail( __( 'The find string cannot be empty.', 'kai-vibe' ) );
		}

		$like        = '%' . $wpdb->esc_like( $find ) . '%';
		$type_clause = '';
		$params      = array( $like );

		if ( ! empty( $args['post_type'] ) && 'any' !== $args['post_type'] ) {
			$type_clause = 'AND post_type = %s';
			$params[]    = $args['post_type'];
		}

		$params[] = $limit;

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts}
				 WHERE post_content LIKE %s {$type_clause}
				 AND post_status NOT IN ('auto-draft', 'inherit', 'trash')
				 ORDER BY ID ASC LIMIT %d",
				$params
			),
			ARRAY_A
		);

		$changed = array();
		$skipped = array();

		foreach ( (array) $rows as $row ) {
			$post_id = (int) $row['ID'];
			$post    = get_post( $post_id );

			if ( ! $post || ! current_user_can( 'edit_post', $post_id ) ) {
				$skipped[] = array( 'post_id' => $post_id, 'reason' => 'not permitted' );
				continue;
			}

			$builder = \KaiVibe\Support\Builders::detect_for_post( $post_id );

			// Rewriting post_content on a builder page does nothing useful.
			if ( $builder ) {
				$skipped[] = array( 'post_id' => $post_id, 'reason' => 'built with ' . $builder . ' — edit with builder_set' );
				continue;
			}

			$occurrences = substr_count( $post->post_content, $find );

			// The selecting LIKE is case-insensitive but str_replace is not, so
			// without this we would rewrite (and journal, and bump the modified
			// date on) posts that only matched on case.
			if ( 0 === $occurrences ) {
				$skipped[] = array( 'post_id' => $post_id, 'reason' => 'matched case-insensitively only — find is case-sensitive' );
				continue;
			}

			$entry = array(
				'post_id'      => $post_id,
				'title'        => $post->post_title,
				'occurrences'  => $occurrences,
				'edit_url'     => get_edit_post_link( $post_id, 'raw' ),
			);

			if ( ! $dry_run ) {
				Journal::record(
					Journal::KIND_POST,
					$post_id,
					sprintf( 'Replaced "%s" in "%s"', $find, $post->post_title ),
					array( 'before' => array( 'post_content' => $post->post_content ) )
				);

				$updated = wp_update_post(
					array(
						'ID'           => $post_id,
						'post_content' => wp_slash( str_replace( $find, $replace, $post->post_content ) ),
					),
					true
				);

				if ( is_wp_error( $updated ) ) {
					$skipped[] = array( 'post_id' => $post_id, 'reason' => $updated->get_error_message() );
					continue;
				}
			}

			$changed[] = $entry;
		}

		return array(
			'dry_run'  => $dry_run,
			'find'     => $find,
			'replace'  => $replace,
			'posts'    => $changed,
			'affected' => count( $changed ),
			'skipped'  => $skipped,
			'note'     => $dry_run
				? 'Nothing was changed. Review this list, then call again with dry_run=false.'
				: 'Each post was journalled separately, so undo_change can revert them individually.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function fetch_rendered_page( array $args ) {
		$url = trim( (string) $args['url'] );

		if ( 0 === strpos( $url, '/' ) ) {
			$url = home_url( $url );
		}

		$host      = wp_parse_url( $url, PHP_URL_HOST );
		$site_host = wp_parse_url( home_url(), PHP_URL_HOST );

		// This tool exists to look at *this* site, not to fetch arbitrary URLs.
		if ( $host !== $site_host ) {
			return $this->fail(
				sprintf(
					/* translators: %s: site host. */
					__( 'This tool only fetches pages on %s.', 'kai-vibe' ),
					$site_host
				)
			);
		}

		$response = wp_remote_get(
			$url,
			array(
				'timeout'    => 20,
				'redirection'=> 3,
				'sslverify'  => ! in_array( wp_get_environment_type(), array( 'local', 'development' ), true ),
				'headers'    => array( 'Cache-Control' => 'no-cache' ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $this->fail(
				sprintf(
					/* translators: %s: error message. */
					__( 'The request failed: %s', 'kai-vibe' ),
					$response->get_error_message()
				)
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );

		$max = isset( $args['max_bytes'] ) ? (int) $args['max_bytes'] : 20000;

		if ( ! isset( $args['as_text'] ) || $args['as_text'] ) {
			$body = preg_replace( '#<(script|style|noscript)[^>]*>.*?</\1>#is', ' ', $body );
			$body = wp_strip_all_tags( (string) $body );
			$body = preg_replace( "/\n{3,}/", "\n\n", trim( preg_replace( '/[ \t]+/', ' ', $body ) ) );
		}

		$truncated = strlen( $body ) > $max;

		if ( $truncated ) {
			$body = substr( $body, 0, $max );
		}

		// PHP notices leaking into output are the usual cause of a broken page.
		$warnings = array();

		foreach ( array( 'Fatal error', 'Warning:', 'Notice:', 'Deprecated:', 'Parse error' ) as $needle ) {
			if ( false !== strpos( $body, $needle ) ) {
				$warnings[] = $needle;
			}
		}

		return array(
			'url'          => $url,
			'status'       => (int) $code,
			'content_type' => wp_remote_retrieve_header( $response, 'content-type' ),
			'body'         => $body,
			'truncated'    => $truncated,
			'php_errors'   => $warnings,
			'note'         => $warnings
				? 'PHP errors are being printed into the page output. That is almost certainly the bug.'
				: '',
		);
	}
}
