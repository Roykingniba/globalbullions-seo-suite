<?php
/**
 * Caches, rewrite rules, cron and transients.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Schema;
use KaiVibe\Mcp\ToolRegistry;
use KaiVibe\Support\Builders;

defined( 'ABSPATH' ) || exit;

class MaintenanceTools extends ToolPack {

	public function register( ToolRegistry $registry ) {

		$registry->add(
			$this->tool( 'flush_cache' )
				->describe(
					'Clear the caches that make a change fail to show up: the object cache, page builder CSS, and whichever caching plugin is installed. Run this after a change that looks saved but does not appear on the front end.',
					'Flush caches'
				)
				->scope( 'maintenance' )
				->cap( 'manage_options' )
				->input(
					Schema::object(
						array(
							'post_id' => Schema::integer( 'Also clear caches for one specific post.' ),
						)
					)
				)
				->run( array( $this, 'flush_cache' ) )
		);

		$registry->add(
			$this->tool( 'flush_rewrites' )
				->describe( 'Regenerate permalink rules. The fix when a new post type or a changed slug gives a 404 on a page that plainly exists.', 'Flush rewrite rules' )
				->scope( 'maintenance' )
				->cap( 'manage_options' )
				->input( Schema::object() )
				->run(
					function () {
						flush_rewrite_rules( true );

						return array(
							'flushed'    => true,
							'permalinks' => get_option( 'permalink_structure' ) ? get_option( 'permalink_structure' ) : 'plain',
						);
					}
				)
		);

		$registry->add(
			$this->tool( 'list_cron' )
				->describe( 'List scheduled cron events with their next run time and recurrence. Overdue events usually mean the site gets no traffic, or DISABLE_WP_CRON is set without a real cron job behind it.', 'List cron events' )
				->scope( 'maintenance' )
				->read_only()
				->input(
					Schema::object(
						array(
							'overdue_only' => Schema::boolean( 'Only events whose scheduled time has passed.', array( 'default' => false ) ),
						)
					)
				)
				->run( array( $this, 'list_cron' ) )
		);

		$registry->add(
			$this->tool( 'run_cron_event' )
				->describe( 'Run a scheduled cron hook immediately rather than waiting for its next window. Useful for kicking a stuck queue.', 'Run cron event' )
				->scope( 'maintenance' )
				->cap( 'manage_options' )
				->gated()
				->input(
					Schema::object(
						array(
							'hook' => Schema::string( 'Cron hook name from list_cron.' ),
						),
						array( 'hook' )
					)
				)
				->run( array( $this, 'run_cron_event' ) )
		);

		$registry->add(
			$this->tool( 'manage_transients' )
				->describe( 'List or delete transients. Expired transients accumulating in the options table are a common and easily fixed cause of a slow site.', 'Transients' )
				->scope( 'maintenance' )
				->cap( 'manage_options' )
				->input(
					Schema::object(
						array(
							'action' => Schema::enum( 'What to do.', array( 'list', 'delete', 'delete_expired' ), array( 'default' => 'list' ) ),
							'name'   => Schema::string( 'Transient name, without the _transient_ prefix. Required for delete.' ),
							'search' => Schema::string( 'Filter the list by name.' ),
						)
					)
				)
				->run( array( $this, 'manage_transients' ) )
		);

		$registry->add(
			$this->tool( 'read_debug_log' )
				->describe( 'Read the tail of wp-content/debug.log. The first place to look when something fails silently. Returns nothing useful unless WP_DEBUG_LOG is enabled.', 'Read debug log' )
				->scope( 'site:read' )
				->cap( 'manage_options' )
				->read_only()
				->input(
					Schema::object(
						array(
							'lines'  => Schema::integer( 'How many lines from the end.', array( 'default' => 100, 'minimum' => 1, 'maximum' => 2000 ) ),
							'filter' => Schema::string( 'Only lines containing this text, e.g. "Fatal" or a plugin name.' ),
						)
					)
				)
				->run( array( $this, 'read_debug_log' ) )
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function flush_cache( array $args ) {
		$cleared = array();

		wp_cache_flush();
		$cleared[] = 'object cache';

		$post_id = isset( $args['post_id'] ) ? (int) $args['post_id'] : 0;

		if ( $post_id ) {
			clean_post_cache( $post_id );
			$cleared[] = 'post ' . $post_id;
		}

		Builders::flush( $post_id );
		$cleared[] = 'page builder cache';

		// The popular caching plugins, each with its own idea of an API.
		$plugins = array(
			'w3-total-cache'  => static function () {
				if ( function_exists( 'w3tc_flush_all' ) ) {
					w3tc_flush_all();
					return true;
				}
				return null;
			},
			'wp-super-cache'  => static function () {
				if ( function_exists( 'wp_cache_clear_cache' ) ) {
					wp_cache_clear_cache();
					return true;
				}
				return null;
			},
			'wp-rocket'       => static function () {
				if ( function_exists( 'rocket_clean_domain' ) ) {
					rocket_clean_domain();
					return true;
				}
				return null;
			},
			'litespeed-cache' => static function () {
				if ( class_exists( '\LiteSpeed\Purge' ) ) {
					do_action( 'litespeed_purge_all' );
					return true;
				}
				return null;
			},
			'wp-fastest-cache' => static function () {
				if ( class_exists( 'WpFastestCache' ) ) {
					do_action( 'wpfc_clear_all_cache', true );
					return true;
				}
				return null;
			},
			'autoptimize'     => static function () {
				if ( class_exists( 'autoptimizeCache' ) ) {
					\autoptimizeCache::clearall();
					return true;
				}
				return null;
			},
			'sg-optimizer'    => static function () {
				if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
					sg_cachepress_purge_cache();
					return true;
				}
				return null;
			},
		);

		foreach ( $plugins as $slug => $callback ) {
			try {
				if ( null !== $callback() ) {
					$cleared[] = $slug;
				}
			} catch ( \Throwable $e ) {
				// One uncooperative cache plugin should not stop the rest.
				continue;
			}
		}

		/**
		 * Clear any other cache layer.
		 *
		 * @param int $post_id Post id, or 0 for site-wide.
		 */
		do_action( 'kaiv_flush_cache', $post_id );

		return array(
			'flushed' => $cleared,
			'note'    => 'A CDN in front of the site is not covered by this — purge that separately if the page is still stale.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function list_cron( array $args ) {
		$crons  = _get_cron_array();
		$now    = time();
		$events = array();

		foreach ( (array) $crons as $timestamp => $hooks ) {
			foreach ( (array) $hooks as $hook => $instances ) {
				foreach ( (array) $instances as $instance ) {
					$overdue = $timestamp < $now;

					if ( ! empty( $args['overdue_only'] ) && ! $overdue ) {
						continue;
					}

					$events[] = array(
						'hook'       => $hook,
						'next_run'   => gmdate( 'c', $timestamp ),
						'in_seconds' => $timestamp - $now,
						'overdue'    => $overdue,
						'schedule'   => isset( $instance['schedule'] ) && $instance['schedule'] ? $instance['schedule'] : 'one-off',
						'args'       => isset( $instance['args'] ) ? $instance['args'] : array(),
					);
				}
			}
		}

		usort(
			$events,
			static function ( $a, $b ) {
				return $a['in_seconds'] <=> $b['in_seconds'];
			}
		);

		$disabled = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;
		$overdue  = count( array_filter( $events, static function ( $event ) {
			return $event['overdue'];
		} ) );

		return array(
			'events'       => $events,
			'total'        => count( $events ),
			'overdue'      => $overdue,
			'wp_cron'      => $disabled ? 'disabled in wp-config.php' : 'enabled',
			'note'         => ( $overdue > 3 && ! $disabled )
				? 'Several events are overdue. WordPress cron only fires on page loads, so a quiet site falls behind — a real server cron job is the fix.'
				: '',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function run_cron_event( array $args ) {
		$hook  = $args['hook'];
		$event = wp_get_scheduled_event( $hook );

		if ( ! $event ) {
			return $this->fail( __( 'No scheduled event with that hook. Call list_cron to see what is registered.', 'kai-vibe' ) );
		}

		$started = microtime( true );

		// Fire it with the arguments it was scheduled with. Without them, any
		// callback that takes a required parameter raises ArgumentCountError,
		// and callbacks with optional ones act on the wrong target.
		do_action_ref_array( $hook, (array) $event->args );

		return array(
			'ran'         => true,
			'hook'        => $hook,
			'duration_ms' => (int) round( ( microtime( true ) - $started ) * 1000 ),
			'note'        => 'The hook fired immediately. Its schedule is unchanged, so it will still run at its next scheduled time.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function manage_transients( array $args ) {
		global $wpdb;

		$action = isset( $args['action'] ) ? $args['action'] : 'list';

		if ( 'delete' === $action ) {
			if ( empty( $args['name'] ) ) {
				return $this->fail( __( 'Pass the transient name to delete.', 'kai-vibe' ) );
			}

			$deleted = delete_transient( $args['name'] );

			return array( 'deleted' => (bool) $deleted, 'name' => $args['name'] );
		}

		if ( 'delete_expired' === $action ) {
			$count = (int) $wpdb->query( // phpcs:ignore WordPress.DB
				$wpdb->prepare(
					"DELETE a, b FROM {$wpdb->options} a
					 LEFT JOIN {$wpdb->options} b ON b.option_name = REPLACE(a.option_name, '_transient_timeout_', '_transient_')
					 WHERE a.option_name LIKE %s AND a.option_value < %d",
					$wpdb->esc_like( '_transient_timeout_' ) . '%',
					time()
				)
			);

			return array(
				'deleted' => $count,
				'note'    => 'Expired transients removed. This does not touch transients that are still valid.',
			);
		}

		$where  = "option_name LIKE %s AND option_name NOT LIKE %s";
		$params = array( $wpdb->esc_like( '_transient_' ) . '%', $wpdb->esc_like( '_transient_timeout_' ) . '%' );

		if ( ! empty( $args['search'] ) ) {
			$where   .= ' AND option_name LIKE %s';
			$params[] = '%' . $wpdb->esc_like( $args['search'] ) . '%';
		}

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT option_name, LENGTH(option_value) AS bytes FROM {$wpdb->options} WHERE {$where} ORDER BY LENGTH(option_value) DESC LIMIT 100",
				$params
			),
			ARRAY_A
		);

		$items = array();

		foreach ( (array) $rows as $row ) {
			$name    = substr( $row['option_name'], strlen( '_transient_' ) );
			$expires = (int) get_option( '_transient_timeout_' . $name );

			$items[] = array(
				'name'    => $name,
				'size'    => size_format( (int) $row['bytes'] ),
				'expires' => $expires ? gmdate( 'c', $expires ) : 'never',
				'expired' => $expires && $expires < time(),
			);
		}

		return array(
			'transients' => $items,
			'note'       => wp_using_ext_object_cache()
				? 'This site uses an external object cache, so most transients never reach the database and will not appear here.'
				: 'Sorted by size. A very large transient in the options table is worth investigating.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function read_debug_log( array $args ) {
		$path = WP_CONTENT_DIR . '/debug.log';

		if ( ! file_exists( $path ) ) {
			return array(
				'exists' => false,
				'note'   => 'There is no wp-content/debug.log. Set WP_DEBUG and WP_DEBUG_LOG to true in wp-config.php to start logging.',
			);
		}

		$lines  = isset( $args['lines'] ) ? (int) $args['lines'] : 100;
		$filter = isset( $args['filter'] ) ? $args['filter'] : '';

		// Read the tail rather than loading a log that may be hundreds of MB.
		$size = (int) filesize( $path );

		if ( $size < 1 ) {
			return array(
				'exists' => true,
				'size'   => size_format( 0 ),
				'lines'  => array(),
				'fatals' => 0,
				'note'   => 'The log exists but is empty.',
			);
		}

		$chunk  = (int) min( $size, max( 8192, $lines * 400 ) );
		$handle = fopen( $path, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		if ( ! $handle ) {
			return array( 'exists' => true, 'note' => 'The log exists but could not be opened.' );
		}

		fseek( $handle, -$chunk, SEEK_END );
		$tail = fread( $handle, $chunk ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		$all = preg_split( "/\r\n|\n|\r/", (string) $tail );

		// The first line is probably a fragment.
		if ( $chunk < $size ) {
			array_shift( $all );
		}

		if ( '' !== $filter ) {
			$all = array_values(
				array_filter(
					$all,
					static function ( $line ) use ( $filter ) {
						return false !== stripos( $line, $filter );
					}
				)
			);
		}

		$all = array_slice( $all, -$lines );

		$fatals = count(
			array_filter(
				$all,
				static function ( $line ) {
					return false !== stripos( $line, 'fatal error' );
				}
			)
		);

		return array(
			'exists'    => true,
			'size'      => size_format( $size ),
			'lines'     => $all,
			'fatals'    => $fatals,
			'note'      => $fatals ? 'Fatal errors present — read those lines first.' : '',
		);
	}
}
