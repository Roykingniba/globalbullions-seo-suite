<?php
/**
 * Navigation menus.
 *
 * Classic menus live in the nav_menu taxonomy; block themes may instead use
 * wp_navigation posts. Both are handled here so the model does not have to
 * work out which world it is in.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Schema;
use KaiVibe\Mcp\ToolRegistry;

defined( 'ABSPATH' ) || exit;

class MenuTools extends ToolPack {

	public function register( ToolRegistry $registry ) {

		$registry->add(
			$this->tool( 'list_menus' )
				->describe( 'List navigation menus, their assigned theme locations, and how many items each holds. On a block theme this also lists wp_navigation blocks, which is where a block theme actually keeps its navigation.', 'List menus' )
				->scope( 'content:read' )
				->read_only()
				->input( Schema::object() )
				->run( array( $this, 'list_menus' ) )
		);

		$registry->add(
			$this->tool( 'get_menu' )
				->describe( 'Read a menu\'s items in order, with their nesting, targets and object references.', 'Get menu' )
				->scope( 'content:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'menu' => Schema::string( 'Menu name, slug or ID.' ),
						),
						array( 'menu' )
					)
				)
				->run( array( $this, 'get_menu' ) )
		);

		$registry->add(
			$this->tool( 'add_menu_item' )
				->describe( 'Add an item to a menu: a link to a post or page, a taxonomy term, or a custom URL. Pass parent_id to nest it under an existing item.', 'Add menu item' )
				->scope( 'content:write' )
				->cap( 'edit_theme_options' )
				->input(
					Schema::object(
						array(
							'menu'      => Schema::string( 'Menu name, slug or ID.' ),
							'title'     => Schema::string( 'Label shown in the menu.' ),
							'post_id'   => Schema::integer( 'Link to this post or page.' ),
							'term_id'   => Schema::integer( 'Link to this taxonomy term.' ),
							'url'       => Schema::string( 'Link to an arbitrary URL, as an alternative to post_id or term_id.' ),
							'parent_id' => Schema::integer( 'Menu item ID to nest this one under.' ),
							'position'  => Schema::integer( 'Position in the menu, 1-based.' ),
							'target'    => Schema::enum( 'Link target.', array( '', '_blank' ), array( 'default' => '' ) ),
						),
						array( 'menu', 'title' )
					)
				)
				->run( array( $this, 'add_menu_item' ) )
		);

		$registry->add(
			$this->tool( 'delete_menu_item' )
				->describe( 'Remove an item from a menu. Its children are promoted to the item\'s own parent rather than disappearing.', 'Delete menu item' )
				->scope( 'content:write' )
				->cap( 'edit_theme_options' )
				->destructive( true )
				->input(
					Schema::object(
						array(
							'item_id' => Schema::integer( 'Menu item ID from get_menu.' ),
						),
						array( 'item_id' )
					)
				)
				->run( array( $this, 'delete_menu_item' ) )
		);
	}

	/**
	 * @return array
	 */
	public function list_menus() {
		$menus     = wp_get_nav_menus();
		$locations = get_nav_menu_locations();
		$registered = get_registered_nav_menus();

		$items = array();

		foreach ( $menus as $menu ) {
			$assigned = array();

			foreach ( $locations as $location => $menu_id ) {
				if ( (int) $menu_id === (int) $menu->term_id ) {
					$assigned[] = isset( $registered[ $location ] ) ? sprintf( '%s (%s)', $registered[ $location ], $location ) : $location;
				}
			}

			$items[] = array(
				'id'        => $menu->term_id,
				'name'      => $menu->name,
				'slug'      => $menu->slug,
				'count'     => (int) $menu->count,
				'locations' => $assigned,
			);
		}

		$payload = array(
			'menus'               => $items,
			'theme_locations'     => $registered,
			'unassigned_locations'=> array_keys( array_diff_key( $registered, array_filter( $locations ) ) ),
		);

		// Block themes keep navigation in wp_navigation posts instead.
		if ( wp_is_block_theme() ) {
			$navigation = get_posts(
				array(
					'post_type'      => 'wp_navigation',
					'post_status'    => 'any',
					'posts_per_page' => 20,
				)
			);

			$payload['block_navigation'] = array_map(
				static function ( $post ) {
					return array( 'id' => $post->ID, 'title' => $post->post_title, 'status' => $post->post_status );
				},
				$navigation
			);

			$payload['note'] = 'This is a block theme. Navigation is usually stored in the wp_navigation posts listed above — read one with get_post and edit it with update_post.';
		}

		return $payload;
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function get_menu( array $args ) {
		$menu = wp_get_nav_menu_object( $args['menu'] );

		if ( ! $menu ) {
			return $this->fail( __( 'No menu with that name, slug or ID. Call list_menus first.', 'kai-vibe' ) );
		}

		$items = wp_get_nav_menu_items( $menu->term_id );

		$formatted = array();

		foreach ( (array) $items as $item ) {
			$formatted[] = array(
				'id'          => $item->ID,
				'title'       => $item->title,
				'url'         => $item->url,
				'parent'      => (int) $item->menu_item_parent,
				'order'       => (int) $item->menu_order,
				'type'        => $item->type,
				'object'      => $item->object,
				'object_id'   => (int) $item->object_id,
				'target'      => $item->target,
				'classes'     => array_filter( (array) $item->classes ),
			);
		}

		return array(
			'menu'  => array( 'id' => $menu->term_id, 'name' => $menu->name, 'slug' => $menu->slug ),
			'items' => $formatted,
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function add_menu_item( array $args ) {
		$menu = wp_get_nav_menu_object( $args['menu'] );

		if ( ! $menu ) {
			return $this->fail( __( 'No menu with that name, slug or ID.', 'kai-vibe' ) );
		}

		$item = array(
			'menu-item-title'   => $args['title'],
			'menu-item-status'  => 'publish',
			'menu-item-parent-id' => isset( $args['parent_id'] ) ? (int) $args['parent_id'] : 0,
			'menu-item-target'  => isset( $args['target'] ) ? $args['target'] : '',
		);

		if ( ! empty( $args['post_id'] ) ) {
			$post = get_post( (int) $args['post_id'] );

			if ( ! $post ) {
				return $this->fail( __( 'That post does not exist.', 'kai-vibe' ) );
			}

			$item['menu-item-type']      = 'post_type';
			$item['menu-item-object']    = $post->post_type;
			$item['menu-item-object-id'] = $post->ID;
		} elseif ( ! empty( $args['term_id'] ) ) {
			$term = get_term( (int) $args['term_id'] );

			if ( ! $term || is_wp_error( $term ) ) {
				return $this->fail( __( 'That term does not exist.', 'kai-vibe' ) );
			}

			$item['menu-item-type']      = 'taxonomy';
			$item['menu-item-object']    = $term->taxonomy;
			$item['menu-item-object-id'] = $term->term_id;
		} elseif ( ! empty( $args['url'] ) ) {
			$item['menu-item-type'] = 'custom';
			$item['menu-item-url']  = esc_url_raw( $args['url'] );
		} else {
			return $this->fail( __( 'Pass one of post_id, term_id or url so the item links somewhere.', 'kai-vibe' ) );
		}

		if ( isset( $args['position'] ) ) {
			$item['menu-item-position'] = (int) $args['position'];
		}

		$item_id = wp_update_nav_menu_item( $menu->term_id, 0, $item );

		if ( is_wp_error( $item_id ) ) {
			return $item_id;
		}

		return array(
			'added'   => true,
			'item_id' => $item_id,
			'menu'    => $menu->name,
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function delete_menu_item( array $args ) {
		$item_id = (int) $args['item_id'];
		$item    = get_post( $item_id );

		if ( ! $item || 'nav_menu_item' !== $item->post_type ) {
			return $this->fail( __( 'That is not a menu item ID. Call get_menu to find the right one.', 'kai-vibe' ) );
		}

		$title  = get_the_title( $item_id );
		$parent = (int) get_post_meta( $item_id, '_menu_item_menu_item_parent', true );

		// Re-parent the children so a whole branch does not vanish with it.
		$children = get_posts(
			array(
				'post_type'      => 'nav_menu_item',
				'posts_per_page' => -1,
				'meta_key'       => '_menu_item_menu_item_parent', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => (string) $item_id, // phpcs:ignore WordPress.DB.SlowDBQuery
				'post_status'    => 'any',
			)
		);

		foreach ( $children as $child ) {
			update_post_meta( $child->ID, '_menu_item_menu_item_parent', $parent );
		}

		wp_delete_post( $item_id, true );

		return array(
			'deleted'    => true,
			'title'      => $title,
			'reparented' => count( $children ),
		);
	}
}
