<?php
/**
 * WooCommerce.
 *
 * Everything goes through the WooCommerce CRUD classes rather than the posts
 * table, so lookup tables, stock, taxes and HPOS order storage all stay correct.
 * The whole pack hides itself when WooCommerce is not installed.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Schema;
use KaiVibe\Mcp\ToolRegistry;

defined( 'ABSPATH' ) || exit;

class WooCommerceTools extends ToolPack {

	/**
	 * @return bool
	 */
	public static function is_active() {
		return class_exists( 'WooCommerce' ) && function_exists( 'wc_get_product' );
	}

	public function register( ToolRegistry $registry ) {
		$available = array( __CLASS__, 'is_active' );

		$registry->add(
			$this->tool( 'wc_products' )
				->describe( 'Search WooCommerce products by name, SKU, category, stock status or price range. Returns price, stock and type for each — enough to decide what to look at next.', 'Find products' )
				->scope( 'woo:read' )
				->read_only()
				->available_when( $available )
				->input(
					Schema::object(
						array(
							'search'   => Schema::string( 'Match against product name and SKU.' ),
							'sku'      => Schema::string( 'Exact SKU.' ),
							'category' => Schema::string( 'Product category slug.' ),
							'status'   => Schema::enum( 'Post status.', array( 'any', 'publish', 'pending', 'draft', 'private' ), array( 'default' => 'publish' ) ),
							'stock_status' => Schema::enum( 'Stock filter.', array( 'any', 'instock', 'outofstock', 'onbackorder' ), array( 'default' => 'any' ) ),
							'type'     => Schema::enum( 'Product type.', array( 'any', 'simple', 'variable', 'grouped', 'external' ), array( 'default' => 'any' ) ),
							'per_page' => Schema::integer( 'Results per page.', array( 'default' => 20, 'minimum' => 1, 'maximum' => 100 ) ),
							'page'     => Schema::integer( 'Page number.', array( 'default' => 1, 'minimum' => 1 ) ),
						)
					)
				)
				->run( array( $this, 'products' ) )
		);

		$registry->add(
			$this->tool( 'wc_get_product' )
				->describe( 'Read one product in full: pricing, stock, dimensions, categories, attributes, variations and images.', 'Get product' )
				->scope( 'woo:read' )
				->read_only()
				->available_when( $available )
				->input(
					Schema::object(
						array(
							'product_id' => Schema::integer( 'Product ID.' ),
							'sku'        => Schema::string( 'SKU, as an alternative to product_id.' ),
						)
					)
				)
				->run( array( $this, 'get_product' ) )
		);

		$registry->add(
			$this->tool( 'wc_update_product' )
				->describe( 'Change a product\'s price, stock, description, status or categories. Uses the WooCommerce CRUD layer, so lookup tables and stock status stay consistent — never edit product data with db_query.', 'Update product' )
				->scope( 'woo:write' )
				->cap( 'edit_products' )
				->available_when( $available )
				->input(
					Schema::object(
						array(
							'product_id'     => Schema::integer( 'Product ID.' ),
							'name'           => Schema::string( 'Product name.' ),
							'regular_price'  => Schema::string( 'Regular price, as a plain number.' ),
							'sale_price'     => Schema::string( 'Sale price. Pass an empty string to clear it.' ),
							'description'    => Schema::string( 'Long description.' ),
							'short_description' => Schema::string( 'Short description.' ),
							'sku'            => Schema::string( 'SKU. Must be unique across the store.' ),
							'stock_quantity' => Schema::integer( 'Stock level. Enables stock management when set.' ),
							'stock_status'   => Schema::enum( 'Stock status.', array( 'instock', 'outofstock', 'onbackorder' ) ),
							'status'         => Schema::enum( 'Post status.', array( 'publish', 'draft', 'private' ) ),
							'categories'     => Schema::arr( 'Category slugs. Replaces existing categories.' ),
						),
						array( 'product_id' )
					)
				)
				->run( array( $this, 'update_product' ) )
		);

		$registry->add(
			$this->tool( 'wc_orders' )
				->describe( 'List orders filtered by status, customer or date range, with totals. Works with both legacy and HPOS order storage.', 'Find orders' )
				->scope( 'woo:read' )
				->cap( 'edit_shop_orders' )
				->read_only()
				->available_when( $available )
				->input(
					Schema::object(
						array(
							'status'   => Schema::string( 'Order status without the wc- prefix, e.g. processing, completed, refunded. Omit for all.' ),
							'customer' => Schema::integer( 'Customer user ID.' ),
							'search'   => Schema::string( 'Search across billing details and order items.' ),
							'after'    => Schema::string( 'Orders created after this date (YYYY-MM-DD).' ),
							'before'   => Schema::string( 'Orders created before this date (YYYY-MM-DD).' ),
							'per_page' => Schema::integer( 'Results per page.', array( 'default' => 20, 'minimum' => 1, 'maximum' => 100 ) ),
							'page'     => Schema::integer( 'Page number.', array( 'default' => 1, 'minimum' => 1 ) ),
						)
					)
				)
				->run( array( $this, 'orders' ) )
		);

		$registry->add(
			$this->tool( 'wc_get_order' )
				->describe( 'Read one order in full: line items, totals, tax, shipping, billing address, payment method and status history.', 'Get order' )
				->scope( 'woo:read' )
				->cap( 'edit_shop_orders' )
				->read_only()
				->available_when( $available )
				->input(
					Schema::object(
						array(
							'order_id' => Schema::integer( 'Order ID.' ),
						),
						array( 'order_id' )
					)
				)
				->run( array( $this, 'get_order' ) )
		);

		$registry->add(
			$this->tool( 'wc_update_order_status' )
				->describe( 'Change an order\'s status. This fires the emails and stock adjustments WooCommerce normally sends, so treat it as a customer-visible action. Gated.', 'Update order status' )
				->scope( 'woo:write' )
				->cap( 'edit_shop_orders' )
				->gated()
				->available_when( $available )
				->input(
					Schema::object(
						array(
							'order_id' => Schema::integer( 'Order ID.' ),
							'status'   => Schema::string( 'New status without the wc- prefix, e.g. processing, completed, cancelled.' ),
							'note'     => Schema::string( 'Order note to record alongside the change.' ),
						),
						array( 'order_id', 'status' )
					)
				)
				->run( array( $this, 'update_order_status' ) )
		);

		$registry->add(
			$this->tool( 'wc_sales_report' )
				->describe( 'Summarise sales over a date range: order count, gross and net revenue, average order value, and the best-selling products. Use this instead of writing SQL against the order tables.', 'Sales report' )
				->scope( 'woo:read' )
				->cap( 'view_woocommerce_reports' )
				->read_only()
				->available_when( $available )
				->input(
					Schema::object(
						array(
							'after'  => Schema::string( 'Start date, YYYY-MM-DD.' ),
							'before' => Schema::string( 'End date, YYYY-MM-DD. Defaults to today.' ),
							'top'    => Schema::integer( 'How many best sellers to include.', array( 'default' => 10, 'minimum' => 1, 'maximum' => 50 ) ),
						),
						array( 'after' )
					)
				)
				->run( array( $this, 'sales_report' ) )
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function products( array $args ) {
		$per_page = isset( $args['per_page'] ) ? (int) $args['per_page'] : 20;
		$page     = isset( $args['page'] ) ? (int) $args['page'] : 1;

		$query = array(
			'limit'   => $per_page,
			'page'    => $page,
			'paginate'=> true,
			'status'  => isset( $args['status'] ) && 'any' !== $args['status'] ? $args['status'] : array( 'publish', 'pending', 'draft', 'private' ),
		);

		if ( ! empty( $args['search'] ) ) {
			$query['s'] = $args['search'];
		}
		if ( ! empty( $args['sku'] ) ) {
			$query['sku'] = $args['sku'];
		}
		if ( ! empty( $args['category'] ) ) {
			$query['category'] = array( $args['category'] );
		}
		if ( ! empty( $args['stock_status'] ) && 'any' !== $args['stock_status'] ) {
			$query['stock_status'] = $args['stock_status'];
		}
		if ( ! empty( $args['type'] ) && 'any' !== $args['type'] ) {
			$query['type'] = $args['type'];
		}

		$results = wc_get_products( $query );

		$items = array();

		foreach ( $results->products as $product ) {
			$items[] = $this->summarise_product( $product );
		}

		return $this->paged( $items, (int) $results->total, $page, $per_page, array( 'currency' => get_woocommerce_currency() ) );
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function get_product( array $args ) {
		$product = null;

		if ( ! empty( $args['product_id'] ) ) {
			$product = wc_get_product( (int) $args['product_id'] );
		} elseif ( ! empty( $args['sku'] ) ) {
			$id = wc_get_product_id_by_sku( $args['sku'] );

			if ( $id ) {
				$product = wc_get_product( $id );
			}
		}

		if ( ! $product ) {
			return $this->fail( __( 'No product matched. Pass product_id or sku, or search with wc_products.', 'kai-vibe' ) );
		}

		$data = $this->summarise_product( $product );

		$data['description']       = $product->get_description();
		$data['short_description'] = $product->get_short_description();
		$data['weight']            = $product->get_weight();
		$data['dimensions']        = array(
			'length' => $product->get_length(),
			'width'  => $product->get_width(),
			'height' => $product->get_height(),
		);
		$data['categories']        = wp_get_post_terms( $product->get_id(), 'product_cat', array( 'fields' => 'slugs' ) );
		$data['tags']              = wp_get_post_terms( $product->get_id(), 'product_tag', array( 'fields' => 'slugs' ) );
		$data['images']            = array_map( 'intval', array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) );
		$data['total_sales']       = (int) $product->get_total_sales();

		$attributes = array();

		foreach ( $product->get_attributes() as $key => $attribute ) {
			// WC_Product_Variation overrides this prop with plain name => value
			// strings, so calling ->get_name() on it is a fatal.
			if ( ! $attribute instanceof \WC_Product_Attribute ) {
				$attributes[ $key ] = $attribute;
				continue;
			}

			$attributes[ $attribute->get_name() ] = $attribute->is_taxonomy()
				? wp_get_post_terms( $product->get_id(), $attribute->get_name(), array( 'fields' => 'names' ) )
				: $attribute->get_options();
		}

		$data['attributes'] = $attributes;

		if ( $product->is_type( 'variable' ) ) {
			$variations = array();

			foreach ( $product->get_children() as $child_id ) {
				$variation = wc_get_product( $child_id );

				if ( ! $variation ) {
					continue;
				}

				$variations[] = array(
					'id'         => $variation->get_id(),
					'sku'        => $variation->get_sku(),
					'attributes' => $variation->get_attributes(),
					'price'      => $variation->get_price(),
					'stock'      => $variation->get_stock_quantity(),
				);
			}

			$data['variations'] = $variations;
		}

		return $data;
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function update_product( array $args ) {
		$product = wc_get_product( (int) $args['product_id'] );

		if ( ! $product ) {
			return $this->fail( __( 'No product with that ID.', 'kai-vibe' ) );
		}

		if ( ! current_user_can( 'edit_post', $product->get_id() ) ) {
			return $this->fail( __( 'The connected user cannot edit that product.', 'kai-vibe' ) );
		}

		$before = $this->summarise_product( $product );

		if ( isset( $args['sku'] ) && $args['sku'] !== $product->get_sku() ) {
			$existing = wc_get_product_id_by_sku( $args['sku'] );

			if ( $existing && (int) $existing !== $product->get_id() ) {
				return $this->fail( __( 'Another product already uses that SKU.', 'kai-vibe' ) );
			}

			$product->set_sku( $args['sku'] );
		}

		$setters = array(
			'name'              => 'set_name',
			'regular_price'     => 'set_regular_price',
			'sale_price'        => 'set_sale_price',
			'description'       => 'set_description',
			'short_description' => 'set_short_description',
			'status'            => 'set_status',
			'stock_status'      => 'set_stock_status',
		);

		foreach ( $setters as $key => $setter ) {
			if ( isset( $args[ $key ] ) ) {
				$product->$setter( $args[ $key ] );
			}
		}

		if ( isset( $args['stock_quantity'] ) ) {
			$product->set_manage_stock( true );
			$product->set_stock_quantity( (int) $args['stock_quantity'] );
		}

		$product->save();

		if ( ! empty( $args['categories'] ) ) {
			wp_set_object_terms( $product->get_id(), (array) $args['categories'], 'product_cat', false );
		}

		// undo_change replays this through wp_update_post(), which can only put
		// back post-table fields. Price, SKU and stock live in CRUD/meta and
		// lookup tables, so say plainly that undo does not cover them.
		\KaiVibe\Security\Journal::record(
			\KaiVibe\Security\Journal::KIND_POST,
			$product->get_id(),
			sprintf( 'Updated product "%s"', $before['name'] ),
			array(
				'before' => array(
					'post_title'  => $before['name'],
					'post_status' => $before['status'],
				),
			)
		);

		return array(
			'updated' => true,
			'before'  => $before,
			'after'   => $this->summarise_product( wc_get_product( $product->get_id() ) ),
			'note'    => 'undo_change restores the name, status and short description only. Price and stock changes have to be re-set with wc_update_product.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function orders( array $args ) {
		$per_page = isset( $args['per_page'] ) ? (int) $args['per_page'] : 20;
		$page     = isset( $args['page'] ) ? (int) $args['page'] : 1;

		$query = array(
			'limit'    => $per_page,
			'page'     => $page,
			'paginate' => true,
			'orderby'  => 'date',
			'order'    => 'DESC',
		);

		if ( ! empty( $args['status'] ) ) {
			$query['status'] = 'wc-' . self::unprefix_status( $args['status'] );
		}
		if ( ! empty( $args['customer'] ) ) {
			$query['customer_id'] = (int) $args['customer'];
		}
		if ( ! empty( $args['search'] ) ) {
			$query['s'] = $args['search'];
		}

		if ( ! empty( $args['after'] ) || ! empty( $args['before'] ) ) {
			$after  = ! empty( $args['after'] ) ? $args['after'] : '1970-01-01';
			$before = ! empty( $args['before'] ) ? $args['before'] : gmdate( 'Y-m-d' );

			$query['date_created'] = $after . '...' . $before;
		}

		$results = wc_get_orders( $query );

		$items = array();

		foreach ( $results->orders as $order ) {
			$items[] = array(
				'id'       => $order->get_id(),
				'number'   => $order->get_order_number(),
				'status'   => $order->get_status(),
				'total'    => $order->get_total(),
				'currency' => $order->get_currency(),
				'customer' => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
				'email'    => $order->get_billing_email(),
				'items'    => $order->get_item_count(),
				'date'     => $order->get_date_created() ? $order->get_date_created()->format( 'c' ) : null,
			);
		}

		return $this->paged( $items, (int) $results->total, $page, $per_page );
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function get_order( array $args ) {
		$order = wc_get_order( (int) $args['order_id'] );

		if ( ! $order ) {
			return $this->fail( __( 'No order with that ID.', 'kai-vibe' ) );
		}

		$items = array();

		foreach ( $order->get_items() as $item ) {
			$items[] = array(
				'name'       => $item->get_name(),
				'product_id' => $item->get_product_id(),
				'quantity'   => $item->get_quantity(),
				'subtotal'   => $item->get_subtotal(),
				'total'      => $item->get_total(),
			);
		}

		$notes = array();

		foreach ( wc_get_order_notes( array( 'order_id' => $order->get_id(), 'limit' => 20 ) ) as $note ) {
			$notes[] = array(
				'date'     => $note->date_created ? $note->date_created->format( 'c' ) : null,
				'author'   => $note->added_by,
				'content'  => $note->content,
				'customer' => (bool) $note->customer_note,
			);
		}

		return array(
			'id'       => $order->get_id(),
			'number'   => $order->get_order_number(),
			'status'   => $order->get_status(),
			'created'  => $order->get_date_created() ? $order->get_date_created()->format( 'c' ) : null,
			'currency' => $order->get_currency(),
			'totals'   => array(
				'subtotal' => $order->get_subtotal(),
				'shipping' => $order->get_shipping_total(),
				'tax'      => $order->get_total_tax(),
				'discount' => $order->get_discount_total(),
				'total'    => $order->get_total(),
				'refunded' => $order->get_total_refunded(),
			),
			'payment'  => array(
				'method'        => $order->get_payment_method_title(),
				'transaction_id'=> $order->get_transaction_id(),
			),
			'billing'  => $order->get_address( 'billing' ),
			'shipping' => $order->get_address( 'shipping' ),
			'items'    => $items,
			'notes'    => $notes,
			'edit_url' => $order->get_edit_order_url(),
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function update_order_status( array $args ) {
		$order = wc_get_order( (int) $args['order_id'] );

		if ( ! $order ) {
			return $this->fail( __( 'No order with that ID.', 'kai-vibe' ) );
		}

		$status = self::unprefix_status( $args['status'] );

		if ( ! array_key_exists( 'wc-' . $status, wc_get_order_statuses() ) ) {
			return $this->fail(
				sprintf(
					/* translators: %s: list of statuses. */
					__( 'Unknown order status. Valid values: %s', 'kai-vibe' ),
					implode( ', ', array_map( static function ( $key ) {
						return self::unprefix_status( $key );
					}, array_keys( wc_get_order_statuses() ) ) )
				)
			);
		}

		$previous = $order->get_status();

		$order->update_status( $status, isset( $args['note'] ) ? $args['note'] : '', true );

		return array(
			'updated' => true,
			'order'   => $order->get_id(),
			'from'    => $previous,
			'to'      => $status,
			'note'    => 'WooCommerce will have sent whatever emails this status change triggers.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function sales_report( array $args ) {
		$after  = $args['after'];
		$before = isset( $args['before'] ) ? $args['before'] : gmdate( 'Y-m-d' );
		$top    = isset( $args['top'] ) ? (int) $args['top'] : 10;

		$orders = wc_get_orders(
			array(
				'limit'        => -1,
				'status'       => array( 'wc-processing', 'wc-completed', 'wc-on-hold' ),
				'date_created' => $after . '...' . $before,
			)
		);

		$gross    = 0.0;
		$refunded = 0.0;
		$products = array();

		foreach ( $orders as $order ) {
			$gross    += (float) $order->get_total();
			$refunded += (float) $order->get_total_refunded();

			foreach ( $order->get_items() as $item ) {
				$name = $item->get_name();

				if ( ! isset( $products[ $name ] ) ) {
					$products[ $name ] = array( 'name' => $name, 'quantity' => 0, 'revenue' => 0.0 );
				}

				$products[ $name ]['quantity'] += (int) $item->get_quantity();
				$products[ $name ]['revenue']  += (float) $item->get_total();
			}
		}

		usort(
			$products,
			static function ( $a, $b ) {
				return $b['revenue'] <=> $a['revenue'];
			}
		);

		$count = count( $orders );

		return array(
			'period'    => array( 'from' => $after, 'to' => $before ),
			'currency'  => get_woocommerce_currency(),
			'orders'    => $count,
			'gross'     => round( $gross, 2 ),
			'refunded'  => round( $refunded, 2 ),
			'net'       => round( $gross - $refunded, 2 ),
			'average'   => $count ? round( $gross / $count, 2 ) : 0,
			'best_sellers' => array_slice( array_values( $products ), 0, $top ),
			'note'      => 'Counts processing, completed and on-hold orders. Cancelled, failed and pending orders are excluded.',
		);
	}

	/**
	 * Strip the "wc-" prefix from an order status.
	 *
	 * ltrim() takes a character mask rather than a prefix, so ltrim( 'completed',
	 * 'wc-' ) returns 'ompleted'. That silently broke every status filter and
	 * every status update for the statuses starting with w, c or -.
	 *
	 * @param string $status Status with or without the prefix.
	 * @return string
	 */
	private static function unprefix_status( $status ) {
		$status = (string) $status;

		return 0 === strpos( $status, 'wc-' ) ? substr( $status, 3 ) : $status;
	}

	/**
	 * @param \WC_Product $product Product.
	 * @return array
	 */
	private function summarise_product( $product ) {
		return array(
			'id'             => $product->get_id(),
			'name'           => $product->get_name(),
			'sku'            => $product->get_sku(),
			'type'           => $product->get_type(),
			'status'         => $product->get_status(),
			'price'          => $product->get_price(),
			'regular_price'  => $product->get_regular_price(),
			'sale_price'     => $product->get_sale_price(),
			'on_sale'        => $product->is_on_sale(),
			'stock_status'   => $product->get_stock_status(),
			'stock_quantity' => $product->get_stock_quantity(),
			'manage_stock'   => $product->get_manage_stock(),
			'url'            => $product->get_permalink(),
			'edit_url'       => get_edit_post_link( $product->get_id(), 'raw' ),
		);
	}
}
