<?php
/**
 * Comments and the moderation queue.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Schema;
use KaiVibe\Mcp\ToolRegistry;
use KaiVibe\Support\Formatter;

defined( 'ABSPATH' ) || exit;

class CommentTools extends ToolPack {

	public function register( ToolRegistry $registry ) {

		$registry->add(
			$this->tool( 'list_comments' )
				->describe( 'List comments, optionally just the moderation queue or just spam. Sorting newest first by default.', 'List comments' )
				->scope( 'comments:read' )
				->cap( 'moderate_comments' )
				->read_only()
				->input(
					Schema::object(
						array(
							'status'   => Schema::enum( 'Which comments to return.', array( 'all', 'approve', 'hold', 'spam', 'trash' ), array( 'default' => 'all' ) ),
							'post_id'  => Schema::integer( 'Only comments on this post.' ),
							'search'   => Schema::string( 'Text to search for in comment content.' ),
							'per_page' => Schema::integer( 'Results per page.', array( 'default' => 25, 'minimum' => 1, 'maximum' => 100 ) ),
							'page'     => Schema::integer( 'Page number.', array( 'default' => 1, 'minimum' => 1 ) ),
						)
					)
				)
				->run( array( $this, 'list_comments' ) )
		);

		$registry->add(
			$this->tool( 'moderate_comment' )
				->describe( 'Approve, unapprove, spam, trash or restore a comment. Marking as spam trains the site\'s spam filter, so prefer it over trashing for genuine spam.', 'Moderate comment' )
				->scope( 'comments:write' )
				->cap( 'moderate_comments' )
				->input(
					Schema::object(
						array(
							'comment_id' => Schema::integer( 'Comment ID.' ),
							'action'     => Schema::enum( 'What to do.', array( 'approve', 'unapprove', 'spam', 'unspam', 'trash', 'untrash' ) ),
						),
						array( 'comment_id', 'action' )
					)
				)
				->run( array( $this, 'moderate_comment' ) )
		);

		$registry->add(
			$this->tool( 'reply_to_comment' )
				->describe( 'Post a reply to a comment as the connected user. The reply is published immediately, so read the thread first.', 'Reply to comment' )
				->scope( 'comments:write' )
				->cap( 'moderate_comments' )
				->input(
					Schema::object(
						array(
							'comment_id' => Schema::integer( 'Comment to reply to.' ),
							'content'    => Schema::string( 'Reply text.' ),
						),
						array( 'comment_id', 'content' )
					)
				)
				->run( array( $this, 'reply_to_comment' ) )
		);

		$registry->add(
			$this->tool( 'delete_comment' )
				->describe( 'Permanently delete a comment. Use moderate_comment with trash first unless you are certain.', 'Delete comment' )
				->scope( 'comments:write' )
				->cap( 'moderate_comments' )
				->destructive( true )
				->gated()
				->input(
					Schema::object(
						array(
							'comment_id' => Schema::integer( 'Comment ID.' ),
						),
						array( 'comment_id' )
					)
				)
				->run( array( $this, 'delete_comment' ) )
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function list_comments( array $args ) {
		$per_page = isset( $args['per_page'] ) ? (int) $args['per_page'] : 25;
		$page     = isset( $args['page'] ) ? (int) $args['page'] : 1;

		$query_args = array(
			'status'  => isset( $args['status'] ) ? $args['status'] : 'all',
			'number'  => $per_page,
			'offset'  => ( $page - 1 ) * $per_page,
			'orderby' => 'comment_date_gmt',
			'order'   => 'DESC',
		);

		if ( ! empty( $args['post_id'] ) ) {
			$query_args['post_id'] = (int) $args['post_id'];
		}
		if ( ! empty( $args['search'] ) ) {
			$query_args['search'] = $args['search'];
		}

		$query    = new \WP_Comment_Query();
		$comments = $query->query( $query_args );

		$total = (int) ( new \WP_Comment_Query() )->query( array_merge( $query_args, array( 'count' => true, 'number' => 0, 'offset' => 0 ) ) );

		$items = array();
		foreach ( $comments as $comment ) {
			$items[] = Formatter::comment( $comment );
		}

		$counts = wp_count_comments();

		return $this->paged(
			$items,
			$total,
			$page,
			$per_page,
			array(
				'queue' => array(
					'awaiting_moderation' => (int) $counts->moderated,
					'approved'            => (int) $counts->approved,
					'spam'                => (int) $counts->spam,
					'trash'               => (int) $counts->trash,
				),
			)
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function moderate_comment( array $args ) {
		$comment = get_comment( (int) $args['comment_id'] );

		if ( ! $comment ) {
			return $this->fail( __( 'No comment with that ID.', 'kai-vibe' ) );
		}

		if ( ! current_user_can( 'edit_comment', $comment->comment_ID ) ) {
			return $this->fail( __( 'The connected user cannot moderate that comment.', 'kai-vibe' ) );
		}

		switch ( $args['action'] ) {
			case 'approve':
				wp_set_comment_status( $comment->comment_ID, 'approve' );
				break;
			case 'unapprove':
				wp_set_comment_status( $comment->comment_ID, 'hold' );
				break;
			case 'spam':
				wp_spam_comment( $comment->comment_ID );
				break;
			case 'unspam':
				wp_unspam_comment( $comment->comment_ID );
				break;
			case 'trash':
				wp_trash_comment( $comment->comment_ID );
				break;
			case 'untrash':
				wp_untrash_comment( $comment->comment_ID );
				break;
		}

		return array(
			'moderated' => true,
			'action'    => $args['action'],
			'comment'   => Formatter::comment( get_comment( $comment->comment_ID ) ),
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function reply_to_comment( array $args ) {
		$parent = get_comment( (int) $args['comment_id'] );

		if ( ! $parent ) {
			return $this->fail( __( 'No comment with that ID.', 'kai-vibe' ) );
		}

		$user = wp_get_current_user();

		$comment_id = wp_insert_comment(
			array(
				'comment_post_ID'      => $parent->comment_post_ID,
				'comment_parent'       => $parent->comment_ID,
				'comment_content'      => wp_slash( $args['content'] ),
				'comment_author'       => $user->display_name,
				'comment_author_email' => $user->user_email,
				'comment_author_url'   => $user->user_url,
				'user_id'              => $user->ID,
				'comment_approved'     => 1,
			)
		);

		if ( ! $comment_id ) {
			return $this->fail( __( 'WordPress refused to save the reply.', 'kai-vibe' ) );
		}

		return array(
			'replied' => true,
			'comment' => Formatter::comment( get_comment( $comment_id ) ),
			'note'    => 'The reply is live and attributed to the connected user.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function delete_comment( array $args ) {
		$comment = get_comment( (int) $args['comment_id'] );

		if ( ! $comment ) {
			return $this->fail( __( 'No comment with that ID.', 'kai-vibe' ) );
		}

		if ( ! current_user_can( 'edit_comment', $comment->comment_ID ) ) {
			return $this->fail( __( 'The connected user cannot delete that comment.', 'kai-vibe' ) );
		}

		$author = $comment->comment_author;

		wp_delete_comment( $comment->comment_ID, true );

		return array( 'deleted' => true, 'author' => $author );
	}
}
