<?php
/**
 * WP-CLI passthrough.
 *
 * Off by default. When it is on, every command is checked against a denylist,
 * run with a timeout, and gated behind an approval — this is the single most
 * powerful tool in the plugin and it deserves the friction.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Schema;
use KaiVibe\Mcp\ToolRegistry;

defined( 'ABSPATH' ) || exit;

class CliTools extends ToolPack {

	public function register( ToolRegistry $registry ) {

		$registry->add(
			$this->tool( 'run_wp_cli' )
				->describe(
					'Run a WP-CLI command on the server. Reach for this only when no specific tool covers what you need — the dedicated tools fire WordPress hooks and keep caches correct, and raw CLI can bypass both. Do not include the leading "wp". Commands that destroy data are refused outright.',
					'Run WP-CLI'
				)
				->scope( 'cli:run' )
				->cap( 'manage_options' )
				->gated()
				->precheck( array( $this, 'check_command' ) )
				->available_when( array( __CLASS__, 'is_enabled' ) )
				->input(
					Schema::object(
						array(
							'command' => Schema::string( 'The command without "wp", e.g. "plugin list --status=active" or "cache flush".' ),
							'timeout' => Schema::integer( 'Seconds to allow before killing it. Defaults to the site setting.', array( 'minimum' => 1, 'maximum' => 600 ) ),
						),
						array( 'command' )
					)
				)
				->run( array( $this, 'run' ) )
		);

		$registry->add(
			$this->tool( 'wp_cli_status' )
				->describe( 'Report whether WP-CLI can run on this server and which commands are blocked. Call this before assuming run_wp_cli will work.', 'WP-CLI status' )
				->scope( 'site:read' )
				->read_only()
				->input( Schema::object() )
				->run( array( $this, 'status' ) )
		);
	}

	/**
	 * @return bool
	 */
	public static function is_enabled() {
		return (bool) kaiv_setting( 'cli_enabled', false ) && self::is_available();
	}

	/**
	 * Can this server shell out at all?
	 *
	 * @return bool
	 */
	public static function is_available() {
		if ( ! function_exists( 'proc_open' ) ) {
			return false;
		}

		$disabled = array_map( 'trim', explode( ',', (string) ini_get( 'disable_functions' ) ) );

		if ( in_array( 'proc_open', $disabled, true ) ) {
			return false;
		}

		return ! ini_get( 'safe_mode' );
	}

	/**
	 * @return array
	 */
	public function status() {
		$available = self::is_available();
		$enabled   = (bool) kaiv_setting( 'cli_enabled', false );

		$version = null;

		if ( $available && $enabled ) {
			$probe = $this->execute( '--version', 10 );

			if ( ! is_wp_error( $probe ) && 0 === $probe['exit_code'] ) {
				$version = trim( $probe['stdout'] );
			}
		}

		return array(
			'available'  => $available,
			'enabled'    => $enabled,
			'binary'     => kaiv_setting( 'cli_binary', 'wp' ),
			'version'    => $version,
			'denylist'   => (array) kaiv_setting( 'cli_denylist', array() ),
			'note'       => $available
				? ( $enabled ? 'Ready.' : 'WP-CLI works on this server but is switched off. Enable it under KAI Vibe → Settings.' )
				: 'This server does not allow PHP to start processes, so WP-CLI cannot be used. Use the dedicated tools instead.',
		);
	}

	/**
	 * Everything that makes a command unrunnable, settled before the approval
	 * gate so the owner is never asked to approve something we would refuse.
	 *
	 * @param array $args Arguments.
	 * @return \KaiVibe\Mcp\ToolResult|null
	 */
	public function check_command( array $args ) {
		if ( ! kaiv_setting( 'cli_enabled', false ) ) {
			return $this->fail( __( 'WP-CLI is switched off for this site. Turn it on under KAI Vibe → Settings if you want agents to use it.', 'kai-vibe' ) );
		}

		if ( ! self::is_available() ) {
			return $this->fail( __( 'This server does not allow PHP to start processes, so WP-CLI is unavailable here.', 'kai-vibe' ) );
		}

		$command = $this->normalise_command( isset( $args['command'] ) ? $args['command'] : '' );

		$blocked = $this->is_blocked( $command );

		if ( $blocked ) {
			return $this->fail(
				sprintf(
					/* translators: %s: blocked command fragment. */
					__( 'That command is on this site\'s denylist ("%s") and will not be run. Do not ask for approval — this cannot be granted.', 'kai-vibe' ),
					$blocked
				)
			);
		}

		// Shell metacharacters would let a command chain into something else.
		if ( preg_match( '/[;&|`$><\n\r]/', $command ) ) {
			return $this->fail( __( 'Shell operators are not allowed. Run one WP-CLI command at a time, without pipes or redirects.', 'kai-vibe' ) );
		}

		return null;
	}

	/**
	 * Strip a leading "wp" so both calling styles work.
	 *
	 * @param string $command Raw command.
	 * @return string
	 */
	private function normalise_command( $command ) {
		return (string) preg_replace( '/^wp\s+/i', '', trim( (string) $command ) );
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function run( array $args ) {
		$refusal = $this->check_command( $args );

		if ( $refusal ) {
			return $refusal;
		}

		$command = $this->normalise_command( $args['command'] );

		$timeout = isset( $args['timeout'] ) ? (int) $args['timeout'] : (int) kaiv_setting( 'cli_timeout', 120 );

		$result = $this->execute( $command, $timeout );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return array(
			'command'   => 'wp ' . $command,
			'exit_code' => $result['exit_code'],
			'stdout'    => $result['stdout'],
			'stderr'    => $result['stderr'],
			'timed_out' => $result['timed_out'],
			'note'      => 0 === $result['exit_code']
				? ''
				: 'Non-zero exit code — read stderr before assuming the command did anything.',
		);
	}

	/**
	 * @param string $command Command without "wp".
	 * @return string Matching denylist entry, or empty string.
	 */
	private function is_blocked( $command ) {
		$normalised = strtolower( trim( (string) preg_replace( '/\s+/', ' ', $command ) ) );

		// WP-CLI accepts global parameters and site aliases before the
		// subcommand, so "--path=/var/www db reset" has to be normalised down
		// to "db reset" before a prefix match means anything.
		while ( preg_match( '/^(?:--[^\s=]+(?:=\S*)?|@\S+)\s+/', $normalised, $leading ) ) {
			$normalised = substr( $normalised, strlen( $leading[0] ) );
		}

		foreach ( (array) kaiv_setting( 'cli_denylist', array() ) as $blocked ) {
			$blocked = strtolower( trim( (string) $blocked ) );

			if ( '' !== $blocked && 0 === strpos( $normalised, $blocked ) ) {
				return $blocked;
			}
		}

		return '';
	}

	/**
	 * Run the binary and capture both streams, killing it on timeout.
	 *
	 * @param string $command Arguments after "wp".
	 * @param int    $timeout Seconds.
	 * @return array|\WP_Error
	 */
	private function execute( $command, $timeout ) {
		$binary = (string) kaiv_setting( 'cli_binary', 'wp' );

		$parts = array(
			escapeshellcmd( $binary ),
			$command,
			'--path=' . escapeshellarg( ABSPATH ),
			'--no-color',
		);

		// Running as root is common in containers and WP-CLI refuses by default.
		if ( function_exists( 'posix_geteuid' ) && 0 === posix_geteuid() ) {
			$parts[] = '--allow-root';
		}

		$full = implode( ' ', $parts );

		$descriptors = array(
			0 => array( 'pipe', 'r' ),
			1 => array( 'pipe', 'w' ),
			2 => array( 'pipe', 'w' ),
		);

		$process = proc_open( $full, $descriptors, $pipes, ABSPATH, null );

		if ( ! is_resource( $process ) ) {
			return new \WP_Error( 'kaiv_cli_failed', __( 'Could not start WP-CLI. Check the binary path in the settings.', 'kai-vibe' ) );
		}

		fclose( $pipes[0] );
		stream_set_blocking( $pipes[1], false );
		stream_set_blocking( $pipes[2], false );

		$stdout    = '';
		$stderr    = '';
		$deadline  = microtime( true ) + max( 1, $timeout );
		$timed_out = false;

		while ( true ) {
			$status = proc_get_status( $process );

			$stdout .= (string) stream_get_contents( $pipes[1] );
			$stderr .= (string) stream_get_contents( $pipes[2] );

			if ( ! $status['running'] ) {
				break;
			}

			if ( microtime( true ) > $deadline ) {
				$timed_out = true;
				proc_terminate( $process, 9 );
				break;
			}

			usleep( 50000 );
		}

		$stdout .= (string) stream_get_contents( $pipes[1] );
		$stderr .= (string) stream_get_contents( $pipes[2] );

		fclose( $pipes[1] );
		fclose( $pipes[2] );

		$exit_code = proc_close( $process );

		// Very long output is rarely useful in full and costs a lot of context.
		$limit = 100000;

		if ( strlen( $stdout ) > $limit ) {
			$stdout = substr( $stdout, 0, $limit ) . sprintf( "\n… [%d bytes truncated]", strlen( $stdout ) - $limit );
		}

		return array(
			'exit_code' => $timed_out ? 124 : $exit_code,
			'stdout'    => $stdout,
			'stderr'    => $stderr,
			'timed_out' => $timed_out,
		);
	}
}
