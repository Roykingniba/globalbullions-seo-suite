<?php
/**
 * Categories, tags and custom taxonomy terms.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Schema;
use KaiVibe\Mcp\ToolRegistry;
use KaiVibe\Security\Journal;
use KaiVibe\Support\Formatter;

defined( 'ABSPATH' ) || exit;

class TaxonomyTools extends ToolPack {

	public function register( ToolRegistry $registry ) {

		$registry->add(
			$this->tool( 'list_terms' )
				->describe( 'List terms in a taxonomy, with counts and hierarchy. Always call this before assigning categories or tags to a post — reusing an existing term beats creating a near-duplicate.', 'List terms' )
				->scope( 'content:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'taxonomy'   => Schema::string( 'Taxonomy slug, e.g. category, post_tag, product_cat.', array( 'default' => 'category' ) ),
							'search'     => Schema::string( 'Filter by name.' ),
							'parent'     => Schema::integer( 'Only children of this term ID.' ),
							'hide_empty' => Schema::boolean( 'Skip terms with no posts.', array( 'default' => false ) ),
							'per_page'   => Schema::integer( 'Results per page.', array( 'default' => 100, 'minimum' => 1, 'maximum' => 500 ) ),
							'page'       => Schema::integer( 'Page number.', array( 'default' => 1, 'minimum' => 1 ) ),
						)
					)
				)
				->run( array( $this, 'list_terms' ) )
		);

		$registry->add(
			$this->tool( 'create_term' )
				->describe( 'Create a term in a taxonomy. Check list_terms first; if a term with the same name exists this returns the existing one rather than making a duplicate.', 'Create term' )
				->scope( 'taxonomy:write' )
				->input(
					Schema::object(
						array(
							'taxonomy'    => Schema::string( 'Taxonomy slug.' ),
							'name'        => Schema::string( 'Term name.' ),
							'slug'        => Schema::string( 'Term slug. Generated from the name when omitted.' ),
							'parent'      => Schema::integer( 'Parent term ID, for hierarchical taxonomies.' ),
							'description' => Schema::string( 'Term description.' ),
						),
						array( 'taxonomy', 'name' )
					)
				)
				->run( array( $this, 'create_term' ) )
		);

		$registry->add(
			$this->tool( 'update_term' )
				->describe( 'Rename a term, change its slug, parent or description. The previous state is journalled.', 'Update term' )
				->scope( 'taxonomy:write' )
				->input(
					Schema::object(
						array(
							'term_id'     => Schema::integer( 'Term ID.' ),
							'name'        => Schema::string( 'New name.' ),
							'slug'        => Schema::string( 'New slug.' ),
							'parent'      => Schema::integer( 'New parent term ID. Pass 0 to move to the top level.' ),
							'description' => Schema::string( 'New description.' ),
						),
						array( 'term_id' )
					)
				)
				->run( array( $this, 'update_term' ) )
		);

		$registry->add(
			$this->tool( 'delete_term' )
				->describe( 'Delete a term. Posts are not deleted, they just lose the term. Deleting a parent term reassigns its children to its own parent.', 'Delete term' )
				->scope( 'taxonomy:write' )
				->destructive( true )
				->input(
					Schema::object(
						array(
							'term_id' => Schema::integer( 'Term ID.' ),
						),
						array( 'term_id' )
					)
				)
				->run( array( $this, 'delete_term' ) )
		);

		$registry->add(
			$this->tool( 'assign_terms' )
				->describe( 'Attach or detach terms on a post without touching anything else about it. Use append=true to add to what is already there rather than replacing it.', 'Assign terms' )
				->scope( 'taxonomy:write' )
				->input(
					Schema::object(
						array(
							'post_id'  => Schema::integer( 'Post ID.' ),
							'taxonomy' => Schema::string( 'Taxonomy slug.' ),
							'terms'    => Schema::arr( 'Term slugs, names or IDs.' ),
							'append'   => Schema::boolean( 'Add to the existing terms instead of replacing them.', array( 'default' => false ) ),
						),
						array( 'post_id', 'taxonomy', 'terms' )
					)
				)
				->run( array( $this, 'assign_terms' ) )
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function list_terms( array $args ) {
		$taxonomy = isset( $args['taxonomy'] ) ? $args['taxonomy'] : 'category';

		if ( ! taxonomy_exists( $taxonomy ) ) {
			return $this->fail(
				sprintf(
					/* translators: %s: taxonomy slug. */
					__( 'There is no taxonomy called "%s". Call list_taxonomies to see what exists.', 'kai-vibe' ),
					$taxonomy
				)
			);
		}

		$per_page = isset( $args['per_page'] ) ? (int) $args['per_page'] : 100;
		$page     = isset( $args['page'] ) ? (int) $args['page'] : 1;

		$query = array(
			'taxonomy'   => $taxonomy,
			'hide_empty' => ! empty( $args['hide_empty'] ),
			'number'     => $per_page,
			'offset'     => ( $page - 1 ) * $per_page,
			'orderby'    => 'name',
		);

		if ( ! empty( $args['search'] ) ) {
			$query['search'] = $args['search'];
		}
		if ( isset( $args['parent'] ) ) {
			$query['parent'] = (int) $args['parent'];
		}

		$terms = get_terms( $query );

		if ( is_wp_error( $terms ) ) {
			return $terms;
		}

		$total = wp_count_terms( array_merge( $query, array( 'number' => 0, 'offset' => 0 ) ) );

		return $this->paged(
			array_map( array( Formatter::class, 'term' ), $terms ),
			is_wp_error( $total ) ? count( $terms ) : (int) $total,
			$page,
			$per_page,
			array( 'taxonomy' => $taxonomy )
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function create_term( array $args ) {
		$taxonomy = $args['taxonomy'];

		if ( ! taxonomy_exists( $taxonomy ) ) {
			return $this->fail(
				sprintf(
					/* translators: %s: taxonomy slug. */
					__( 'There is no taxonomy called "%s".', 'kai-vibe' ),
					$taxonomy
				)
			);
		}

		$taxonomy_object = get_taxonomy( $taxonomy );

		if ( ! current_user_can( $taxonomy_object->cap->manage_terms ) ) {
			return $this->fail( __( 'The connected user cannot manage terms in that taxonomy.', 'kai-vibe' ) );
		}

		$existing = get_term_by( 'name', $args['name'], $taxonomy );

		if ( $existing ) {
			return array(
				'created' => false,
				'term'    => Formatter::term( $existing ),
				'note'    => 'A term with that name already exists, so it was reused rather than duplicated.',
			);
		}

		$term_args = array();

		if ( ! empty( $args['slug'] ) ) {
			$term_args['slug'] = sanitize_title( $args['slug'] );
		}
		if ( ! empty( $args['parent'] ) ) {
			$term_args['parent'] = (int) $args['parent'];
		}
		if ( isset( $args['description'] ) ) {
			$term_args['description'] = $args['description'];
		}

		$result = wp_insert_term( $args['name'], $taxonomy, $term_args );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$term = get_term( $result['term_id'] );

		return array( 'created' => true, 'term' => Formatter::term( $term ) );
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function update_term( array $args ) {
		$term = get_term( (int) $args['term_id'] );

		if ( ! $term || is_wp_error( $term ) ) {
			return $this->fail( __( 'No term with that ID.', 'kai-vibe' ) );
		}

		$taxonomy_object = get_taxonomy( $term->taxonomy );

		if ( ! current_user_can( $taxonomy_object->cap->edit_terms ) ) {
			return $this->fail( __( 'The connected user cannot edit terms in that taxonomy.', 'kai-vibe' ) );
		}

		Journal::record(
			Journal::KIND_TERM,
			$term->term_id,
			sprintf( 'Updated term "%s"', $term->name ),
			array(
				'before' => array(
					'name'        => $term->name,
					'slug'        => $term->slug,
					'parent'      => $term->parent,
					'description' => $term->description,
				),
			)
		);

		$changes = array();

		foreach ( array( 'name', 'description' ) as $field ) {
			if ( isset( $args[ $field ] ) ) {
				$changes[ $field ] = $args[ $field ];
			}
		}

		if ( isset( $args['slug'] ) ) {
			$changes['slug'] = sanitize_title( $args['slug'] );
		}
		if ( isset( $args['parent'] ) ) {
			$changes['parent'] = (int) $args['parent'];
		}

		if ( ! $changes ) {
			return $this->fail( __( 'Nothing to change — pass at least one of name, slug, parent or description.', 'kai-vibe' ) );
		}

		$result = wp_update_term( $term->term_id, $term->taxonomy, $changes );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return array( 'updated' => true, 'term' => Formatter::term( get_term( $term->term_id ) ) );
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function delete_term( array $args ) {
		$term = get_term( (int) $args['term_id'] );

		if ( ! $term || is_wp_error( $term ) ) {
			return $this->fail( __( 'No term with that ID.', 'kai-vibe' ) );
		}

		$taxonomy_object = get_taxonomy( $term->taxonomy );

		if ( ! current_user_can( $taxonomy_object->cap->delete_terms ) ) {
			return $this->fail( __( 'The connected user cannot delete terms in that taxonomy.', 'kai-vibe' ) );
		}

		$name  = $term->name;
		$count = (int) $term->count;

		$result = wp_delete_term( $term->term_id, $term->taxonomy );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// wp_delete_term() returns 0 for a taxonomy's default term and false
		// when the term is already gone. Neither is a WP_Error.
		if ( ! $result ) {
			return $this->fail( __( 'That term was not deleted. It is the default term for its taxonomy, so change the default first.', 'kai-vibe' ) );
		}

		return array(
			'deleted'         => true,
			'term'            => $name,
			'posts_untagged'  => $count,
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function assign_terms( array $args ) {
		$post = $this->require_post( $args['post_id'], 'edit_post' );

		if ( ! $post instanceof \WP_Post ) {
			return $post;
		}

		$taxonomy = $args['taxonomy'];

		if ( ! taxonomy_exists( $taxonomy ) ) {
			return $this->fail(
				sprintf(
					/* translators: %s: taxonomy slug. */
					__( 'There is no taxonomy called "%s".', 'kai-vibe' ),
					$taxonomy
				)
			);
		}

		if ( ! in_array( $taxonomy, get_object_taxonomies( $post->post_type ), true ) ) {
			return $this->fail(
				sprintf(
					/* translators: 1: taxonomy, 2: post type. */
					__( 'The %1$s taxonomy does not apply to the %2$s post type.', 'kai-vibe' ),
					$taxonomy,
					$post->post_type
				)
			);
		}

		$terms   = (array) $args['terms'];
		$numeric = $terms && count( array_filter( $terms, 'is_numeric' ) ) === count( $terms );

		$result = wp_set_object_terms(
			$post->ID,
			$numeric ? array_map( 'intval', $terms ) : $terms,
			$taxonomy,
			! empty( $args['append'] )
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return array(
			'assigned' => true,
			'post_id'  => $post->ID,
			'taxonomy' => $taxonomy,
			'terms'    => Formatter::post_terms( get_post( $post->ID ) ),
		);
	}
}
