<?php
/**
 * Users and roles.
 *
 * Password hashes and session tokens never leave the site, and every write is
 * gated — an agent that can silently create administrators is a backdoor.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Schema;
use KaiVibe\Mcp\ToolRegistry;
use KaiVibe\Support\Formatter;

defined( 'ABSPATH' ) || exit;

class UserTools extends ToolPack {

	public function register( ToolRegistry $registry ) {

		$registry->add(
			$this->tool( 'list_users' )
				->describe( 'List site users with their roles and post counts. Password hashes and session tokens are never returned.', 'List users' )
				->scope( 'users:read' )
				->cap( 'list_users' )
				->read_only()
				->input(
					Schema::object(
						array(
							'search'   => Schema::string( 'Match against login, email, display name or URL.' ),
							'role'     => Schema::string( 'Filter by role slug, e.g. administrator, editor, subscriber.' ),
							'orderby'  => Schema::enum( 'Sort field.', array( 'registered', 'display_name', 'post_count', 'login' ), array( 'default' => 'registered' ) ),
							'order'    => Schema::enum( 'Sort direction.', array( 'DESC', 'ASC' ), array( 'default' => 'DESC' ) ),
							'per_page' => Schema::integer( 'Results per page.', array( 'default' => 20, 'minimum' => 1, 'maximum' => 100 ) ),
							'page'     => Schema::integer( 'Page number.', array( 'default' => 1, 'minimum' => 1 ) ),
						)
					)
				)
				->run( array( $this, 'list_users' ) )
		);

		$registry->add(
			$this->tool( 'get_user' )
				->describe( 'Read one user by ID, login or email, including their roles and effective capabilities.', 'Get user' )
				->scope( 'users:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'user_id' => Schema::integer( 'User ID.' ),
							'login'   => Schema::string( 'Username, as an alternative to user_id.' ),
							'email'   => Schema::string( 'Email address, as an alternative to user_id.' ),
						)
					)
				)
				->run( array( $this, 'get_user' ) )
		);

		$registry->add(
			$this->tool( 'list_roles' )
				->describe( 'List the roles defined on this site and the capabilities each one grants. Read this before changing anyone\'s role.', 'List roles' )
				->scope( 'users:read' )
				->read_only()
				->input( Schema::object() )
				->run( array( $this, 'list_roles' ) )
		);

		$registry->add(
			$this->tool( 'create_user' )
				->describe(
					'Create a user account. WordPress generates the password and emails it to them — this tool will not accept or return a password. Creating an administrator always requires an approval.',
					'Create user'
				)
				->scope( 'users:write' )
				->cap( 'create_users' )
				->gated()
				->input(
					Schema::object(
						array(
							'login'        => Schema::string( 'Username. Cannot be changed later.' ),
							'email'        => Schema::string( 'Email address. Must be unique on the site.' ),
							'role'         => Schema::string( 'Role slug.', array( 'default' => 'subscriber' ) ),
							'display_name' => Schema::string( 'Public display name.' ),
							'first_name'   => Schema::string( 'First name.' ),
							'last_name'    => Schema::string( 'Last name.' ),
							'notify'       => Schema::boolean( 'Email the new user their credentials.', array( 'default' => true ) ),
						),
						array( 'login', 'email' )
					)
				)
				->run( array( $this, 'create_user' ) )
		);

		$registry->add(
			$this->tool( 'update_user' )
				->describe( 'Change a user\'s profile fields or role. Passwords cannot be set through this tool. Role changes require an approval.', 'Update user' )
				->scope( 'users:write' )
				->cap( 'edit_users' )
				->input(
					Schema::object(
						array(
							'user_id'      => Schema::integer( 'User ID.' ),
							'email'        => Schema::string( 'New email address.' ),
							'role'         => Schema::string( 'New role slug. Replaces existing roles.' ),
							'display_name' => Schema::string( 'New display name.' ),
							'first_name'   => Schema::string( 'New first name.' ),
							'last_name'    => Schema::string( 'New last name.' ),
							'url'          => Schema::string( 'New website URL.' ),
							'description'  => Schema::string( 'New biographical text.' ),
						),
						array( 'user_id' )
					)
				)
				->run( array( $this, 'update_user' ) )
		);

		$registry->add(
			$this->tool( 'delete_user' )
				->describe( 'Delete a user, optionally reassigning their content to someone else. Always gated. Reassign rather than orphaning content unless you have been told otherwise.', 'Delete user' )
				->scope( 'users:write' )
				->cap( 'delete_users' )
				->destructive( true )
				->gated()
				->input(
					Schema::object(
						array(
							'user_id'    => Schema::integer( 'User ID to delete.' ),
							'reassign_to'=> Schema::integer( 'User ID to reassign their posts to. Omit to delete their content too.' ),
						),
						array( 'user_id' )
					)
				)
				->run( array( $this, 'delete_user' ) )
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function list_users( array $args ) {
		$per_page = isset( $args['per_page'] ) ? (int) $args['per_page'] : 20;
		$page     = isset( $args['page'] ) ? (int) $args['page'] : 1;

		$query_args = array(
			'number'  => $per_page,
			'paged'   => $page,
			'orderby' => isset( $args['orderby'] ) ? $args['orderby'] : 'registered',
			'order'   => isset( $args['order'] ) ? $args['order'] : 'DESC',
		);

		if ( ! empty( $args['search'] ) ) {
			$query_args['search']         = '*' . $args['search'] . '*';
			$query_args['search_columns'] = array( 'user_login', 'user_email', 'display_name', 'user_url' );
		}

		if ( ! empty( $args['role'] ) ) {
			$query_args['role'] = $args['role'];
		}

		$query = new \WP_User_Query( $query_args );

		$items = array();
		foreach ( $query->get_results() as $user ) {
			$items[] = Formatter::user( $user );
		}

		return $this->paged( $items, (int) $query->get_total(), $page, $per_page );
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function get_user( array $args ) {
		$user = false;

		if ( ! empty( $args['user_id'] ) ) {
			$user = get_userdata( (int) $args['user_id'] );
		} elseif ( ! empty( $args['login'] ) ) {
			$user = get_user_by( 'login', $args['login'] );
		} elseif ( ! empty( $args['email'] ) ) {
			$user = get_user_by( 'email', $args['email'] );
		}

		if ( ! $user ) {
			return $this->fail( __( 'No user matched. Pass user_id, login or email.', 'kai-vibe' ) );
		}

		if ( ! current_user_can( 'list_users' ) && get_current_user_id() !== $user->ID ) {
			return $this->fail( __( 'The connected user may only read their own account.', 'kai-vibe' ) );
		}

		$data = Formatter::user( $user );

		// Only the capabilities that are actually granted; the false ones are noise.
		$data['capabilities'] = array_keys( array_filter( $user->allcaps ) );
		$data['description']  = $user->description;

		return $data;
	}

	/**
	 * @return array
	 */
	public function list_roles() {
		$roles = wp_roles()->roles;
		$out   = array();

		// count_users() is an uncached full scan; hoist it out of the loop.
		$counts = count_users();

		foreach ( $roles as $slug => $role ) {
			$out[ $slug ] = array(
				'name'         => $role['name'],
				'capabilities' => array_keys( array_filter( $role['capabilities'] ) ),
				'users'        => isset( $counts['avail_roles'][ $slug ] ) ? (int) $counts['avail_roles'][ $slug ] : 0,
			);
		}

		return $out;
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function create_user( array $args ) {
		$role = isset( $args['role'] ) ? $args['role'] : 'subscriber';

		if ( ! wp_roles()->is_role( $role ) ) {
			return $this->fail(
				sprintf(
					/* translators: %s: role slug. */
					__( 'There is no role called "%s". Call list_roles to see what exists.', 'kai-vibe' ),
					$role
				)
			);
		}

		// You cannot hand out more than you hold.
		if ( 'administrator' === $role && ! current_user_can( 'promote_users' ) ) {
			return $this->fail( __( 'The connected user cannot create administrators.', 'kai-vibe' ) );
		}

		if ( username_exists( $args['login'] ) ) {
			return $this->fail( __( 'That username is already taken.', 'kai-vibe' ) );
		}

		if ( email_exists( $args['email'] ) ) {
			return $this->fail( __( 'That email address already belongs to another account.', 'kai-vibe' ) );
		}

		$user_id = wp_insert_user(
			array(
				'user_login'   => sanitize_user( $args['login'] ),
				'user_email'   => sanitize_email( $args['email'] ),
				'user_pass'    => wp_generate_password( 24, true, true ),
				'role'         => $role,
				'display_name' => isset( $args['display_name'] ) ? $args['display_name'] : $args['login'],
				'first_name'   => isset( $args['first_name'] ) ? $args['first_name'] : '',
				'last_name'    => isset( $args['last_name'] ) ? $args['last_name'] : '',
			)
		);

		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}

		if ( ! isset( $args['notify'] ) || $args['notify'] ) {
			wp_new_user_notification( $user_id, null, 'user' );
		}

		return array(
			'created' => true,
			'user'    => Formatter::user( get_userdata( $user_id ) ),
			'note'    => 'A random password was generated and never exposed. The user should set their own via the reset link.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function update_user( array $args ) {
		$user = get_userdata( (int) $args['user_id'] );

		if ( ! $user ) {
			return $this->fail( __( 'No user with that ID.', 'kai-vibe' ) );
		}

		if ( ! current_user_can( 'edit_user', $user->ID ) ) {
			return $this->fail( __( 'The connected user cannot edit that account.', 'kai-vibe' ) );
		}

		$update = array( 'ID' => $user->ID );

		foreach ( array( 'display_name', 'first_name', 'last_name', 'description' ) as $field ) {
			if ( isset( $args[ $field ] ) ) {
				$update[ $field ] = $args[ $field ];
			}
		}

		if ( isset( $args['email'] ) ) {
			$existing = email_exists( $args['email'] );

			if ( $existing && (int) $existing !== $user->ID ) {
				return $this->fail( __( 'That email address already belongs to another account.', 'kai-vibe' ) );
			}

			$update['user_email'] = sanitize_email( $args['email'] );
		}

		if ( isset( $args['url'] ) ) {
			$update['user_url'] = esc_url_raw( $args['url'] );
		}

		// A role change is a privilege change, so it goes through the gate.
		if ( isset( $args['role'] ) && ! in_array( $args['role'], (array) $user->roles, true ) ) {
			if ( ! wp_roles()->is_role( $args['role'] ) ) {
				return $this->fail( __( 'That role does not exist.', 'kai-vibe' ) );
			}

			if ( ! current_user_can( 'promote_users' ) ) {
				return $this->fail( __( 'The connected user cannot change roles.', 'kai-vibe' ) );
			}

			$gate = \KaiVibe\Security\Approval::require_for(
				'update_user',
				array( 'user_id' => $user->ID, 'role' => $args['role'] )
			);

			if ( $gate ) {
				return $gate;
			}

			$update['role'] = $args['role'];
		}

		if ( count( $update ) < 2 ) {
			return $this->fail( __( 'Nothing to change.', 'kai-vibe' ) );
		}

		$result = wp_update_user( $update );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return array( 'updated' => true, 'user' => Formatter::user( get_userdata( $user->ID ) ) );
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function delete_user( array $args ) {
		require_once ABSPATH . 'wp-admin/includes/user.php';

		$user_id = (int) $args['user_id'];
		$user    = get_userdata( $user_id );

		if ( ! $user ) {
			return $this->fail( __( 'No user with that ID.', 'kai-vibe' ) );
		}

		if ( ! current_user_can( 'delete_user', $user_id ) ) {
			return $this->fail( __( 'The connected user cannot delete that account.', 'kai-vibe' ) );
		}

		if ( get_current_user_id() === $user_id ) {
			return $this->fail( __( 'This connection acts as that user, so deleting it would cut the connection. Do it from wp-admin instead.', 'kai-vibe' ) );
		}

		// wp_delete_user() only deletes the user's content when $reassign is
		// null. A literal 0 reassigns it to a non-existent author instead,
		// which hides it everywhere without deleting it.
		$reassign = isset( $args['reassign_to'] ) ? (int) $args['reassign_to'] : 0;
		$reassign = $reassign > 0 ? $reassign : null;

		if ( null !== $reassign && ! get_userdata( $reassign ) ) {
			return $this->fail( __( 'The reassign_to user does not exist.', 'kai-vibe' ) );
		}

		$login = $user->user_login;
		$posts = count_user_posts( $user_id );

		$result = wp_delete_user( $user_id, $reassign );

		if ( ! $result ) {
			return $this->fail( __( 'WordPress refused to delete that user.', 'kai-vibe' ) );
		}

		return array(
			'deleted'   => true,
			'login'     => $login,
			'posts'     => (int) $posts,
			'reassigned'=> $reassign ? $reassign : null,
		);
	}
}
