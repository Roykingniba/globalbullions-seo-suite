<?php
/**
 * Posts, pages and every custom post type.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Schema;
use KaiVibe\Mcp\ToolRegistry;
use KaiVibe\Security\Journal;
use KaiVibe\Security\ProtectedData;
use KaiVibe\Support\Builders;
use KaiVibe\Support\Formatter;

defined( 'ABSPATH' ) || exit;

class ContentTools extends ToolPack {

	public function register( ToolRegistry $registry ) {

		$registry->add(
			$this->tool( 'find_content' )
				->describe(
					'Search and filter content of any post type. This is the main way to locate something before working on it: filter by type, status, search term, author, taxonomy term, parent, date range or slug, and sort however you need. Returns summaries, not full bodies — follow up with get_post for the ones you care about.',
					'Find content'
				)
				->scope( 'content:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'post_type'  => Schema::string( 'Post type slug, or "any" for all searchable types. Call list_post_types if unsure.', array( 'default' => 'post' ) ),
							'search'     => Schema::string( 'Free-text search across title and content.' ),
							'status'     => Schema::string( 'Status filter: publish, draft, pending, private, future, trash, or "any".', array( 'default' => 'any' ) ),
							'author'     => Schema::integer( 'Restrict to one author by user ID.' ),
							'parent'     => Schema::integer( 'Restrict to children of this post ID.' ),
							'slug'       => Schema::string( 'Exact slug (post_name) match.' ),
							'taxonomy'   => Schema::string( 'Taxonomy to filter on, used together with "terms".' ),
							'terms'      => Schema::arr( 'Term slugs or IDs to filter by within "taxonomy".' ),
							'meta_key'   => Schema::string( 'Meta key to filter on, used together with "meta_value".' ),
							'meta_value' => Schema::string( 'Meta value to match.' ),
							'after'      => Schema::string( 'Only posts published after this date (YYYY-MM-DD).' ),
							'before'     => Schema::string( 'Only posts published before this date (YYYY-MM-DD).' ),
							'orderby'    => Schema::enum( 'Sort field.', array( 'date', 'modified', 'title', 'menu_order', 'comment_count', 'rand', 'relevance' ), array( 'default' => 'date' ) ),
							'order'      => Schema::enum( 'Sort direction.', array( 'DESC', 'ASC' ), array( 'default' => 'DESC' ) ),
							'per_page'   => Schema::integer( 'Results per page, 1-100.', array( 'default' => 20, 'minimum' => 1, 'maximum' => 100 ) ),
							'page'       => Schema::integer( 'Page number, 1-based.', array( 'default' => 1, 'minimum' => 1 ) ),
						)
					)
				)
				->run( array( $this, 'find_content' ) )
		);

		$registry->add(
			$this->tool( 'get_post' )
				->describe( 'Read one post in full: content, excerpt, status, template, featured image, taxonomy terms and meta. If a page builder owns the post, the response says so — read the layout with builder_get rather than trusting post_content.', 'Get post' )
				->scope( 'content:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'post_id'   => Schema::integer( 'Post ID.' ),
							'url'       => Schema::string( 'Alternatively, a URL on this site to resolve to a post.' ),
							'rendered'  => Schema::boolean( 'Also return the content with shortcodes and blocks rendered.', array( 'default' => false ) ),
						)
					)
				)
				->run( array( $this, 'get_post' ) )
		);

		$registry->add(
			$this->tool( 'create_post' )
				->describe(
					'Create a post of any type. Defaults to a draft on purpose — publish deliberately by passing status. Accepts taxonomy terms, meta, a featured image and a page template in one call. Returns the new ID and edit URL.',
					'Create post'
				)
				->scope( 'content:write' )
				->cap( 'edit_posts' )
				->input(
					Schema::object(
						array(
							'title'      => Schema::string( 'Post title.' ),
							'content'    => Schema::string( 'Post body. Use block markup for block themes, HTML otherwise.' ),
							'post_type'  => Schema::string( 'Post type slug.', array( 'default' => 'post' ) ),
							'status'     => Schema::enum( 'Post status.', array( 'draft', 'publish', 'pending', 'private', 'future' ), array( 'default' => 'draft' ) ),
							'excerpt'    => Schema::string( 'Hand-written excerpt.' ),
							'slug'       => Schema::string( 'URL slug. Generated from the title when omitted.' ),
							'author'     => Schema::integer( 'Author user ID. Defaults to the connected user.' ),
							'parent'     => Schema::integer( 'Parent post ID for hierarchical types.' ),
							'menu_order' => Schema::integer( 'Sort order for hierarchical types.' ),
							'date'       => Schema::string( 'Publish date, YYYY-MM-DD HH:MM:SS in site time. Required for status=future.' ),
							'template'   => Schema::string( 'Page template file, e.g. template-full-width.php.' ),
							'thumbnail'  => Schema::integer( 'Attachment ID to use as the featured image.' ),
							'terms'      => Schema::map( 'Taxonomy terms, e.g. {"category":["news"],"post_tag":["launch"]}. Slugs, names or IDs.' ),
							'meta'       => Schema::map( 'Meta fields to set, as key/value pairs.' ),
						),
						array( 'title' )
					)
				)
				->run( array( $this, 'create_post' ) )
		);

		$registry->add(
			$this->tool( 'update_post' )
				->describe(
					'Update an existing post. Only the fields you pass are changed. The previous state is journalled first, so undo_change can put it back. If a page builder owns the post, do not write post_content here — use builder_set.',
					'Update post'
				)
				->scope( 'content:write' )
				->input(
					Schema::object(
						array(
							'post_id'    => Schema::integer( 'Post ID to update.' ),
							'title'      => Schema::string( 'New title.' ),
							'content'    => Schema::string( 'New body.' ),
							'append'     => Schema::boolean( 'Append content to the existing body instead of replacing it.', array( 'default' => false ) ),
							'status'     => Schema::enum( 'New status.', array( 'draft', 'publish', 'pending', 'private', 'future', 'trash' ) ),
							'excerpt'    => Schema::string( 'New excerpt.' ),
							'slug'       => Schema::string( 'New slug.' ),
							'author'     => Schema::integer( 'New author user ID.' ),
							'parent'     => Schema::integer( 'New parent post ID.' ),
							'menu_order' => Schema::integer( 'New sort order.' ),
							'date'       => Schema::string( 'New publish date, YYYY-MM-DD HH:MM:SS.' ),
							'template'   => Schema::string( 'New page template file.' ),
							'thumbnail'  => Schema::integer( 'New featured image attachment ID. Pass 0 to remove.' ),
							'terms'      => Schema::map( 'Taxonomy terms to set. Replaces existing terms in each taxonomy given.' ),
							'meta'       => Schema::map( 'Meta fields to set.' ),
						),
						array( 'post_id' )
					)
				)
				->run( array( $this, 'update_post' ) )
		);

		$registry->add(
			$this->tool( 'delete_post' )
				->describe( 'Move a post to the trash, or delete it permanently. Trashing is reversible from wp-admin and is the default; permanent deletion is gated behind an approval.', 'Delete post' )
				->scope( 'content:write' )
				->destructive( true )
				->input(
					Schema::object(
						array(
							'post_id' => Schema::integer( 'Post ID.' ),
							'force'   => Schema::boolean( 'Delete permanently instead of trashing. Cannot be undone.', array( 'default' => false ) ),
						),
						array( 'post_id' )
					)
				)
				->run( array( $this, 'delete_post' ) )
		);

		$registry->add(
			$this->tool( 'get_post_meta' )
				->describe( 'Read post meta. Without a key, returns every non-protected key with large values summarised. With a key, returns that value in full — this is how you read big serialised fields such as builder layouts or ACF repeaters.', 'Get post meta' )
				->scope( 'content:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'post_id'  => Schema::integer( 'Post ID.' ),
							'meta_key' => Schema::string( 'A single meta key to read in full.' ),
						),
						array( 'post_id' )
					)
				)
				->run( array( $this, 'get_post_meta' ) )
		);

		$registry->add(
			$this->tool( 'set_post_meta' )
				->describe( 'Set or delete a single post meta value. The previous value is journalled. Builder caches are flushed afterwards, so this is safe to use for builder meta as well.', 'Set post meta' )
				->scope( 'content:write' )
				->input(
					Schema::object(
						array(
							'post_id'    => Schema::integer( 'Post ID.' ),
							'meta_key'   => Schema::string( 'Meta key.' ),
							'meta_value' => Schema::string( 'Value to store. JSON is decoded into an array when it parses cleanly.' ),
							'delete'     => Schema::boolean( 'Delete the key instead of setting it.', array( 'default' => false ) ),
						),
						array( 'post_id', 'meta_key' )
					)
				)
				->run( array( $this, 'set_post_meta' ) )
		);

		$registry->add(
			$this->tool( 'list_revisions' )
				->describe( 'List stored revisions for a post, newest first, with author and date. Pair with restore_revision to roll back a body you did not write.', 'List revisions' )
				->scope( 'content:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'post_id' => Schema::integer( 'Post ID.' ),
							'limit'   => Schema::integer( 'How many revisions to return.', array( 'default' => 10, 'minimum' => 1, 'maximum' => 50 ) ),
						),
						array( 'post_id' )
					)
				)
				->run( array( $this, 'list_revisions' ) )
		);

		$registry->add(
			$this->tool( 'restore_revision' )
				->describe( 'Restore a post to one of its revisions. Use list_revisions first to pick the right revision ID.', 'Restore revision' )
				->scope( 'content:write' )
				->destructive( true )
				->input(
					Schema::object(
						array(
							'revision_id' => Schema::integer( 'Revision ID from list_revisions.' ),
						),
						array( 'revision_id' )
					)
				)
				->run( array( $this, 'restore_revision' ) )
		);

		$registry->add(
			$this->tool( 'duplicate_post' )
				->describe( 'Copy a post, including its meta, taxonomy terms and builder layout, as a new draft. The safe way to experiment with a live page: duplicate it, rework the copy, then swap.', 'Duplicate post' )
				->scope( 'content:write' )
				->input(
					Schema::object(
						array(
							'post_id' => Schema::integer( 'Post ID to copy.' ),
							'title'   => Schema::string( 'Title for the copy. Defaults to the original with " (copy)" appended.' ),
							'status'  => Schema::enum( 'Status for the copy.', array( 'draft', 'private', 'pending' ), array( 'default' => 'draft' ) ),
						),
						array( 'post_id' )
					)
				)
				->run( array( $this, 'duplicate_post' ) )
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function find_content( array $args ) {
		$per_page = isset( $args['per_page'] ) ? (int) $args['per_page'] : 20;
		$page     = isset( $args['page'] ) ? (int) $args['page'] : 1;

		$query_args = array(
			'post_type'           => isset( $args['post_type'] ) ? $args['post_type'] : 'post',
			'post_status'         => isset( $args['status'] ) ? $args['status'] : 'any',
			'posts_per_page'      => $per_page,
			'paged'               => $page,
			'orderby'             => isset( $args['orderby'] ) ? $args['orderby'] : 'date',
			'order'               => isset( $args['order'] ) ? $args['order'] : 'DESC',
			'ignore_sticky_posts' => true,
			'no_found_rows'       => false,
			// Without this, an explicit post_status puts drafts, pending and
			// private posts into the query with no capability test at all.
			'perm'                => 'readable',
		);

		if ( 'any' === $query_args['post_type'] ) {
			$query_args['post_type'] = 'any';
		}

		if ( ! empty( $args['search'] ) ) {
			$query_args['s'] = $args['search'];
		}
		if ( ! empty( $args['author'] ) ) {
			$query_args['author'] = (int) $args['author'];
		}
		if ( isset( $args['parent'] ) ) {
			$query_args['post_parent'] = (int) $args['parent'];
		}
		if ( ! empty( $args['slug'] ) ) {
			$query_args['name'] = sanitize_title( $args['slug'] );
		}

		if ( ! empty( $args['taxonomy'] ) && ! empty( $args['terms'] ) ) {
			$terms   = (array) $args['terms'];
			$numeric = count( array_filter( $terms, 'is_numeric' ) ) === count( $terms );

			$query_args['tax_query'] = array(
				array(
					'taxonomy' => $args['taxonomy'],
					'field'    => $numeric ? 'term_id' : 'slug',
					'terms'    => $numeric ? array_map( 'intval', $terms ) : $terms,
				),
			);
		}

		if ( ! empty( $args['meta_key'] ) ) {
			$query_args['meta_key'] = $args['meta_key']; // phpcs:ignore WordPress.DB.SlowDBQuery

			if ( isset( $args['meta_value'] ) ) {
				$query_args['meta_value'] = $args['meta_value']; // phpcs:ignore WordPress.DB.SlowDBQuery
			}
		}

		if ( ! empty( $args['after'] ) || ! empty( $args['before'] ) ) {
			$date = array( 'inclusive' => true );

			if ( ! empty( $args['after'] ) ) {
				$date['after'] = $args['after'];
			}
			if ( ! empty( $args['before'] ) ) {
				$date['before'] = $args['before'];
			}

			$query_args['date_query'] = array( $date );
		}

		$query = new \WP_Query( $query_args );
		$items = array();

		foreach ( $query->posts as $post ) {
			// "perm" only covers private posts; drafts still need checking.
			if ( ! current_user_can( 'read_post', $post->ID ) ) {
				continue;
			}

			$items[] = Formatter::post( $post );
		}

		return $this->paged(
			$items,
			(int) $query->found_posts,
			$page,
			$per_page,
			empty( $items ) ? array( 'note' => 'Nothing matched. Widen the search, check the post_type with list_post_types, or set status to "any" — drafts are excluded by some filters.' ) : array()
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function get_post( array $args ) {
		$post_id = isset( $args['post_id'] ) ? (int) $args['post_id'] : 0;

		if ( ! $post_id && ! empty( $args['url'] ) ) {
			$post_id = url_to_postid( $args['url'] );

			if ( ! $post_id ) {
				return $this->fail(
					sprintf(
						/* translators: %s: URL. */
						__( 'Could not resolve %s to a post. Try find_content with a search term from the page title.', 'kai-vibe' ),
						$args['url']
					)
				);
			}
		}

		$post = $this->require_post( $post_id, 'read_post' );

		if ( ! $post instanceof \WP_Post ) {
			return $post;
		}

		$data = Formatter::post( $post, true );

		if ( ! empty( $args['rendered'] ) ) {
			$data['rendered'] = apply_filters( 'the_content', $post->post_content );
		}

		return $data;
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function create_post( array $args ) {
		$post_type = isset( $args['post_type'] ) ? $args['post_type'] : 'post';

		$type_object = get_post_type_object( $post_type );

		if ( ! $type_object ) {
			return $this->fail(
				sprintf(
					/* translators: %s: post type. */
					__( 'There is no post type called "%s". Call list_post_types to see what exists.', 'kai-vibe' ),
					$post_type
				)
			);
		}

		if ( ! current_user_can( $type_object->cap->create_posts ) ) {
			return $this->fail(
				sprintf(
					/* translators: %s: post type label. */
					__( 'The connected user cannot create %s.', 'kai-vibe' ),
					$type_object->labels->name
				)
			);
		}

		$postarr = array(
			'post_type'    => $post_type,
			'post_title'   => $args['title'],
			'post_content' => isset( $args['content'] ) ? $args['content'] : '',
			'post_status'  => isset( $args['status'] ) ? $args['status'] : 'draft',
			'post_excerpt' => isset( $args['excerpt'] ) ? $args['excerpt'] : '',
			'post_author'  => isset( $args['author'] ) ? (int) $args['author'] : get_current_user_id(),
		);

		if ( ! empty( $args['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( $args['slug'] );
		}
		if ( isset( $args['parent'] ) ) {
			$postarr['post_parent'] = (int) $args['parent'];
		}
		if ( isset( $args['menu_order'] ) ) {
			$postarr['menu_order'] = (int) $args['menu_order'];
		}
		if ( ! empty( $args['date'] ) ) {
			$postarr['post_date'] = $args['date'];
		}

		$post_id = wp_insert_post( wp_slash( $postarr ), true );

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		$this->apply_extras( $post_id, $args );

		// Journalled with an empty "before" so undo means "trash this".
		Journal::record(
			Journal::KIND_POST,
			$post_id,
			sprintf( 'Created %s "%s"', $post_type, $args['title'] ),
			array( 'before' => array( '__created' => true ) )
		);

		$post = get_post( $post_id );

		return array(
			'created'  => true,
			'post'     => Formatter::post( $post ),
			'edit_url' => get_edit_post_link( $post_id, 'raw' ),
			'note'     => 'publish' === $postarr['post_status']
				? 'This is live now.'
				: 'Saved as a draft. Call update_post with status=publish when it is ready.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function update_post( array $args ) {
		$post = $this->require_post( $args['post_id'], 'edit_post' );

		if ( ! $post instanceof \WP_Post ) {
			return $post;
		}

		$builder = Builders::detect_for_post( $post->ID );

		if ( $builder && isset( $args['content'] ) ) {
			return $this->fail(
				sprintf(
					/* translators: %s: builder name. */
					__( 'This post is built with %s, so writing post_content would be overwritten by the builder or break the layout. Read it with builder_get and write it with builder_set instead.', 'kai-vibe' ),
					Builders::label( $builder )
				),
				array( 'builder' => $builder, 'post_id' => $post->ID )
			);
		}

		// Capture the before-state for undo.
		Journal::record(
			Journal::KIND_POST,
			$post->ID,
			sprintf( 'Updated "%s"', $post->post_title ),
			array(
				'before' => array(
					'post_title'   => $post->post_title,
					'post_content' => $post->post_content,
					'post_excerpt' => $post->post_excerpt,
					'post_status'  => $post->post_status,
					'post_name'    => $post->post_name,
					'post_parent'  => $post->post_parent,
					'menu_order'   => $post->menu_order,
					'post_author'  => $post->post_author,
					'post_date'    => $post->post_date,
				),
			)
		);

		$postarr = array( 'ID' => $post->ID );

		if ( isset( $args['title'] ) ) {
			$postarr['post_title'] = $args['title'];
		}

		if ( isset( $args['content'] ) ) {
			$postarr['post_content'] = ! empty( $args['append'] )
				? $post->post_content . "\n\n" . $args['content']
				: $args['content'];
		}

		foreach ( array( 'excerpt' => 'post_excerpt', 'status' => 'post_status' ) as $arg => $field ) {
			if ( isset( $args[ $arg ] ) ) {
				$postarr[ $field ] = $args[ $arg ];
			}
		}

		// wp_update_post() overwrites post_date on a draft unless edit_date is
		// set, which silently publishes anything you try to schedule. It also
		// needs post_date_gmt, or the two columns drift apart.
		if ( isset( $args['date'] ) && '' !== $args['date'] ) {
			$postarr['post_date']     = $args['date'];
			$postarr['post_date_gmt'] = get_gmt_from_date( $args['date'] );
			$postarr['edit_date']     = true;
		}

		if ( isset( $args['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( $args['slug'] );
		}
		if ( isset( $args['author'] ) ) {
			$postarr['post_author'] = (int) $args['author'];
		}
		if ( isset( $args['parent'] ) ) {
			$postarr['post_parent'] = (int) $args['parent'];
		}
		if ( isset( $args['menu_order'] ) ) {
			$postarr['menu_order'] = (int) $args['menu_order'];
		}

		$result = wp_update_post( wp_slash( $postarr ), true );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$this->apply_extras( $post->ID, $args );

		Builders::flush( $post->ID );

		return array(
			'updated'  => true,
			'post'     => Formatter::post( get_post( $post->ID ) ),
			'changed'  => array_values( array_diff( array_keys( $postarr ), array( 'ID' ) ) ),
			'note'     => 'The previous version is journalled. Call list_changes to find it, or undo_change to revert.',
		);
	}

	/**
	 * Terms, meta, template and featured image — shared by create and update.
	 *
	 * @param int   $post_id Post id.
	 * @param array $args    Tool arguments.
	 */
	private function apply_extras( $post_id, array $args ) {
		if ( ! empty( $args['terms'] ) && is_array( $args['terms'] ) ) {
			foreach ( $args['terms'] as $taxonomy => $terms ) {
				if ( ! taxonomy_exists( $taxonomy ) ) {
					continue;
				}

				$terms   = (array) $terms;
				$numeric = $terms && count( array_filter( $terms, 'is_numeric' ) ) === count( $terms );

				wp_set_object_terms( $post_id, $numeric ? array_map( 'intval', $terms ) : $terms, $taxonomy, false );
			}
		}

		if ( ! empty( $args['meta'] ) && is_array( $args['meta'] ) ) {
			foreach ( $args['meta'] as $key => $value ) {
				if ( ProtectedData::is_protected_meta( $key ) ) {
					continue;
				}

				update_post_meta( $post_id, $key, wp_slash( $value ) );
			}
		}

		if ( isset( $args['template'] ) ) {
			update_post_meta( $post_id, '_wp_page_template', $args['template'] );
		}

		if ( isset( $args['thumbnail'] ) ) {
			$thumbnail = (int) $args['thumbnail'];

			if ( $thumbnail > 0 ) {
				set_post_thumbnail( $post_id, $thumbnail );
			} else {
				delete_post_thumbnail( $post_id );
			}
		}
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function delete_post( array $args ) {
		$post = $this->require_post( $args['post_id'], 'delete_post' );

		if ( ! $post instanceof \WP_Post ) {
			return $post;
		}

		$force = ! empty( $args['force'] );

		if ( $force ) {
			// Permanent deletion is the one content operation with no way back.
			$gate = \KaiVibe\Security\Approval::require_for(
				'delete_post',
				array( 'post_id' => $post->ID, 'force' => true )
			);

			if ( $gate ) {
				return $gate;
			}

			wp_delete_post( $post->ID, true );

			return array(
				'deleted'   => true,
				'permanent' => true,
				'post_id'   => $post->ID,
				'title'     => $post->post_title,
			);
		}

		wp_trash_post( $post->ID );

		return array(
			'trashed' => true,
			'post_id' => $post->ID,
			'title'   => $post->post_title,
			'note'    => 'Moved to the trash. Restore it with update_post and status=draft, or delete it for good with force=true.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function get_post_meta( array $args ) {
		$post = $this->require_post( $args['post_id'], 'edit_post' );

		if ( ! $post instanceof \WP_Post ) {
			return $post;
		}

		if ( ! empty( $args['meta_key'] ) ) {
			$key = $args['meta_key'];

			if ( ProtectedData::is_protected_meta( $key ) ) {
				return $this->fail( __( 'That meta key is protected and cannot be read over MCP.', 'kai-vibe' ) );
			}

			$value = get_post_meta( $post->ID, $key, true );

			return array(
				'post_id'    => $post->ID,
				'meta_key'   => $key,
				'meta_value' => $value,
				'exists'     => metadata_exists( 'post', $post->ID, $key ),
			);
		}

		return array(
			'post_id' => $post->ID,
			'meta'    => Formatter::post_meta( $post->ID ),
			'note'    => 'Values over 2 KB are summarised. Pass meta_key to read one in full.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function set_post_meta( array $args ) {
		$post = $this->require_post( $args['post_id'], 'edit_post' );

		if ( ! $post instanceof \WP_Post ) {
			return $post;
		}

		$key = $args['meta_key'];

		if ( ProtectedData::is_protected_meta( $key ) ) {
			return $this->fail( __( 'That meta key is protected and cannot be written over MCP.', 'kai-vibe' ) );
		}

		$before = get_post_meta( $post->ID, $key, true );

		Journal::record(
			Journal::KIND_META,
			$post->ID . ':' . $key,
			sprintf( 'Set meta %s on "%s"', $key, $post->post_title ),
			array(
				'before'   => metadata_exists( 'post', $post->ID, $key ) ? $before : null,
				'post_id'  => $post->ID,
				'meta_key' => $key,
			)
		);

		if ( ! empty( $args['delete'] ) ) {
			delete_post_meta( $post->ID, $key );
			Builders::flush( $post->ID );

			return array( 'deleted' => true, 'post_id' => $post->ID, 'meta_key' => $key );
		}

		$value = isset( $args['meta_value'] ) ? $args['meta_value'] : '';

		// A JSON object or array is almost always meant as structured data.
		if ( is_string( $value ) ) {
			$trimmed = trim( $value );

			if ( '' !== $trimmed && ( '{' === $trimmed[0] || '[' === $trimmed[0] ) ) {
				$decoded = json_decode( $trimmed, true );

				if ( JSON_ERROR_NONE === json_last_error() ) {
					$value = $decoded;
				}
			}
		}

		update_post_meta( $post->ID, $key, wp_slash( $value ) );

		Builders::flush( $post->ID );

		return array(
			'updated'  => true,
			'post_id'  => $post->ID,
			'meta_key' => $key,
			'note'     => 'Previous value journalled; undo_change can restore it.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function list_revisions( array $args ) {
		$post = $this->require_post( $args['post_id'], 'edit_post' );

		if ( ! $post instanceof \WP_Post ) {
			return $post;
		}

		$limit     = isset( $args['limit'] ) ? (int) $args['limit'] : 10;
		$revisions = wp_get_post_revisions( $post->ID, array( 'numberposts' => $limit ) );

		$items = array();

		foreach ( $revisions as $revision ) {
			$items[] = array(
				'id'          => $revision->ID,
				'date'        => get_gmt_from_date( $revision->post_date, 'c' ),
				'author'      => get_the_author_meta( 'display_name', $revision->post_author ),
				'title'       => $revision->post_title,
				'content_len' => strlen( $revision->post_content ),
				'autosave'    => wp_is_post_autosave( $revision ) ? true : false,
			);
		}

		return array(
			'post_id'   => $post->ID,
			'revisions' => $items,
			'note'      => $items ? '' : 'No revisions stored. The site may have revisions disabled in wp-config.php.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function restore_revision( array $args ) {
		$revision = wp_get_post_revision( (int) $args['revision_id'] );

		if ( ! $revision ) {
			return $this->fail( __( 'No revision with that ID. Call list_revisions first.', 'kai-vibe' ) );
		}

		if ( ! current_user_can( 'edit_post', $revision->post_parent ) ) {
			return $this->fail( __( 'The connected user cannot edit that post.', 'kai-vibe' ) );
		}

		$parent = get_post( $revision->post_parent );

		if ( ! $parent ) {
			return $this->fail( __( 'That revision has no parent post left to restore into.', 'kai-vibe' ) );
		}

		Journal::record(
			Journal::KIND_POST,
			$parent->ID,
			sprintf( 'Restored revision %d of "%s"', $revision->ID, $parent->post_title ),
			array(
				'before' => array(
					'post_title'   => $parent->post_title,
					'post_content' => $parent->post_content,
					'post_excerpt' => $parent->post_excerpt,
				),
			)
		);

		wp_restore_post_revision( $revision->ID );

		return array(
			'restored'    => true,
			'post_id'     => $parent->ID,
			'revision_id' => $revision->ID,
			'post'        => Formatter::post( get_post( $parent->ID ) ),
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function duplicate_post( array $args ) {
		$post = $this->require_post( $args['post_id'], 'edit_post' );

		if ( ! $post instanceof \WP_Post ) {
			return $post;
		}

		$title = isset( $args['title'] ) && '' !== $args['title']
			? $args['title']
			: $post->post_title . ' (copy)';

		$new_id = wp_insert_post(
			wp_slash(
				array(
					'post_type'      => $post->post_type,
					'post_title'     => $title,
					'post_content'   => $post->post_content,
					'post_excerpt'   => $post->post_excerpt,
					'post_status'    => isset( $args['status'] ) ? $args['status'] : 'draft',
					'post_author'    => get_current_user_id(),
					'post_parent'    => $post->post_parent,
					'menu_order'     => $post->menu_order,
					'comment_status' => $post->comment_status,
					'ping_status'    => $post->ping_status,
				)
			),
			true
		);

		if ( is_wp_error( $new_id ) ) {
			return $new_id;
		}

		// Meta carries the builder layout, ACF fields, SEO data and the rest.
		foreach ( get_post_meta( $post->ID ) as $key => $values ) {
			if ( ProtectedData::is_protected_meta( $key ) || '_edit_lock' === $key || '_edit_last' === $key ) {
				continue;
			}

			foreach ( (array) $values as $value ) {
				add_post_meta( $new_id, $key, wp_slash( maybe_unserialize( $value ) ) );
			}
		}

		foreach ( get_object_taxonomies( $post->post_type ) as $taxonomy ) {
			$terms = wp_get_object_terms( $post->ID, $taxonomy, array( 'fields' => 'ids' ) );

			if ( ! is_wp_error( $terms ) && $terms ) {
				wp_set_object_terms( $new_id, $terms, $taxonomy );
			}
		}

		Journal::record(
			Journal::KIND_POST,
			$new_id,
			sprintf( 'Duplicated "%s"', $post->post_title ),
			array( 'before' => array( '__created' => true ) )
		);

		Builders::flush( $new_id );

		return array(
			'duplicated' => true,
			'source'     => $post->ID,
			'post'       => Formatter::post( get_post( $new_id ), false ),
			'edit_url'   => get_edit_post_link( $new_id, 'raw' ),
		);
	}
}
