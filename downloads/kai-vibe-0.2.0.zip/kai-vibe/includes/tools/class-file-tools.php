<?php
/**
 * Theme and plugin files.
 *
 * Every path goes through PathGuard, so the reachable filesystem is exactly
 * wp-content plus whatever extra roots the owner configured. Every write
 * journals the previous contents first.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Schema;
use KaiVibe\Mcp\Tool;
use KaiVibe\Mcp\ToolRegistry;
use KaiVibe\Security\Journal;
use KaiVibe\Security\PathGuard;

defined( 'ABSPATH' ) || exit;

class FileTools extends ToolPack {

	public function register( ToolRegistry $registry ) {

		$registry->add(
			$this->tool( 'list_files' )
				->describe( 'List a directory inside the allowed roots. Paths are relative to wp-content, so "themes/my-theme" is the usual starting point. Set recursive to walk the tree.', 'List files' )
				->scope( 'fs:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'path'      => Schema::string( 'Directory relative to wp-content. Empty lists wp-content itself.', array( 'default' => '' ) ),
							'recursive' => Schema::boolean( 'Walk subdirectories.', array( 'default' => false ) ),
							'pattern'   => Schema::string( 'Only files matching this glob, e.g. *.php or *.css.' ),
							'max'       => Schema::integer( 'Cap on how many entries to return.', array( 'default' => 200, 'minimum' => 1, 'maximum' => 2000 ) ),
						)
					)
				)
				->run( array( $this, 'list_files' ) )
		);

		$registry->add(
			$this->tool( 'read_file' )
				->describe( 'Read a text file. Line numbers are included so you can quote positions accurately. Use offset and limit on large files rather than pulling the whole thing.', 'Read file' )
				->scope( 'fs:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'path'   => Schema::string( 'File path relative to wp-content.' ),
							'offset' => Schema::integer( 'First line to return, 1-based.', array( 'default' => 1, 'minimum' => 1 ) ),
							'limit'  => Schema::integer( 'How many lines to return.', array( 'default' => 500, 'minimum' => 1, 'maximum' => 5000 ) ),
							'raw'    => Schema::boolean( 'Return the contents without line numbers.', array( 'default' => false ) ),
						),
						array( 'path' )
					)
				)
				->run( array( $this, 'read_file' ) )
		);

		$registry->add(
			$this->tool( 'write_file' )
				->describe(
					'Write a file, creating or overwriting it. Read it first if it exists — the previous contents are journalled, but blind overwrites still lose work. Writing PHP into an active theme takes effect on the next page load, so check your syntax.',
					'Write file'
				)
				->scope( 'fs:write' )
				->cap( 'edit_themes' )
				->gated()
				->precheck( array( $this, 'check_write' ) )
				->input(
					Schema::object(
						array(
							'path'    => Schema::string( 'File path relative to wp-content.' ),
							'content' => Schema::string( 'Full file contents.' ),
						),
						array( 'path', 'content' )
					)
				)
				->run( array( $this, 'write_file' ) )
		);

		$registry->add(
			$this->tool( 'edit_file' )
				->describe(
					'Replace an exact string in a file. Safer than write_file for a targeted change: the old text must appear exactly once, so a stale assumption fails loudly instead of silently mangling the file. Include enough surrounding context to make the match unique.',
					'Edit file'
				)
				->scope( 'fs:write' )
				->cap( 'edit_themes' )
				->gated()
				->precheck( array( $this, 'check_write' ) )
				->input(
					Schema::object(
						array(
							'path'        => Schema::string( 'File path relative to wp-content.' ),
							'old_string'  => Schema::string( 'Exact text to replace, including indentation.' ),
							'new_string'  => Schema::string( 'Replacement text.' ),
							'replace_all' => Schema::boolean( 'Replace every occurrence instead of requiring exactly one.', array( 'default' => false ) ),
						),
						array( 'path', 'old_string', 'new_string' )
					)
				)
				->run( array( $this, 'edit_file' ) )
		);

		$registry->add(
			$this->tool( 'search_files' )
				->describe( 'Search file contents across the allowed roots, like grep. Returns matching lines with their file and line number. This is how you find where a function, hook, class or string actually lives.', 'Search files' )
				->scope( 'fs:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'query'      => Schema::string( 'Text or regular expression to find.' ),
							'path'       => Schema::string( 'Directory to search, relative to wp-content.', array( 'default' => 'themes' ) ),
							'regex'      => Schema::boolean( 'Treat query as a regular expression.', array( 'default' => false ) ),
							'extensions' => Schema::arr( 'Limit to these file extensions, e.g. ["php","js"].' ),
							'max'        => Schema::integer( 'Maximum matches to return.', array( 'default' => 100, 'minimum' => 1, 'maximum' => 1000 ) ),
						),
						array( 'query' )
					)
				)
				->run( array( $this, 'search_files' ) )
		);

		$registry->add(
			$this->tool( 'delete_file' )
				->describe( 'Delete a file. The contents are journalled first, so undo_change can put it back. Gated.', 'Delete file' )
				->scope( 'fs:write' )
				->cap( 'edit_themes' )
				->destructive()
				->gated()
				->precheck(
					function ( array $args ) {
						$resolved = PathGuard::resolve( isset( $args['path'] ) ? $args['path'] : '' );

						if ( is_wp_error( $resolved ) ) {
							return $resolved;
						}

						if ( is_dir( $resolved ) ) {
							return $this->fail( __( 'That is a directory. This tool only deletes files.', 'kai-vibe' ) );
						}

						return null;
					}
				)
				->input(
					Schema::object(
						array(
							'path' => Schema::string( 'File path relative to wp-content.' ),
						),
						array( 'path' )
					)
				)
				->run( array( $this, 'delete_file' ) )
		);

		$registry->add(
			$this->tool( 'create_directory' )
				->describe( 'Create a directory, including any missing parents, inside the allowed roots.', 'Create directory' )
				->scope( 'fs:write' )
				->cap( 'edit_themes' )
				->input(
					Schema::object(
						array(
							'path' => Schema::string( 'Directory path relative to wp-content.' ),
						),
						array( 'path' )
					)
				)
				->run( array( $this, 'create_directory' ) )
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function list_files( array $args ) {
		$path     = isset( $args['path'] ) ? $args['path'] : '';
		$resolved = PathGuard::resolve( '' === $path ? '.' : $path );

		if ( is_wp_error( $resolved ) ) {
			return $resolved;
		}

		if ( ! is_dir( $resolved ) ) {
			return $this->fail(
				sprintf(
					/* translators: %s: path. */
					__( '%s is a file, not a directory. Read it with read_file.', 'kai-vibe' ),
					$path
				)
			);
		}

		$max     = isset( $args['max'] ) ? (int) $args['max'] : 200;
		$pattern = isset( $args['pattern'] ) ? $args['pattern'] : '';
		$entries = array();
		$truncated = false;

		if ( ! empty( $args['recursive'] ) ) {
			$iterator = new \RecursiveIteratorIterator(
				new \RecursiveDirectoryIterator( $resolved, \FilesystemIterator::SKIP_DOTS ),
				\RecursiveIteratorIterator::SELF_FIRST
			);
		} else {
			$iterator = new \FilesystemIterator( $resolved, \FilesystemIterator::SKIP_DOTS );
		}

		foreach ( $iterator as $item ) {
			if ( count( $entries ) >= $max ) {
				$truncated = true;
				break;
			}

			$name = $item->getFilename();

			// Skip the noise nobody wants to page through.
			if ( in_array( $name, array( '.git', 'node_modules', '.svn', '.DS_Store' ), true ) ) {
				continue;
			}

			if ( '' !== $pattern && $item->isFile() && ! $this->matches_pattern( $pattern, $name ) ) {
				continue;
			}

			// getMTime() throws on a broken symlink, which would fail the whole
			// listing over one stale link.
			$stattable = $item->isFile() || $item->isDir();

			$entries[] = array(
				'path'     => PathGuard::relative( $item->getPathname() ),
				'name'     => $name,
				'type'     => $item->isDir() ? 'dir' : 'file',
				'size'     => $item->isFile() ? $item->getSize() : null,
				'modified' => $stattable ? gmdate( 'c', $item->getMTime() ) : null,
				'writable' => $item->isWritable(),
			);
		}

		usort(
			$entries,
			static function ( $a, $b ) {
				if ( $a['type'] !== $b['type'] ) {
					return 'dir' === $a['type'] ? -1 : 1;
				}
				return strcmp( $a['path'], $b['path'] );
			}
		);

		return array(
			'path'      => PathGuard::relative( $resolved ),
			'entries'   => $entries,
			'count'     => count( $entries ),
			'truncated' => $truncated,
			'roots'     => PathGuard::relative_roots(),
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function read_file( array $args ) {
		$resolved = PathGuard::resolve( $args['path'] );

		if ( is_wp_error( $resolved ) ) {
			return $resolved;
		}

		if ( is_dir( $resolved ) ) {
			return $this->fail( __( 'That is a directory. Use list_files instead.', 'kai-vibe' ) );
		}

		if ( ! PathGuard::is_text( $resolved ) ) {
			return array(
				'path'   => PathGuard::relative( $resolved ),
				'binary' => true,
				'size'   => filesize( $resolved ),
				'note'   => 'This is a binary file, so its contents are not returned as text.',
			);
		}

		// A memory-exhaustion fatal here is not catchable and would take down
		// the whole REST request, so refuse oversized files up front.
		$size      = (int) filesize( $resolved );
		$max_bytes = (int) kaiv_setting( 'fs_max_bytes', 2 * MB_IN_BYTES );

		if ( $size > $max_bytes ) {
			return $this->fail(
				sprintf(
					/* translators: 1: file size, 2: size limit. */
					__( 'That file is %1$s, over the %2$s read limit. Use search_files to find the part you need.', 'kai-vibe' ),
					size_format( $size ),
					size_format( $max_bytes )
				)
			);
		}

		$contents = file_get_contents( $resolved ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		if ( false === $contents ) {
			return $this->fail( __( 'The file could not be read. Check its permissions.', 'kai-vibe' ) );
		}

		if ( ! empty( $args['raw'] ) ) {
			return array(
				'path'     => PathGuard::relative( $resolved ),
				'contents' => $contents,
				'bytes'    => strlen( $contents ),
			);
		}

		$lines  = preg_split( "/\r\n|\n|\r/", $contents );
		$total  = count( $lines );
		$offset = isset( $args['offset'] ) ? max( 1, (int) $args['offset'] ) : 1;
		$limit  = isset( $args['limit'] ) ? (int) $args['limit'] : 500;

		$slice = array_slice( $lines, $offset - 1, $limit );

		$numbered = array();
		foreach ( $slice as $index => $line ) {
			$numbered[] = sprintf( "%d\t%s", $offset + $index, $line );
		}

		return array(
			'path'        => PathGuard::relative( $resolved ),
			'total_lines' => $total,
			'from_line'   => $offset,
			'to_line'     => min( $total, $offset + count( $slice ) - 1 ),
			'contents'    => implode( "\n", $numbered ),
			'note'        => ( $offset + count( $slice ) - 1 ) < $total
				? sprintf( 'Truncated at line %d of %d. Call again with offset to continue.', $offset + count( $slice ) - 1, $total )
				: '',
		);
	}

	/**
	 * A path outside the jail, a blocked extension or an oversized body can
	 * never be written, so refuse before the approval gate rather than asking
	 * the owner to approve a write that would fail anyway.
	 *
	 * @param array $args Arguments.
	 * @return \KaiVibe\Mcp\ToolResult|\WP_Error|null
	 */
	public function check_write( array $args ) {
		$resolved = PathGuard::resolve_for_write( isset( $args['path'] ) ? $args['path'] : '' );

		if ( is_wp_error( $resolved ) ) {
			return $resolved;
		}

		$body = null;

		if ( isset( $args['content'] ) ) {
			$body = (string) $args['content'];
		} elseif ( isset( $args['new_string'] ) ) {
			$body = (string) $args['new_string'];
		}

		if ( null !== $body ) {
			$max_bytes = (int) kaiv_setting( 'fs_max_bytes', 2 * MB_IN_BYTES );

			if ( strlen( $body ) > $max_bytes ) {
				return $this->fail(
					sprintf(
						/* translators: %s: size limit. */
						__( 'That is larger than the %s write limit for this site.', 'kai-vibe' ),
						size_format( $max_bytes )
					)
				);
			}
		}

		return null;
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function write_file( array $args ) {
		$refusal = $this->check_write( $args );

		if ( $refusal ) {
			return Tool::normalise( $refusal );
		}

		$resolved = PathGuard::resolve_for_write( $args['path'] );
		$content  = (string) $args['content'];

		$existed = file_exists( $resolved );
		$before  = $existed ? file_get_contents( $resolved ) : null; // phpcs:ignore WordPress.WP.AlternativeFunctions

		// A PHP syntax error in an active theme takes the whole site down.
		$lint = $this->lint_php( $resolved, $content );

		if ( is_wp_error( $lint ) ) {
			return $lint;
		}

		Journal::record(
			Journal::KIND_FILE,
			PathGuard::relative( $resolved ),
			sprintf( '%s %s', $existed ? 'Overwrote' : 'Created', PathGuard::relative( $resolved ) ),
			array( 'before' => $before )
		);

		$written = file_put_contents( $resolved, $content ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		if ( false === $written ) {
			return $this->fail( __( 'The write failed. Check that the directory is writable by the web server.', 'kai-vibe' ) );
		}

		return array(
			'written' => true,
			'path'    => PathGuard::relative( $resolved ),
			'bytes'   => $written,
			'created' => ! $existed,
			'note'    => 'Previous contents journalled; undo_change can restore them.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function edit_file( array $args ) {
		$resolved = PathGuard::resolve( $args['path'] );

		if ( is_wp_error( $resolved ) ) {
			return $resolved;
		}

		$check = PathGuard::resolve_for_write( $args['path'] );

		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$before = file_get_contents( $resolved ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		if ( false === $before ) {
			return $this->fail( __( 'The file could not be read.', 'kai-vibe' ) );
		}

		$old = (string) $args['old_string'];
		$new = (string) $args['new_string'];

		if ( $old === $new ) {
			return $this->fail( __( 'old_string and new_string are identical, so there is nothing to change.', 'kai-vibe' ) );
		}

		$occurrences = substr_count( $before, $old );

		if ( 0 === $occurrences ) {
			return $this->fail(
				__( 'That exact text does not appear in the file. Read the file again — whitespace and indentation have to match precisely.', 'kai-vibe' ),
				array( 'path' => PathGuard::relative( $resolved ) )
			);
		}

		if ( $occurrences > 1 && empty( $args['replace_all'] ) ) {
			return $this->fail(
				sprintf(
					/* translators: %d: number of occurrences. */
					__( 'That text appears %d times. Include more surrounding context to make it unique, or pass replace_all=true.', 'kai-vibe' ),
					$occurrences
				),
				array( 'occurrences' => $occurrences )
			);
		}

		$after = empty( $args['replace_all'] )
			? $this->replace_first( $before, $old, $new )
			: str_replace( $old, $new, $before );

		$lint = $this->lint_php( $resolved, $after );

		if ( is_wp_error( $lint ) ) {
			return $lint;
		}

		Journal::record(
			Journal::KIND_FILE,
			PathGuard::relative( $resolved ),
			sprintf( 'Edited %s', PathGuard::relative( $resolved ) ),
			array( 'before' => $before )
		);

		$written = file_put_contents( $resolved, $after ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		if ( false === $written ) {
			return $this->fail( __( 'The write failed. Check file permissions.', 'kai-vibe' ) );
		}

		return array(
			'edited'       => true,
			'path'         => PathGuard::relative( $resolved ),
			'replacements' => empty( $args['replace_all'] ) ? 1 : $occurrences,
			'bytes'        => $written,
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function search_files( array $args ) {
		$root = PathGuard::resolve( isset( $args['path'] ) ? $args['path'] : 'themes' );

		if ( is_wp_error( $root ) ) {
			return $root;
		}

		$max        = isset( $args['max'] ) ? (int) $args['max'] : 100;
		$extensions = isset( $args['extensions'] ) ? array_map( 'strtolower', (array) $args['extensions'] ) : array();
		$is_regex   = ! empty( $args['regex'] );
		$query      = (string) $args['query'];

		if ( $is_regex ) {
			// Validate before walking the tree, so a bad pattern fails fast.
			if ( false === @preg_match( '#' . $query . '#', '' ) ) {
				return $this->fail( __( 'That is not a valid regular expression.', 'kai-vibe' ) );
			}
		}

		$matches   = array();
		$scanned   = 0;
		$truncated = false;

		$iterator = new \RecursiveIteratorIterator(
			new \RecursiveCallbackFilterIterator(
				new \RecursiveDirectoryIterator( $root, \FilesystemIterator::SKIP_DOTS ),
				static function ( $current ) {
					return ! in_array( $current->getFilename(), array( '.git', 'node_modules', 'vendor', '.svn' ), true );
				}
			)
		);

		foreach ( $iterator as $file ) {
			if ( count( $matches ) >= $max ) {
				$truncated = true;
				break;
			}

			if ( ! $file->isFile() || ! PathGuard::is_text( $file->getPathname() ) ) {
				continue;
			}

			$extension = strtolower( $file->getExtension() );

			if ( $extensions && ! in_array( $extension, $extensions, true ) ) {
				continue;
			}

			// Skip anything too big to be source code.
			if ( $file->getSize() > 2 * MB_IN_BYTES ) {
				continue;
			}

			// Only the search root went through PathGuard. A symlinked file
			// inside the root is yielded by the iterator and would otherwise be
			// read straight through to its target, outside the jail.
			$safe = PathGuard::resolve( $file->getPathname() );

			if ( is_wp_error( $safe ) ) {
				continue;
			}

			$scanned++;

			$handle = fopen( $safe, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions

			if ( ! $handle ) {
				continue;
			}

			$number = 0;

			while ( false !== ( $line = fgets( $handle ) ) ) {
				$number++;

				$hit = $is_regex
					? (bool) preg_match( '#' . $query . '#', $line )
					: ( false !== stripos( $line, $query ) );

				if ( ! $hit ) {
					continue;
				}

				$matches[] = array(
					'path' => PathGuard::relative( $file->getPathname() ),
					'line' => $number,
					'text' => rtrim( substr( $line, 0, 300 ) ),
				);

				if ( count( $matches ) >= $max ) {
					break;
				}
			}

			fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}

		return array(
			'query'         => $query,
			'matches'       => $matches,
			'files_scanned' => $scanned,
			'truncated'     => $truncated,
			'note'          => $matches ? '' : 'No matches. Try a shorter fragment, or widen the path — the default is themes only.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function delete_file( array $args ) {
		$resolved = PathGuard::resolve( $args['path'] );

		if ( is_wp_error( $resolved ) ) {
			return $resolved;
		}

		if ( is_dir( $resolved ) ) {
			return $this->fail( __( 'That is a directory. This tool only deletes files.', 'kai-vibe' ) );
		}

		$before = PathGuard::is_text( $resolved )
			? file_get_contents( $resolved ) // phpcs:ignore WordPress.WP.AlternativeFunctions
			: null;

		Journal::record(
			Journal::KIND_FILE,
			PathGuard::relative( $resolved ),
			sprintf( 'Deleted %s', PathGuard::relative( $resolved ) ),
			array( 'before' => $before )
		);

		wp_delete_file( $resolved );

		return array(
			'deleted' => ! file_exists( $resolved ),
			'path'    => PathGuard::relative( $resolved ),
			'note'    => null === $before ? 'Binary file — its contents were not journalled, so this cannot be undone.' : 'Contents journalled; undo_change can restore the file.',
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function create_directory( array $args ) {
		$resolved = PathGuard::resolve_for_write( rtrim( $args['path'], '/' ) . '/.keep' );

		if ( is_wp_error( $resolved ) ) {
			// resolve_for_write needs an existing parent; walk up to find one.
			$resolved = $this->resolve_new_directory( $args['path'] );

			if ( is_wp_error( $resolved ) ) {
				return $resolved;
			}
		} else {
			$resolved = dirname( $resolved );
		}

		if ( is_dir( $resolved ) ) {
			return array( 'created' => false, 'path' => PathGuard::relative( $resolved ), 'note' => 'Already exists.' );
		}

		if ( ! wp_mkdir_p( $resolved ) ) {
			return $this->fail( __( 'Could not create the directory. Check permissions on the parent.', 'kai-vibe' ) );
		}

		return array( 'created' => true, 'path' => PathGuard::relative( $resolved ) );
	}

	/**
	 * Work out the absolute path for a directory whose parents may not exist yet,
	 * while still refusing anything that would land outside the roots.
	 *
	 * @param string $path Requested path.
	 * @return string|\WP_Error
	 */
	private function resolve_new_directory( $path ) {
		$path = wp_normalize_path( trim( (string) $path ) );

		if ( '' === $path || false !== strpos( $path, "\0" ) || false !== strpos( $path, '..' ) ) {
			return new \WP_Error( 'kaiv_bad_path', __( 'That directory path is not acceptable.', 'kai-vibe' ) );
		}

		$is_absolute = ( 0 === strpos( $path, '/' ) ) || preg_match( '#^[A-Za-z]:/#', $path );
		$absolute    = $is_absolute ? $path : trailingslashit( wp_normalize_path( WP_CONTENT_DIR ) ) . ltrim( $path, '/' );

		foreach ( PathGuard::roots() as $root ) {
			if ( 0 === strpos( trailingslashit( $absolute ), $root ) ) {
				return untrailingslashit( $absolute );
			}
		}

		return new \WP_Error(
			'kaiv_outside_root',
			sprintf(
				/* translators: %s: allowed roots. */
				__( 'That path is outside the allowed roots (%s).', 'kai-vibe' ),
				implode( ', ', PathGuard::relative_roots() )
			)
		);
	}

	/**
	 * Glob matching. fnmatch() is missing on some Windows PHP builds, so fall
	 * back to translating the glob into a regular expression.
	 *
	 * @param string $pattern Glob pattern.
	 * @param string $name    Filename.
	 * @return bool
	 */
	private function matches_pattern( $pattern, $name ) {
		if ( function_exists( 'fnmatch' ) ) {
			return fnmatch( $pattern, $name );
		}

		$regex = '#^' . str_replace( array( '\*', '\?' ), array( '.*', '.' ), preg_quote( $pattern, '#' ) ) . '$#i';

		return (bool) preg_match( $regex, $name );
	}

	/**
	 * @param string $haystack Subject.
	 * @param string $needle   Search.
	 * @param string $replace  Replacement.
	 * @return string
	 */
	private function replace_first( $haystack, $needle, $replace ) {
		$position = strpos( $haystack, $needle );

		if ( false === $position ) {
			return $haystack;
		}

		return substr_replace( $haystack, $replace, $position, strlen( $needle ) );
	}

	/**
	 * Syntax-check PHP before it lands on disk.
	 *
	 * @param string $path    Target path, used to decide whether to lint.
	 * @param string $content Proposed contents.
	 * @return true|\WP_Error
	 */
	private function lint_php( $path, $content ) {
		if ( 'php' !== strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) ) {
			return true;
		}

		// PHP 7+ can parse without executing, which is exactly what is wanted.
		if ( ! function_exists( 'token_get_all' ) ) {
			return true;
		}

		try {
			// A parse error here throws rather than fataling the request.
			token_get_all( $content, TOKEN_PARSE );
		} catch ( \ParseError $e ) {
			return new \WP_Error(
				'kaiv_php_syntax',
				sprintf(
					/* translators: %s: parser message. */
					__( 'That PHP has a syntax error, so it was not written: %s', 'kai-vibe' ),
					$e->getMessage()
				),
				array( 'line' => $e->getLine() )
			);
		} catch ( \Throwable $e ) {
			// Anything else is not a reason to block the write.
			return true;
		}

		return true;
	}
}
