<?php
/**
 * Plugins and themes.
 *
 * Anything that installs code from outside the site, or takes code away, is
 * gated behind an approval. Deactivating this plugin itself is refused outright
 * — an agent should not be able to cut the branch it is sitting on.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Schema;
use KaiVibe\Mcp\ToolRegistry;
use KaiVibe\Support\SiteProfile;

defined( 'ABSPATH' ) || exit;

class ExtensionTools extends ToolPack {

	public function register( ToolRegistry $registry ) {

		$registry->add(
			$this->tool( 'list_plugins' )
				->describe( 'List installed plugins with version, activation state and available updates. The plugin "file" value (e.g. akismet/akismet.php) is the identifier the other plugin tools expect.', 'List plugins' )
				->scope( 'extensions:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'status' => Schema::enum( 'Filter by state.', array( 'all', 'active', 'inactive', 'update-available' ), array( 'default' => 'all' ) ),
							'search' => Schema::string( 'Match against plugin name or slug.' ),
						)
					)
				)
				->run( array( $this, 'list_plugins' ) )
		);

		$registry->add(
			$this->tool( 'list_themes' )
				->describe( 'List installed themes, which is active, parent/child relationships, and available updates.', 'List themes' )
				->scope( 'extensions:read' )
				->read_only()
				->input( Schema::object() )
				->run(
					function () {
						return SiteProfile::extensions()['themes'];
					}
				)
		);

		$registry->add(
			$this->tool( 'activate_plugin' )
				->describe( 'Activate an installed plugin. If activation triggers a fatal error WordPress rolls it back, and that error is returned to you rather than white-screening the site.', 'Activate plugin' )
				->scope( 'extensions:write' )
				->cap( 'activate_plugins' )
				->gated()
				->precheck( array( $this, 'check_plugin' ) )
				->input(
					Schema::object(
						array(
							'plugin' => Schema::string( 'Plugin file from list_plugins, e.g. akismet/akismet.php.' ),
						),
						array( 'plugin' )
					)
				)
				->run( array( $this, 'activate_plugin' ) )
		);

		$registry->add(
			$this->tool( 'deactivate_plugin' )
				->describe( 'Deactivate an active plugin. Useful for bisecting a conflict — deactivate, check the symptom, reactivate.', 'Deactivate plugin' )
				->scope( 'extensions:write' )
				->cap( 'activate_plugins' )
				->gated()
				->precheck( array( $this, 'check_plugin' ) )
				->input(
					Schema::object(
						array(
							'plugin' => Schema::string( 'Plugin file from list_plugins.' ),
						),
						array( 'plugin' )
					)
				)
				->run( array( $this, 'deactivate_plugin' ) )
		);

		$registry->add(
			$this->tool( 'install_plugin' )
				->describe(
					'Install a plugin from the WordPress.org directory by slug, or from a ZIP URL. Always gated: this runs third-party code on the site. Say what the plugin is and why it is needed when you ask for approval.',
					'Install plugin'
				)
				->scope( 'extensions:write' )
				->cap( 'install_plugins' )
				->gated()
				->input(
					Schema::object(
						array(
							'slug'     => Schema::string( 'WordPress.org plugin slug, e.g. classic-editor.' ),
							'zip_url'  => Schema::string( 'URL of a plugin ZIP, as an alternative to slug.' ),
							'activate' => Schema::boolean( 'Activate it once installed.', array( 'default' => false ) ),
						)
					)
				)
				->run( array( $this, 'install_plugin' ) )
		);

		$registry->add(
			$this->tool( 'update_extension' )
				->describe( 'Update a plugin or theme to its latest version. Take a backup first if the site is production — this replaces files on disk.', 'Update plugin or theme' )
				->scope( 'extensions:write' )
				->cap( 'update_plugins' )
				->gated()
				->input(
					Schema::object(
						array(
							'type'   => Schema::enum( 'What to update.', array( 'plugin', 'theme' ) ),
							'target' => Schema::string( 'Plugin file (akismet/akismet.php) or theme stylesheet (twentytwentyfour).' ),
						),
						array( 'type', 'target' )
					)
				)
				->run( array( $this, 'update_extension' ) )
		);

		$registry->add(
			$this->tool( 'delete_plugin' )
				->describe( 'Delete an inactive plugin and its files. Irreversible without a reinstall, and always gated.', 'Delete plugin' )
				->scope( 'extensions:write' )
				->cap( 'delete_plugins' )
				->destructive()
				->gated()
				->precheck( array( $this, 'check_plugin' ) )
				->input(
					Schema::object(
						array(
							'plugin' => Schema::string( 'Plugin file from list_plugins.' ),
						),
						array( 'plugin' )
					)
				)
				->run( array( $this, 'delete_plugin' ) )
		);

		$registry->add(
			$this->tool( 'switch_theme' )
				->describe( 'Activate a different theme. This visibly changes the whole front end, so it is gated. Check the target theme exists with list_themes first.', 'Switch theme' )
				->scope( 'extensions:write' )
				->cap( 'switch_themes' )
				->destructive( true )
				->gated()
				->precheck( array( $this, 'check_theme' ) )
				->input(
					Schema::object(
						array(
							'stylesheet' => Schema::string( 'Theme stylesheet directory, e.g. twentytwentyfour.' ),
						),
						array( 'stylesheet' )
					)
				)
				->run( array( $this, 'switch_theme' ) )
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function list_plugins( array $args ) {
		$plugins = SiteProfile::extensions()['plugins'];

		$status = isset( $args['status'] ) ? $args['status'] : 'all';
		$search = isset( $args['search'] ) ? strtolower( $args['search'] ) : '';

		$filtered = array();

		foreach ( $plugins as $plugin ) {
			if ( 'active' === $status && ! $plugin['active'] ) {
				continue;
			}
			if ( 'inactive' === $status && $plugin['active'] ) {
				continue;
			}
			if ( 'update-available' === $status && ! $plugin['update'] ) {
				continue;
			}
			if ( '' !== $search && false === strpos( strtolower( $plugin['name'] . ' ' . $plugin['slug'] ), $search ) ) {
				continue;
			}

			$filtered[] = $plugin;
		}

		return array(
			'plugins' => $filtered,
			'total'   => count( $plugins ),
			'shown'   => count( $filtered ),
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function activate_plugin( array $args ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';

		$plugin = $args['plugin'];

		if ( ! $this->plugin_exists( $plugin ) ) {
			return $this->fail( __( 'No installed plugin with that file. Call list_plugins to see the exact values.', 'kai-vibe' ) );
		}

		if ( is_plugin_active( $plugin ) ) {
			return array( 'activated' => false, 'plugin' => $plugin, 'note' => 'Already active.' );
		}

		$result = activate_plugin( $plugin );

		if ( is_wp_error( $result ) ) {
			return $this->fail(
				sprintf(
					/* translators: %s: error message. */
					__( 'Activation failed and was rolled back: %s', 'kai-vibe' ),
					$result->get_error_message()
				)
			);
		}

		return array( 'activated' => true, 'plugin' => $plugin );
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function deactivate_plugin( array $args ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';

		$plugin = $args['plugin'];

		if ( $this->is_self( $plugin ) ) {
			return $this->fail( __( 'That is KAI Vibe itself. Deactivating it would end this connection, so it has to be done in wp-admin.', 'kai-vibe' ) );
		}

		if ( ! $this->plugin_exists( $plugin ) ) {
			return $this->fail( __( 'No installed plugin with that file.', 'kai-vibe' ) );
		}

		if ( ! is_plugin_active( $plugin ) ) {
			return array( 'deactivated' => false, 'plugin' => $plugin, 'note' => 'Already inactive.' );
		}

		deactivate_plugins( $plugin );

		return array( 'deactivated' => true, 'plugin' => $plugin );
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function install_plugin( array $args ) {
		$this->load_upgrader();

		if ( ! empty( $args['slug'] ) ) {
			$api = plugins_api(
				'plugin_information',
				array( 'slug' => sanitize_key( $args['slug'] ), 'fields' => array( 'sections' => false ) )
			);

			if ( is_wp_error( $api ) ) {
				return $this->fail(
					sprintf(
						/* translators: 1: slug, 2: error. */
						__( 'Could not find "%1$s" on WordPress.org: %2$s', 'kai-vibe' ),
						$args['slug'],
						$api->get_error_message()
					)
				);
			}

			$source = $api->download_link;
			$label  = $api->name;
		} elseif ( ! empty( $args['zip_url'] ) ) {
			$source = esc_url_raw( $args['zip_url'] );
			$label  = basename( $source );
		} else {
			return $this->fail( __( 'Pass either a WordPress.org slug or a zip_url.', 'kai-vibe' ) );
		}

		$upgrader = new \Plugin_Upgrader( new \WP_Ajax_Upgrader_Skin() );
		$result   = $upgrader->install( $source );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( ! $result ) {
			return $this->fail( __( 'Installation failed. Check that wp-content/plugins is writable.', 'kai-vibe' ) );
		}

		$installed = $upgrader->plugin_info();
		$activated = false;

		if ( ! empty( $args['activate'] ) && $installed ) {
			$activation = activate_plugin( $installed );
			$activated  = ! is_wp_error( $activation );
		}

		return array(
			'installed' => true,
			'name'      => $label,
			'plugin'    => $installed,
			'activated' => $activated,
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function update_extension( array $args ) {
		// The tool declares update_plugins statically; the theme branch needs
		// the theme capability instead.
		if ( 'theme' === $args['type'] && ! current_user_can( 'update_themes' ) ) {
			return $this->fail( __( 'The WordPress user this token acts as cannot update themes.', 'kai-vibe' ) );
		}

		$this->load_upgrader();

		$skin = new \WP_Ajax_Upgrader_Skin();

		if ( 'plugin' === $args['type'] ) {
			if ( ! $this->plugin_exists( $args['target'] ) ) {
				return $this->fail( __( 'No installed plugin with that file.', 'kai-vibe' ) );
			}

			wp_update_plugins();

			$upgrader = new \Plugin_Upgrader( $skin );
			$result   = $upgrader->upgrade( $args['target'] );
		} else {
			if ( ! wp_get_theme( $args['target'] )->exists() ) {
				return $this->fail( __( 'No installed theme with that stylesheet.', 'kai-vibe' ) );
			}

			wp_update_themes();

			$upgrader = new \Theme_Upgrader( $skin );
			$result   = $upgrader->upgrade( $args['target'] );
		}

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( false === $result ) {
			return array( 'updated' => false, 'note' => 'Already at the latest version, or no update was available.' );
		}

		return array(
			'updated'  => true,
			'type'     => $args['type'],
			'target'   => $args['target'],
			'messages' => $skin->get_upgrade_messages(),
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function delete_plugin( array $args ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';

		$plugin = $args['plugin'];

		if ( $this->is_self( $plugin ) ) {
			return $this->fail( __( 'That is KAI Vibe itself and cannot be deleted from here.', 'kai-vibe' ) );
		}

		if ( ! $this->plugin_exists( $plugin ) ) {
			return $this->fail( __( 'No installed plugin with that file.', 'kai-vibe' ) );
		}

		if ( is_plugin_active( $plugin ) ) {
			return $this->fail( __( 'That plugin is still active. Deactivate it first so you can check nothing breaks before the files go.', 'kai-vibe' ) );
		}

		// delete_plugins() needs file.php loaded and the direct filesystem
		// method forced, or it returns null without deleting anything.
		$this->load_upgrader();

		$result = delete_plugins( array( $plugin ) );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( true !== $result ) {
			return $this->fail( __( 'WordPress could not get filesystem access to delete that plugin. Nothing was removed.', 'kai-vibe' ) );
		}

		return array( 'deleted' => true, 'plugin' => $plugin );
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function switch_theme( array $args ) {
		$theme = wp_get_theme( $args['stylesheet'] );

		if ( ! $theme->exists() ) {
			return $this->fail( __( 'No installed theme with that stylesheet. Call list_themes first.', 'kai-vibe' ) );
		}

		$errors = $theme->errors();

		if ( $errors ) {
			return $this->fail(
				sprintf(
					/* translators: %s: error message. */
					__( 'That theme is broken and cannot be activated: %s', 'kai-vibe' ),
					$errors->get_error_message()
				)
			);
		}

		$previous = get_stylesheet();

		switch_theme( $args['stylesheet'] );

		return array(
			'switched' => true,
			'from'     => $previous,
			'to'       => $args['stylesheet'],
			'note'     => sprintf( 'The front end now renders with %s. Switch back with switch_theme and stylesheet=%s if this was wrong.', $theme->get( 'Name' ), $previous ),
		);
	}

	/**
	 * Settle everything that would make a plugin operation impossible, before
	 * the approval gate asks a human about it.
	 *
	 * @param array $args Arguments.
	 * @param \KaiVibe\Mcp\Tool $tool Tool being called.
	 * @return \KaiVibe\Mcp\ToolResult|null
	 */
	public function check_plugin( array $args, $tool ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';

		$plugin = isset( $args['plugin'] ) ? $args['plugin'] : '';

		if ( $this->is_self( $plugin ) ) {
			return $this->fail( __( 'That is KAI Vibe itself. Acting on it would end this connection, so it has to be done in wp-admin. Do not ask for approval.', 'kai-vibe' ) );
		}

		if ( ! $this->plugin_exists( $plugin ) ) {
			return $this->fail( __( 'No installed plugin with that file. Call list_plugins to see the exact values.', 'kai-vibe' ) );
		}

		if ( 'delete_plugin' === $tool->name && is_plugin_active( $plugin ) ) {
			return $this->fail( __( 'That plugin is still active. Deactivate it first so you can check nothing breaks before the files go.', 'kai-vibe' ) );
		}

		return null;
	}

	/**
	 * @param array $args Arguments.
	 * @return \KaiVibe\Mcp\ToolResult|null
	 */
	public function check_theme( array $args ) {
		$theme = wp_get_theme( isset( $args['stylesheet'] ) ? $args['stylesheet'] : '' );

		if ( ! $theme->exists() ) {
			return $this->fail( __( 'No installed theme with that stylesheet. Call list_themes first.', 'kai-vibe' ) );
		}

		if ( $theme->errors() ) {
			return $this->fail(
				sprintf(
					/* translators: %s: error message. */
					__( 'That theme is broken and cannot be activated: %s', 'kai-vibe' ),
					$theme->errors()->get_error_message()
				)
			);
		}

		return null;
	}

	/**
	 * @param string $plugin Plugin file.
	 * @return bool
	 */
	private function plugin_exists( $plugin ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';

		return array_key_exists( $plugin, get_plugins() );
	}

	/**
	 * @param string $plugin Plugin file.
	 * @return bool
	 */
	private function is_self( $plugin ) {
		return plugin_basename( KAIV_FILE ) === $plugin;
	}

	private function load_upgrader() {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
		require_once ABSPATH . 'wp-admin/includes/theme.php';

		// The upgraders write directly to disk rather than asking for FTP details.
		add_filter( 'filesystem_method', static function () {
			return 'direct';
		} );
	}
}
