<?php
/**
 * The media library.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Schema;
use KaiVibe\Mcp\ToolRegistry;
use KaiVibe\Support\Formatter;

defined( 'ABSPATH' ) || exit;

class MediaTools extends ToolPack {

	public function register( ToolRegistry $registry ) {

		$registry->add(
			$this->tool( 'search_media' )
				->describe( 'Search the media library by filename, title, alt text or MIME type. Use this before uploading anything — sites accumulate the same image five times over.', 'Search media' )
				->scope( 'media:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'search'    => Schema::string( 'Text to match against title, filename, caption and alt text.' ),
							'mime_type' => Schema::string( 'MIME type or prefix, e.g. image/ or image/png or application/pdf.' ),
							'author'    => Schema::integer( 'Only files uploaded by this user ID.' ),
							'unattached'=> Schema::boolean( 'Only files not attached to any post.', array( 'default' => false ) ),
							'missing_alt' => Schema::boolean( 'Only images with empty alt text. Useful for accessibility passes.', array( 'default' => false ) ),
							'per_page'  => Schema::integer( 'Results per page.', array( 'default' => 20, 'minimum' => 1, 'maximum' => 100 ) ),
							'page'      => Schema::integer( 'Page number.', array( 'default' => 1, 'minimum' => 1 ) ),
						)
					)
				)
				->run( array( $this, 'search_media' ) )
		);

		$registry->add(
			$this->tool( 'upload_media' )
				->describe(
					'Add a file to the media library from a URL, or from base64 data you already hold. Sets the title, alt text and caption in the same call, and can attach it to a post. Returns the attachment ID you need for featured images and block markup.',
					'Upload media'
				)
				->scope( 'media:write' )
				->cap( 'upload_files' )
				->input(
					Schema::object(
						array(
							'url'       => Schema::string( 'URL to download the file from.' ),
							'data'      => Schema::string( 'Base64-encoded file contents, as an alternative to url.' ),
							'filename'  => Schema::string( 'Filename to store it as. Required when using data.' ),
							'title'     => Schema::string( 'Attachment title.' ),
							'alt'       => Schema::string( 'Alt text. Always set this for images — it is both accessibility and SEO.' ),
							'caption'   => Schema::string( 'Caption.' ),
							'post_id'   => Schema::integer( 'Attach the upload to this post.' ),
							'featured'  => Schema::boolean( 'Also set it as that post\'s featured image.', array( 'default' => false ) ),
						)
					)
				)
				->run( array( $this, 'upload_media' ) )
		);

		$registry->add(
			$this->tool( 'update_media' )
				->describe( 'Change an attachment\'s title, alt text, caption or description. The quickest win on most sites is filling in missing alt text found with search_media.', 'Update media' )
				->scope( 'media:write' )
				->input(
					Schema::object(
						array(
							'attachment_id' => Schema::integer( 'Attachment ID.' ),
							'title'         => Schema::string( 'New title.' ),
							'alt'           => Schema::string( 'New alt text.' ),
							'caption'       => Schema::string( 'New caption.' ),
							'description'   => Schema::string( 'New description.' ),
						),
						array( 'attachment_id' )
					)
				)
				->run( array( $this, 'update_media' ) )
		);

		$registry->add(
			$this->tool( 'delete_media' )
				->describe( 'Delete an attachment and its generated sizes from disk. This cannot be undone, so it is gated behind an approval.', 'Delete media' )
				->scope( 'media:write' )
				->destructive( true )
				->gated()
				->input(
					Schema::object(
						array(
							'attachment_id' => Schema::integer( 'Attachment ID.' ),
						),
						array( 'attachment_id' )
					)
				)
				->run( array( $this, 'delete_media' ) )
		);

		$registry->add(
			$this->tool( 'set_featured_image' )
				->describe( 'Set or clear a post\'s featured image.', 'Featured image' )
				->scope( 'media:write' )
				->input(
					Schema::object(
						array(
							'post_id'       => Schema::integer( 'Post ID.' ),
							'attachment_id' => Schema::integer( 'Attachment ID. Pass 0 to remove the featured image.' ),
						),
						array( 'post_id', 'attachment_id' )
					)
				)
				->run( array( $this, 'set_featured_image' ) )
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function search_media( array $args ) {
		$per_page = isset( $args['per_page'] ) ? (int) $args['per_page'] : 20;
		$page     = isset( $args['page'] ) ? (int) $args['page'] : 1;

		$query_args = array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		if ( ! empty( $args['search'] ) ) {
			$query_args['s'] = $args['search'];
		}
		if ( ! empty( $args['mime_type'] ) ) {
			$query_args['post_mime_type'] = $args['mime_type'];
		}
		if ( ! empty( $args['author'] ) ) {
			$query_args['author'] = (int) $args['author'];
		}
		if ( ! empty( $args['unattached'] ) ) {
			$query_args['post_parent'] = 0;
		}

		if ( ! empty( $args['missing_alt'] ) ) {
			$query_args['post_mime_type'] = isset( $query_args['post_mime_type'] ) ? $query_args['post_mime_type'] : 'image';
			$query_args['meta_query']     = array(
				'relation' => 'OR',
				array( 'key' => '_wp_attachment_image_alt', 'compare' => 'NOT EXISTS' ),
				array( 'key' => '_wp_attachment_image_alt', 'value' => '', 'compare' => '=' ),
			);
		}

		$query = new \WP_Query( $query_args );
		$items = array();

		foreach ( $query->posts as $attachment ) {
			$items[] = Formatter::attachment( $attachment );
		}

		return $this->paged( $items, (int) $query->found_posts, $page, $per_page );
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function upload_media( array $args ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$post_id = isset( $args['post_id'] ) ? (int) $args['post_id'] : 0;

		if ( ! empty( $args['url'] ) ) {
			$attachment_id = media_sideload_image( $args['url'], $post_id, null, 'id' );

			if ( is_wp_error( $attachment_id ) ) {
				// media_sideload_image only handles images; fall back for other types.
				$attachment_id = $this->sideload_any( $args['url'], $post_id );
			}
		} elseif ( ! empty( $args['data'] ) ) {
			if ( empty( $args['filename'] ) ) {
				return $this->fail( __( 'Pass a filename alongside base64 data so WordPress knows the file type.', 'kai-vibe' ) );
			}

			$decoded = base64_decode( $args['data'], true );

			if ( false === $decoded ) {
				return $this->fail( __( 'The data argument is not valid base64.', 'kai-vibe' ) );
			}

			$upload = wp_upload_bits( sanitize_file_name( $args['filename'] ), null, $decoded );

			if ( ! empty( $upload['error'] ) ) {
				return $this->fail( $upload['error'] );
			}

			$attachment_id = $this->attach_file( $upload['file'], $post_id, isset( $args['title'] ) ? $args['title'] : '' );
		} else {
			return $this->fail( __( 'Pass either a url or base64 data.', 'kai-vibe' ) );
		}

		if ( is_wp_error( $attachment_id ) ) {
			return $attachment_id;
		}

		$update = array( 'ID' => $attachment_id );

		if ( ! empty( $args['title'] ) ) {
			$update['post_title'] = $args['title'];
		}
		if ( isset( $args['caption'] ) ) {
			$update['post_excerpt'] = $args['caption'];
		}

		if ( count( $update ) > 1 ) {
			wp_update_post( wp_slash( $update ) );
		}

		if ( isset( $args['alt'] ) ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', wp_slash( $args['alt'] ) );
		}

		if ( ! empty( $args['featured'] ) && $post_id ) {
			set_post_thumbnail( $post_id, $attachment_id );
		}

		return array(
			'uploaded'   => true,
			'attachment' => Formatter::attachment( get_post( $attachment_id ) ),
			'note'       => empty( $args['alt'] ) ? 'No alt text was set. Set it with update_media unless the image is purely decorative.' : '',
		);
	}

	/**
	 * Sideload a non-image file from a URL.
	 *
	 * @param string $url     Source URL.
	 * @param int    $post_id Parent post.
	 * @return int|\WP_Error
	 */
	private function sideload_any( $url, $post_id ) {
		$temp = download_url( $url );

		if ( is_wp_error( $temp ) ) {
			return $temp;
		}

		// wp_parse_url() returns null for a URL with no path, which basename()
		// then turns into an empty filename that sideloading always rejects.
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		$name = '' !== $path ? basename( $path ) : '';

		if ( '' === $name || '' === pathinfo( $name, PATHINFO_EXTENSION ) ) {
			wp_delete_file( $temp );

			return new \WP_Error(
				'kaiv_no_filename',
				__( 'That URL has no usable filename with an extension. Pass the file as base64 data with an explicit filename instead.', 'kai-vibe' )
			);
		}

		$file = array(
			'name'     => $name,
			'tmp_name' => $temp,
		);

		$attachment_id = media_handle_sideload( $file, $post_id );

		if ( is_wp_error( $attachment_id ) && file_exists( $temp ) ) {
			wp_delete_file( $temp );
		}

		return $attachment_id;
	}

	/**
	 * Register an already-written file as an attachment.
	 *
	 * @param string $file    Absolute path.
	 * @param int    $post_id Parent post.
	 * @param string $title   Title.
	 * @return int|\WP_Error
	 */
	private function attach_file( $file, $post_id, $title ) {
		$filetype = wp_check_filetype( basename( $file ), null );

		$attachment_id = wp_insert_attachment(
			array(
				'post_mime_type' => $filetype['type'],
				'post_title'     => $title ? $title : preg_replace( '/\.[^.]+$/', '', basename( $file ) ),
				'post_content'   => '',
				'post_status'    => 'inherit',
			),
			$file,
			$post_id,
			true
		);

		if ( is_wp_error( $attachment_id ) ) {
			return $attachment_id;
		}

		wp_update_attachment_metadata( $attachment_id, wp_generate_attachment_metadata( $attachment_id, $file ) );

		return $attachment_id;
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function update_media( array $args ) {
		$attachment = $this->require_post( $args['attachment_id'], 'edit_post' );

		if ( ! $attachment instanceof \WP_Post ) {
			return $attachment;
		}

		if ( 'attachment' !== $attachment->post_type ) {
			return $this->fail( __( 'That ID is not an attachment.', 'kai-vibe' ) );
		}

		$update = array( 'ID' => $attachment->ID );

		if ( isset( $args['title'] ) ) {
			$update['post_title'] = $args['title'];
		}
		if ( isset( $args['caption'] ) ) {
			$update['post_excerpt'] = $args['caption'];
		}
		if ( isset( $args['description'] ) ) {
			$update['post_content'] = $args['description'];
		}

		if ( count( $update ) > 1 ) {
			wp_update_post( wp_slash( $update ) );
		}

		if ( isset( $args['alt'] ) ) {
			update_post_meta( $attachment->ID, '_wp_attachment_image_alt', wp_slash( $args['alt'] ) );
		}

		return array( 'updated' => true, 'attachment' => Formatter::attachment( get_post( $attachment->ID ) ) );
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function delete_media( array $args ) {
		$attachment = $this->require_post( $args['attachment_id'], 'delete_post' );

		if ( ! $attachment instanceof \WP_Post ) {
			return $attachment;
		}

		if ( 'attachment' !== $attachment->post_type ) {
			return $this->fail( __( 'That ID is not an attachment.', 'kai-vibe' ) );
		}

		$title = $attachment->post_title;
		$url   = wp_get_attachment_url( $attachment->ID );

		$result = wp_delete_attachment( $attachment->ID, true );

		if ( ! $result ) {
			return $this->fail( __( 'WordPress refused to delete that attachment.', 'kai-vibe' ) );
		}

		return array( 'deleted' => true, 'title' => $title, 'url' => $url );
	}

	/**
	 * @param array $args Arguments.
	 * @return array|\KaiVibe\Mcp\ToolResult
	 */
	public function set_featured_image( array $args ) {
		$post = $this->require_post( $args['post_id'], 'edit_post' );

		if ( ! $post instanceof \WP_Post ) {
			return $post;
		}

		$attachment_id = (int) $args['attachment_id'];

		if ( 0 === $attachment_id ) {
			delete_post_thumbnail( $post->ID );

			return array( 'cleared' => true, 'post_id' => $post->ID );
		}

		if ( 'attachment' !== get_post_type( $attachment_id ) ) {
			return $this->fail( __( 'That attachment ID does not exist.', 'kai-vibe' ) );
		}

		set_post_thumbnail( $post->ID, $attachment_id );

		return array(
			'set'           => true,
			'post_id'       => $post->ID,
			'attachment_id' => $attachment_id,
			'url'           => wp_get_attachment_url( $attachment_id ),
		);
	}
}
