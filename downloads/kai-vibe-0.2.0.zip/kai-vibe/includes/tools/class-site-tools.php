<?php
/**
 * Orientation tools: what is this site, what can I do here, what am I waiting on.
 *
 * @package KaiVibe
 */

namespace KaiVibe\Tools;

use KaiVibe\Mcp\Schema;
use KaiVibe\Mcp\ToolRegistry;
use KaiVibe\Security\Approval;
use KaiVibe\Security\RateLimiter;
use KaiVibe\Support\SiteProfile;

defined( 'ABSPATH' ) || exit;

class SiteTools extends ToolPack {

	public function register( ToolRegistry $registry ) {

		$registry->add(
			$this->tool( 'site_info' )
				->describe(
					'Start here on any new task. Reports the site name and URL, WordPress/PHP/MySQL versions, active theme, whether it is a block theme, which page builder is installed, whether WooCommerce is running, and which capabilities this connection actually has (filesystem writable, WP-CLI present, database access, approval gate). Everything else you do should be informed by this.',
					'Site info'
				)
				->scope( 'site:read' )
				->read_only()
				->input( Schema::object() )
				->run(
					function () {
						return SiteProfile::overview();
					}
				)
		);

		$registry->add(
			$this->tool( 'list_post_types' )
				->describe( 'List every registered post type with its supports, taxonomies, REST base and the capability needed to edit it. Call this before assuming a site only has posts and pages — custom post types are where most bespoke sites keep their real content.', 'Post types' )
				->scope( 'site:read' )
				->read_only()
				->input( Schema::object() )
				->run(
					function () {
						return SiteProfile::post_types();
					}
				)
		);

		$registry->add(
			$this->tool( 'list_taxonomies' )
				->describe( 'List every registered taxonomy, which post types it applies to, whether it is hierarchical, and how many terms it holds.', 'Taxonomies' )
				->scope( 'site:read' )
				->read_only()
				->input( Schema::object() )
				->run(
					function () {
						return SiteProfile::taxonomies();
					}
				)
		);

		$registry->add(
			$this->tool( 'site_health' )
				->describe( 'Run the WordPress Site Health checks and report failures and recommendations, plus PHP limits, disk headroom, and whether cron and the object cache are working. Use this when the site "feels slow" or before blaming your own change.', 'Site health' )
				->scope( 'site:read' )
				->read_only()
				->input(
					Schema::object(
						array(
							'include_passing' => Schema::boolean( 'Include checks that passed. Off by default so the output stays about problems.', array( 'default' => false ) ),
						)
					)
				)
				->run( array( $this, 'site_health' ) )
		);

		$registry->add(
			$this->tool( 'connection_status' )
				->describe( 'Report which WordPress user this connection acts as, which scopes it holds, how many calls remain in the current rate-limit window, and which tools are available. Useful when a call fails and you are unsure whether it is a permission problem.', 'Connection status' )
				->scope( '' )
				->read_only()
				->input( Schema::object() )
				->run( array( $this, 'connection_status' ) )
		);

		$registry->add(
			$this->tool( 'check_approval' )
				->describe( 'Check whether the site owner has approved a gated operation. Pass the approval_id a previous tool call returned. When it reports "approved", call the original tool again with exactly the same arguments and it will go through. Poll this rather than retrying the tool blindly.', 'Check approval' )
				->scope( '' )
				->read_only()
				->input(
					Schema::object(
						array(
							'approval_id' => Schema::string( 'The approval id returned by the gated tool call.' ),
						),
						array( 'approval_id' )
					)
				)
				->run( array( $this, 'check_approval' ) )
		);

		$registry->add(
			$this->tool( 'list_approvals' )
				->describe( 'List operations currently waiting on the site owner, with what each one would do and when it expires.', 'Pending approvals' )
				->scope( '' )
				->read_only()
				->input( Schema::object() )
				->run(
					function () {
						return array(
							'pending'      => Approval::pending(),
							'approval_url' => Approval::url(),
						);
					}
				)
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function site_health( array $args ) {
		$include_passing = ! empty( $args['include_passing'] );

		// Site Health and the update helpers live in wp-admin, which a REST
		// request has not loaded.
		require_once ABSPATH . 'wp-admin/includes/update.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';

		$results = array( 'critical' => array(), 'recommended' => array(), 'good' => array() );

		if ( ! class_exists( 'WP_Site_Health' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-site-health.php';
		}

		if ( class_exists( 'WP_Site_Health' ) ) {
			$health = \WP_Site_Health::get_instance();

			foreach ( get_class_methods( $health ) as $method ) {
				if ( 0 !== strpos( $method, 'get_test_' ) ) {
					continue;
				}

				try {
					$test = $health->$method();
				} catch ( \Throwable $e ) {
					continue;
				}

				if ( ! is_array( $test ) || empty( $test['status'] ) ) {
					continue;
				}

				$bucket = isset( $results[ $test['status'] ] ) ? $test['status'] : 'recommended';

				if ( 'good' === $bucket && ! $include_passing ) {
					continue;
				}

				$results[ $bucket ][] = array(
					'label'       => isset( $test['label'] ) ? wp_strip_all_tags( $test['label'] ) : $method,
					'description' => isset( $test['description'] ) ? wp_strip_all_tags( $test['description'] ) : '',
				);
			}
		}

		$upload_dir = wp_upload_dir();
		$free       = @disk_free_space( ABSPATH );

		return array(
			'checks'      => $include_passing ? $results : array_diff_key( $results, array( 'good' => 1 ) ),
			'environment' => array(
				'php_version'        => PHP_VERSION,
				'memory_limit'       => ini_get( 'memory_limit' ),
				'wp_memory_limit'    => WP_MEMORY_LIMIT,
				'max_execution_time' => ini_get( 'max_execution_time' ),
				'upload_max_size'    => size_format( wp_max_upload_size() ),
				'disk_free'          => is_numeric( $free ) ? size_format( $free ) : 'unknown',
				'uploads_writable'   => wp_is_writable( $upload_dir['basedir'] ),
				'content_writable'   => wp_is_writable( WP_CONTENT_DIR ),
				'object_cache'       => wp_using_ext_object_cache() ? 'external' : 'database only',
				'cron'               => ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) ? 'disabled (external cron expected)' : 'enabled',
				'https'              => is_ssl(),
			),
			'updates'     => array(
				// get_core_updates() always includes the current-version offer,
				// so a bare count reports an update on an up-to-date site.
				'core'    => count(
					array_filter(
						(array) ( function_exists( 'get_core_updates' ) ? get_core_updates() : array() ),
						static function ( $offer ) {
							return isset( $offer->response ) && 'upgrade' === $offer->response;
						}
					)
				),
				'plugins' => count( (array) get_plugin_updates() ),
				'themes'  => count( (array) get_theme_updates() ),
			),
		);
	}

	/**
	 * @return array
	 */
	public function connection_status() {
		$auth  = \KaiVibe\Auth\Authenticator::instance();
		$user  = wp_get_current_user();
		$token = $auth->token();

		$tools = array();
		foreach ( kaiv()->tools()->available() as $tool ) {
			$tools[] = $tool->name;
		}

		return array(
			'acting_as'  => array(
				'id'    => $user->ID,
				'login' => $user->user_login,
				'roles' => array_values( $user->roles ),
			),
			'token'      => $token ? array(
				'id'      => $token['id'],
				'label'   => $token['label'],
				'expires' => $token['expires'] ? gmdate( 'c', $token['expires'] ) : 'never',
			) : null,
			'scopes'     => $auth->scopes(),
			'rate_limit' => RateLimiter::status(),
			'tools'      => $tools,
		);
	}

	/**
	 * @param array $args Arguments.
	 * @return array
	 */
	public function check_approval( array $args ) {
		$request = Approval::get( $args['approval_id'] );

		if ( ! $request ) {
			return array(
				'status' => 'unknown',
				'note'   => 'No approval request with that id. It may have expired — call the original tool again to raise a fresh one.',
			);
		}

		$expired = $request['expires'] < time() && Approval::PENDING === $request['status'];

		$notes = array(
			Approval::PENDING  => 'Still waiting. Ask the site owner to approve it at the URL below, then check again.',
			Approval::APPROVED => 'Approved. Call the original tool again with exactly the same arguments — the gate will let it through once.',
			Approval::DENIED   => 'Declined. Do not retry. Ask the site owner what they would prefer instead.',
			Approval::USED     => 'Already used. The operation has run.',
		);

		return array(
			'approval_id'  => $request['id'],
			'tool'         => $request['tool'],
			'summary'      => $request['summary'],
			'status'       => $expired ? 'expired' : $request['status'],
			'expires_in'   => max( 0, $request['expires'] - time() ),
			'approval_url' => Approval::url(),
			'note'         => $expired
				? 'This request expired. Call the original tool again to raise a fresh one.'
				: ( isset( $notes[ $request['status'] ] ) ? $notes[ $request['status'] ] : '' ),
		);
	}
}
