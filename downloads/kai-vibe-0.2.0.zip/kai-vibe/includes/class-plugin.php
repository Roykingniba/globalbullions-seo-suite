<?php
/**
 * Plugin bootstrap. Wires the REST endpoint, auth layer, tool registry and admin UI.
 *
 * @package KaiVibe
 */

namespace KaiVibe;

use KaiVibe\Admin\Admin;
use KaiVibe\Auth\Authenticator;
use KaiVibe\Auth\OAuth;
use KaiVibe\Mcp\RestController;
use KaiVibe\Mcp\ToolRegistry;

defined( 'ABSPATH' ) || exit;

final class Plugin {

	/** @var Plugin|null */
	private static $instance = null;

	/** @var ToolRegistry */
	private $tools;

	/** @var bool */
	private $booted = false;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->tools = new ToolRegistry();
	}

	/**
	 * The tool registry every tool pack registers into.
	 *
	 * @return ToolRegistry
	 */
	public function tools() {
		return $this->tools;
	}

	public function boot() {
		if ( $this->booted ) {
			return;
		}
		$this->booted = true;

		add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
		add_action( 'init', array( $this, 'maybe_upgrade' ) );

		// Auth must hook early — determine_current_user runs before REST dispatch.
		Authenticator::instance()->hooks();

		// The OAuth server answers discovery requests that arrive before any
		// credentials exist, so it hooks alongside auth rather than behind it.
		OAuth::instance()->hooks();

		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
		add_action( 'kaiv_cleanup', array( Security\AuditLog::class, 'prune' ) );

		// Tool packs load on init so post types, taxonomies and plugins like
		// WooCommerce have already registered themselves.
		add_action( 'init', array( $this, 'register_tools' ), 20 );

		if ( is_admin() ) {
			Admin::instance()->hooks();
		}
	}

	public function load_textdomain() {
		load_plugin_textdomain( 'kai-vibe', false, dirname( plugin_basename( KAIV_FILE ) ) . '/languages' );
	}

	public function maybe_upgrade() {
		if ( get_option( 'kaiv_db_version' ) !== KAIV_VERSION ) {
			Installer::install_tables();
			update_option( 'kaiv_db_version', KAIV_VERSION );
		}
	}

	public function register_routes() {
		( new RestController() )->register_routes();
	}

	/**
	 * Instantiate every tool pack. Each pack's register() adds tools to the registry.
	 */
	public function register_tools() {
		$packs = array(
			Tools\SiteTools::class,
			Tools\ContentTools::class,
			Tools\TaxonomyTools::class,
			Tools\MediaTools::class,
			Tools\UserTools::class,
			Tools\CommentTools::class,
			Tools\OptionTools::class,
			Tools\MenuTools::class,
			Tools\ExtensionTools::class,
			Tools\FileTools::class,
			Tools\CliTools::class,
			Tools\DatabaseTools::class,
			Tools\BuilderTools::class,
			Tools\WooCommerceTools::class,
			Tools\SearchTools::class,
			Tools\MaintenanceTools::class,
			Tools\JournalTools::class,
		);

		/**
		 * Filter the tool packs loaded into the MCP server.
		 *
		 * @param string[] $packs Fully qualified class names implementing ToolPack.
		 */
		$packs = apply_filters( 'kaiv_tool_packs', $packs );

		foreach ( $packs as $pack ) {
			if ( class_exists( $pack ) ) {
				( new $pack() )->register( $this->tools );
			}
		}

		/**
		 * Fires after all built-in tools are registered. Add your own here.
		 *
		 * @param ToolRegistry $registry Tool registry.
		 */
		do_action( 'kaiv_register_tools', $this->tools );
	}
}
