<?php
/**
 * Maps KaiVibe\Sub\ClassName to includes/sub/class-class-name.php.
 *
 * @package KaiVibe
 */

namespace KaiVibe;

defined( 'ABSPATH' ) || exit;

class Autoloader {

	const PREFIX = 'KaiVibe\\';

	public static function register() {
		spl_autoload_register( array( __CLASS__, 'load' ) );
	}

	/**
	 * @param string $class Fully qualified class name.
	 */
	public static function load( $class ) {
		if ( 0 !== strpos( $class, self::PREFIX ) ) {
			return;
		}

		$relative = substr( $class, strlen( self::PREFIX ) );
		$parts    = explode( '\\', $relative );
		$name     = array_pop( $parts );

		// ToolRegistry -> class-tool-registry.php
		$file = 'class-' . strtolower( preg_replace( '/([a-z0-9])([A-Z])/', '$1-$2', $name ) ) . '.php';

		$dir = '';
		foreach ( $parts as $part ) {
			$dir .= strtolower( preg_replace( '/([a-z0-9])([A-Z])/', '$1-$2', $part ) ) . '/';
		}

		$path = KAIV_DIR . 'includes/' . $dir . $file;

		if ( is_readable( $path ) ) {
			require_once $path;
		}
	}
}
