<?php
/**
 * Fired when the plugin is deleted from wp-admin.
 *
 * Removes every option, table and scheduled event the plugin created.
 * Tokens are destroyed here — deleting the plugin revokes all agent access.
 *
 * @package KaiVibe
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

$options = array(
	'kaiv_settings',
	'kaiv_tokens',
	'kaiv_db_version',
	'kaiv_pending_approvals',
	'kaiv_install_time',
);

foreach ( $options as $option ) {
	delete_option( $option );
	delete_site_option( $option );
}

// Drop custom tables.
foreach ( array( 'kaiv_audit_log', 'kaiv_journal' ) as $table ) {
	$name = $wpdb->prefix . $table;
	$wpdb->query( "DROP TABLE IF EXISTS `{$name}`" ); // phpcs:ignore WordPress.DB
}

// Clear transients used for approvals and rate limiting.
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_kaiv_%' OR option_name LIKE '_transient_timeout_kaiv_%'" ); // phpcs:ignore WordPress.DB

wp_clear_scheduled_hook( 'kaiv_cleanup' );
